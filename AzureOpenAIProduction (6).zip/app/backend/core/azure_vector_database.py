# import requests
# import os
# from pathlib import Path
# from datetime import datetime
# from dotenv import load_dotenv
# # from openai import AzureOpenAI


# ENV_FILE = os.getenv("ENV_FILE") or ".env_local"
# uplevel_folder = f"{Path(__file__).parent.parent.absolute().as_posix()}/"
# env_location = uplevel_folder + ENV_FILE
# load_dotenv(env_location)

# AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY")
# AZURE_SEARCH_URL = os.getenv("AZURE_AI_SEARCH_URL")
# INDEX_NAME = os.getenv("AZURE_AI_SEARCH_INDEX_NAME")
# SEARCH_API_URL = f"{AZURE_SEARCH_URL}/{INDEX_NAME}/docs/" + "search"
# MODIFY_API_URL = f"{AZURE_SEARCH_URL}/{INDEX_NAME}/docs/" + "index"


# # def get_embedding_vector_from_content(content: str) -> list:
# #     aoai_client = AzureOpenAI(
# #         azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
# #         api_key=os.environ["AZURE_EMBEDDING_API_KEY"],
# #         api_version=os.environ["AZURE_OPENAI_API_VERSION"]
# #     )

# #     # generate a vector embedding of the user's question
# #     embedding = aoai_client.embeddings.create(input=content,
# #                                             model=os.environ["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"])
# #     vector = embedding.data[0].embedding
# #     return vector
    
# def get_chunk_info_by_file_name(file_names: list, ai_search_version: str, select_field = "id, document_name"):
#     end_point = SEARCH_API_URL + "?api-version=" + ai_search_version
#     filter_items = []
#     for file_name in file_names:
#         filter_items.append("document_name eq '" + file_name + "'")
#     filter_conditions = " or ".join(filter_items)
#     headers = {'content-type': 'application/json', 'api-key': AZURE_SEARCH_KEY}
#     payload = {"filter": filter_conditions, "select": select_field}
#     response = requests.post(end_point, json=payload, headers=headers)
#     json_data = response.json()
    
#     return json_data


# def get_chunk_id_by_file_name(file_names: list, ai_search_version: str, exclude_checkpoint: bool = True):
#     json_data = get_chunk_info_by_file_name(file_names, ai_search_version)
#     ids = []
#     for item in json_data['value']:
#         if exclude_checkpoint and item["id"]=="Update=Check=Point":
#             continue
#         ids.append(item['id'])
#     return ids


# def remove_chunk_by_id(ids: list, ai_search_version: str):
#     end_point = MODIFY_API_URL + "?api-version=" + ai_search_version
#     headers = {'content-type': 'application/json', 'api-key': AZURE_SEARCH_KEY}
#     value = []
#     for id in ids:
#         value.append({"@search.action": "delete", "id": id})
#     payload = {"value": value}
#     response = requests.post(end_point, json=payload, headers=headers)
#     if response.status_code == 200:
#         return True
#     return False
    

# def remove_outdate_azure_document(file_name: str, ai_search_version: str):
#     file_name_info = []
#     if file_name:
#         file_name = clean_document_key(file_name)
#         file_name_info = [file_name]
#     ids = get_chunk_id_by_file_name(file_name_info, ai_search_version)
#     while ids:
#         remove_chunk_by_id(ids, ai_search_version)
#         ids = get_chunk_id_by_file_name(file_name_info, ai_search_version)


# def update_vector_record(values: list , ai_search_version: str):
#     end_point = MODIFY_API_URL + "?api-version=" + ai_search_version
#     headers = {'content-type': 'application/json', 'api-key': AZURE_SEARCH_KEY}
#     payload = {"value": values}
#     response = requests.post(end_point, json=payload, headers=headers)
#     if response.status_code == 200:
#         return True
#     return False


# def clean_document_key(file_name: str) -> str:
#      file_name = file_name.replace(".", "_")
#      file_name = file_name.replace(" ", "_")
#      file_name = file_name.replace("@", "-")
#      file_name = file_name.replace(",", "")
#      return file_name


# def upload_vector_database(contents: list, meta_jsons:list, user_name: str, file_name: str, ai_search_version: str):
#     values = []
#     count = 0
#     file_name = clean_document_key(file_name)
#     user_name = clean_document_key(user_name)
#     for i in range(len(contents)):
#         content = contents[i]
#         meta_json = ""
#         if meta_jsons:
#             meta_json = meta_jsons[i]
        
#         vector = get_embedding_vector_from_content(content)
#         id = "tmp_" + user_name + "_" + file_name + "_" + str(count)
#         document_name = "tmp_" + user_name

#         value = {
#             "@search.action": "upload",
#             "id": id,
#             "url":"tmp_" + user_name,
#             "filepath": "tmp_" + user_name,
#             "content": content,
#             "contentVector": vector,
#             "meta_json_string": meta_json,
#             "document_name": document_name,
#         }
#         values.append(value)
#         count += 1
#     response = update_vector_record(values, ai_search_version)
#     return response