import os
import shutil
import uuid
import asyncio
import openai
import platform
from azure.storage.blob import BlobServiceClient
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import SearchIndex, SimpleField, SearchableField
from azure.core.credentials import AzureKeyCredential
from langchain.document_loaders import PyPDFLoader, UnstructuredWordDocumentLoader, UnstructuredPowerPointLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from core.img_extractor import pdf_image,img_summary
import re
from collections import defaultdict
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta,timezone
from quart import session
from core.doc_translate import translate_document, upload_file_to_azure, generate_target_uri, generate_previewable_url
from core.scanned_doc import scannned_document
import logging
# Constants
CHUNK_SIZE = 1000
# user_name=session['user_name'] 
pattern = r"pageno_(\d+)"
CHUNK_OVERLAP = 200
BATCH_SIZE = 100

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

def create_search_index(index_name, search_service_endpoint, search_api_key):
    # search_service_name = "poc-openai-cogsrch"
    search_service_name = os.getenv('AZURE_SEARCH_SERVICE_NAME')
    # admin_key = AzureKeyCredential("TBpoXA6at3L38HsBWSRHnZWfstC07Txt7kDulY7ccDAzSeAHslm9")
    admin_key = AzureKeyCredential(f"{os.getenv('AZURE_SEARCH_API_KEY')}")
    # index_name = "srathore_bulk"
    # indexer_client = SearchIndexerClient(endpoint=f"https://{search_service_name}.search.windows.net", credential=admin_key)

    # admin_key = "your_admin_key"
    # index_name = "your_index_name"

    # Initialize SearchIndexClient
    search_service_endpoint = f"https://{search_service_name}.search.windows.net"
    index_client = SearchIndexClient(endpoint=search_service_endpoint, credential=admin_key)
    
    fields = [
        SimpleField(name="id", type="Edm.String", key=True),
        SearchableField(name="content", type="Edm.String", searchable=True, filterable=False, sortable=False),
        SimpleField(name="filepath", type="Edm.String"),
        SearchableField(name="title", type="Edm.String"),
        SimpleField(name="url", type="Edm.String"),
        SimpleField(name="page_number",type="Edm.Int32")
        #SimpleField(name="page_number", type="Edm.Int32")
        # VectorField(name="contentVector", dimensions=1536, vector_search_configuration="vector_config")
    ]

    index = SearchIndex(
        name=index_name,
        fields=fields,
        # vector_search_configurations=[
        #     {"name": "vector_config", "kind": "vector_search"}
        # ]
    )

    index_client.create_index(index)

# def generate_previewable_sas_url(storage_account_name, storage_account_key, container_name, blob_name, page_number):
#     # Define the SAS token expiration time
#     sas_expiry = datetime.now() + timedelta(hours=1)  # 1-hour validity

#     # Generate SAS token
#     sas_token = generate_blob_sas(
#         account_name=storage_account_name,
#         account_key=storage_account_key,
#         container_name=container_name,
#         blob_name=blob_name,
#         permission=BlobSasPermissions(read=True),
#         expiry=sas_expiry,
#         content_disposition="inline",
#         content_type="application/pdf"
#     )

#     # Construct the full URL
#     blob_url = f"https://{storage_account_name}.blob.core.windows.net/{container_name}/{blob_name}"
#     previewable_url = f"{blob_url}?{sas_token}#page={page_number}"

#     return previewable_url
# def generate_previewable_sas_url(storage_account_name, storage_account_key, container_name, blob_name):
#     # Define the SAS token expiration time
#     sas_start = datetime.now(timezone.utc) - timedelta(minutes=5)
#     sas_expiry = datetime.now(timezone.utc) + timedelta(hours=1)  # 1-hour validity

#     # Generate SAS token
#     sas_token = generate_blob_sas(
#         account_name=storage_account_name,
#         account_key=storage_account_key,
#         container_name=container_name,
#         blob_name=blob_name,
#         permission=BlobSasPermissions(read=True),
#         expiry=sas_expiry,
#         start=sas_start,
#         content_disposition="inline",
#         content_type="application/pdf"
#     )

#     # Construct the full URL
#     blob_url = f"https://{storage_account_name}.blob.core.windows.net/{container_name}/{blob_name}"
#     previewable_url = f"{blob_url}?{sas_token}"

#     return previewable_url


def connect_to_blob_storage(container_name, connection_string):

    connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
    # connection_string = "DefaultEndpointsProtocol=https;AccountName=sapocopenai;AccountKey=H30mVmhmyKpFmLUkFSKpDO3CUe+jbcG8aGZ8TgCRNTQj5Ac5HB+649BzYypyo9eW0W9BRy9Z0oFr+ASt6hAVYw==;EndpointSuffix=core.windows.net"
    # container_name = "bulk-upload-qna"
    container_name = os.getenv('AZURE_BULK_UPLOAD_CONTAINER_NAME')

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_client = blob_service_client.get_container_client(container_name)
    return container_client

# def get_blob_text_streamed(container_client, blob_name, chunk_size=CHUNK_SIZE):
#     blob_client = container_client.get_blob_client(blob_name)
#     downloader = blob_client.download_blob()
    
#     text_data = ""
#     for chunk in downloader.chunks():
#         text_data += chunk.decode("utf-8",errors = "ignore")
#         if len(text_data) >= chunk_size:
#             yield text_data
#             text_data = ""
#     if text_data:
#         yield text_data
def get_file_text_streamed(file_path, chunk_size=CHUNK_SIZE):
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        text_data = ""
        for line in f:
            text_data += line
            if len(text_data) >= chunk_size:
                yield text_data
                text_data = ""
        if text_data:
            yield text_data
async def load_and_split_file(path,img_there,temp_image_path, tempvar):
    if path.endswith('.pdf'):
        loader = PyPDFLoader(path)
    elif path.endswith(('.doc', '.docx')):
        loader = UnstructuredWordDocumentLoader(path)
    elif path.endswith(('.ppt', '.pptx')):
        loader = UnstructuredPowerPointLoader(path)
    else:
        raise ValueError(f"Unsupported file format: {path}")
    
    # Load the document
    doc = loader.load()
    # Split the document into chunks with the specified chunk size and overlap
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP)
    split_docs = text_splitter.split_documents(doc)
    # print(split_docs, "158")
    # Threshold for determining insufficient text content
    token_threshold = 20
    insufficient_text_pages = []
    has_text = False
    # img_docs

    # Check each chunk for text content length
    total_tokens = sum(len(chunk.page_content.split()) for chunk in split_docs)
    has_text = total_tokens > 5
    for idx, chunk in enumerate(split_docs):
        # Handle page/slide metadata based on file type
        # if len(chunk.page_content.split()) >= token_threshold:
            # has_text = True
        if path.endswith(('.ppt', '.pptx')):
            print("****************************171******************************")
            chunk.metadata["page"] = idx + 1  # Using chunk index to assign slide number (starting from 1)
        else:
            chunk.metadata["page"] = chunk.metadata.get("page", 0) + 1

        #        # print("Img_docs",img_doc,"Img_Docs")
        # else:
        #     has_text = False
        #     if path.endswith(('.ppt', '.pptx')):
        #         print("****************************171******************************")
        #         chunk.metadata["page"] = idx + 1  # Using chunk index to assign slide number (starting from 1)
        #     else:
        #         chunk.metadata["page"] = chunk.metadata.get("page", 0) + 1
            # chunk.metadata["page"] = idx + 1
        print(insufficient_text_pages, "178")
        print(chunk.metadata["page"])       
            # insufficient_text_pages.append(chunk.metadata["page"]) 
    # for chunk in split_docs:
    #     chunk.metadata["page"] = chunk.metadata.get("page", 0) + 1
    #     if len(chunk.page_content.split()) >= token_threshold:
    #         has_text = True  # Mark that the document has text

    #            # print("Img_docs",img_doc,"Img_Docs")
    #     else:
            # insufficient_text_pages.append(chunk.metadata["page"])
            

    scanned_doc_handler = scannned_document()
    print("******************191********************")

    # Trigger OCR only if no meaningful text is found in the document

    if not has_text and tempvar:
        print(f"Document appears to be scanned with insufficient text. Pages: {insufficient_text_pages}")
        output_folder = os.path.join("./temp_images", os.path.basename(path).split('.')[0])
        os.makedirs(output_folder, exist_ok=True)

        # Convert all pages of the document into images
        await scanned_doc_handler.split_pdf_into_images(path, output_folder)

        combined_ocr_results = []
        # Process the images with OCR
        for image_file in sorted(os.listdir(output_folder)):
            image_path = os.path.join(output_folder, image_file)
            if os.path.isfile(image_path) and image_file.endswith(('.png', '.jpeg', '.jpg')):
                ocr_text = scanned_doc_handler.extract_text_from_image(image_path)
                if ocr_text.strip():  # Skip empty OCR results
                    repeated_ocr_text = ' '.join([ocr_text] * 35)
                    page_number = int(image_file.split('_')[1].split('.')[0])  # Extract page number from file name
                    #combined_ocr_results.append({"content": ocr_text, "page": page_number})
                    for _ in range(35):
                        combined_ocr_results.append({"content": repeated_ocr_text, "page": page_number})

        # Clean up temporary files
        shutil.rmtree(output_folder, ignore_errors=True)

        # Check if OCR results are empty
        # if not combined_ocr_results:
        #     raise ValueError("OCR failed to extract text from the document. No data to index.")

        return combined_ocr_results,has_text
    else:
        print(f"Document contains sufficient text. Skipping OCR.")



    # Combine chunks by page for normal text documents
    img_docs = []
    if has_text:
        if img_there:
            files = os.listdir(temp_image_path)  
            for j,i in enumerate(files):
                # print(j,i)
                print("##loading")
                match = re.search(pattern, i)
                if match:
                    pageno = match.group(1)
                img_info, img_token_info = img_summary(os.path.join(temp_image_path, i))
                ###testing###### 
                # print(img_info)
                img_doc = Document(img_info, metadata={'source': os.path.basename(path), 'page': pageno})
                # print(img_doc)
                # img_docs = text_splitter.split_documents([img_doc])
                img_docs.extend(text_splitter.split_documents([img_doc]))
                os.remove(os.path.join(temp_image_path, i))
                # print("Img_docs",img_doc,"Img_Docs")
    combined_docs = []
    split_docs_by_page = defaultdict(list)
    img_docs_by_page = defaultdict(list)
    if img_there:
        for img_doc in img_docs:
            # page = img_doc.metadata["page"]
            page = int(img_doc.metadata["page"])
            img_docs_by_page[page].append(img_doc)
            print(f"@@@@@@ Image Document on Page {page}: {img_doc} !!!!!!!")
        # Group chunks by page number
    
    for doc in split_docs:
        # page = doc.metadata["page"]
        page = int(doc.metadata["page"])
        split_docs_by_page[page].append(doc)
        print(f"////// Split Document on Page {page}: {doc} ///////")

        # split_docs_by_page[doc.metadata["page"]].append(doc)
        # print("//////",doc,"///////")

    # Merge chunks sequentially for each page
    # for page_number in sorted(set(map(int, split_docs_by_page.keys())).union(map(int, img_docs_by_page.keys()))):
    # # # for page_number in sorted(set(split_docs_by_page.keys()).union(img_docs_by_page.keys())):
    #     combined_docs.extend(img_docs_by_page[page_number])
    #     combined_docs.extend(split_docs_by_page[page_number])
    #     print(combined_docs)
        
    # for page_number in sorted(map(int, split_docs_by_page.keys())):
    #     combined_docs.extend(split_docs_by_page[page_number])
    all_pages = sorted(set(map(int, split_docs_by_page.keys())).union(map(int, img_docs_by_page.keys())))
    print(f"All Pages to Process: {all_pages}")

    for page_number in all_pages:
        if page_number in img_docs_by_page:
            combined_docs.extend(img_docs_by_page[page_number])
            print(f"Adding Image Docs from Page {page_number}: {img_docs_by_page[page_number]}")
        if page_number in split_docs_by_page:
            combined_docs.extend(split_docs_by_page[page_number])
            print(f"Adding Split Docs from Page {page_number}: {split_docs_by_page[page_number]}")

    return [{"content": chunk.page_content, "page": chunk.metadata["page"]} for chunk in combined_docs], has_text



def upload_chunks_in_batches(search_client, batch):
   for doc in batch:
        result = search_client.upload_documents(documents=batch)
        # search_client.upload_documents(documents=batch)
        #print(f"Title: {doc['title']}, Page: {doc['page_number']}, Content snippet: {doc['content'][:100]}...")


async def create_index(tempvar, user_name):
    container_name_bulk = os.getenv('AZURE_BULK_UPLOAD_CONTAINER_NAME')
    container_name = f"{container_name_bulk}" + user_name
    connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    # connection_string = "DefaultEndpointsProtocol=https;AccountName=sapocopenai;AccountKey=H30mVmhmyKpFmLUkFSKpDO3CUe+jbcG8aGZ8TgCRNTQj5Ac5HB+649BzYypyo9eW0W9BRy9Z0oFr+ASt6hAVYw==;EndpointSuffix=core.windows.net"
    search_service_name = os.getenv("AZURE_SEARCH_SERVICE_NAME")
    search_service_endpoint = f"https://{search_service_name}.search.windows.net"
    # search_api_key ="TBpoXA6at3L38HsBWSRHnZWfstC07Txt7kDulY7ccDAzSeAHslm9"
    search_api_key = os.getenv('AZURE_SEARCH_API_KEY')
    print("231", search_api_key, "search_api_key")
    openai.api_key = os.getenv("OPENAI_API_KEY")
    # index_name = f"{user_name}_index"
    # index_name = f"{user_name.split('@')[0]}-index"
    # index_name = "mparag-index"
    # index_name = f"{user_name.split('@')[0]}-index"
    index_name1 = re.sub(r'[^a-zA-Z0-9]', '', user_name.split('@')[0])
    index_name = f"{index_name1}"
    print(index_name,"Index_Name")
    logger.info(f"index_name in create_index: {index_name}")

    index_client = SearchIndexClient(endpoint=search_service_endpoint, credential=AzureKeyCredential(search_api_key))

    # Check if the index already exists
    index_exists = False
    try:
        index_exists = index_client.get_index(index_name) is not None
    except Exception:
        # Index does not exist, will create a new one
        pass

    # Create the index if it does not exist
    if not index_exists:
        create_search_index(index_name, search_service_endpoint, search_api_key)
                            
    search_client = SearchClient(
        endpoint=search_service_endpoint,
        index_name=index_name,
        credential=AzureKeyCredential(search_api_key)
    )
    container_client = connect_to_blob_storage(container_name, connection_string)
    # print("Hello1")
    blobs = container_client.list_blobs()
    # # print("Hello2")
    # STORAGE_ACCOUNT_NAME="sapocopenai"
    # STORAGE_ACCOUNT_KEY="H30mVmhmyKpFmLUkFSKpDO3CUe+jbcG8aGZ8TgCRNTQj5Ac5HB+649BzYypyo9eW0W9BRy9Z0oFr+ASt6hAVYw=="

    # temp_folder_path = os.path.join("..", "./temp")

    sharepoint_tmp_folder_path = os.path.join("sharepoint_tmp_folder", session['user_name'])
    logger.info(f"sharepoint_tmp_folder_path in create_index: {sharepoint_tmp_folder_path}")
    tempdir = "/home/tempfile"
    system_platform = platform.system()
    if system_platform == "Linux":           
        tempdir = "/home/tempfile"
    elif system_platform == "Windows":
        tempdir = "./tempfile"
    else:
        raise OSError(f"Unsupported platform: {system_platform}")

# Ensure the base tempfile directory exists
    if not os.path.exists(tempdir):
        os.makedirs(tempdir, exist_ok=True)

    # Ensure the user-specific directory exists
    tempdir = os.path.join(tempdir, session['user_name'])
    logger.info(f"tempdir in create_index: {tempdir}")
    # tempdir = os.path.join("tempfile", session['user_name'])

    # Dynamically select the folder based on existence
    selected_folder_path = None

    if  os.path.exists(tempdir):
        selected_folder_path = tempdir
        print(f"Using 'tempfile': {selected_folder_path}")
        temp_folder_path = os.path.join("sharepoint_tmp_folder", session['user_name'])
    elif  os.path.exists(sharepoint_tmp_folder_path):
        selected_folder_path = sharepoint_tmp_folder_path
        print(f"Using 'sharepoint_tmp_folder': {selected_folder_path}")
   
    else:
        print("No temporary folders found.")
        logging.debug("No temporary folders found.")
    # Handle the case where neither folder exists
        selected_folder_path = None  # or raise an exception, return a specific response, etc.

# Proceed with file processing if a folder was found
    if selected_folder_path:
        # Add your file processing logic here
        print(f"Processing files in: {selected_folder_path}")
        logger.info(f"Processing files in: {selected_folder_path}")


    
    # temp_folder_path = "sharepoint_tmp_folder/adeorukhkar@dsi.com"
    # temp_image_path1="./temp_image"
    temp_image_path = os.path.join("./temp_image", session['user_name'])
    os.makedirs(temp_image_path, exist_ok=True)
    for file_name in os.listdir(selected_folder_path):
        print("inside for loop indexcreation")
        file_path = os.path.join(selected_folder_path, file_name)
        print(file_name,"Filename")
        logging.debug("file_name:", file_name, "file_path:", file_path)
        
        # Only process valid files
        if os.path.isfile(file_path):
            container_name = os.getenv('AZURE_BULK_UPLOAD_CONTAINER_NAME')
            # container_name = "bulk-upload-qna"
            user_name = user_name
            title = os.path.splitext(file_name)[0]
            storage_service_name = os.getenv('AZURE_STORAGE_NAME')
            url = f"https://{storage_service_name}.blob.core.windows.net/{container_name}/{user_name}/{title}.pdf"
            #url2 = await generate_previewable_url(container_name,title)
            batch = []

            # Load and split the file into chunks
            # temp_image_path="./temp_image"
            temp_image_path = os.path.join("./temp_image", session['user_name'])
            os.makedirs(temp_image_path, exist_ok=True)
            img_there=False
            print(tempvar,"Tempvar")
            if tempvar:
                img_there=pdf_image(file_path,temp_image_path)
                logging.debug("img_there:", img_there)
            print("****************************390****************************")
            chunks, has_text = await load_and_split_file(file_path,img_there,temp_image_path, tempvar)
            if os.path.exists(os.path.join("temp_image", session['user_name'])):
            # print("yes database folder")
                await asyncio.get_event_loop().run_in_executor(None, shutil.rmtree, os.path.join("temp_image", session['user_name'])) 
            # if os.path.exists(temp_image_path):
            #     try:
            #         # Delete the folder and its contents
            #         shutil.rmtree(temp_image_path)
            #         print(f"Successfully deleted the folder: {temp_image_path}")
            #     except Exception as e:
            #         print(f"Error deleting the folder: {e}")
            # if img_there:
            #     files = os.listdir(temp_image_path)  
            #     for j,i in enumerate(files):
            #         # print(j,i)
            #         match = re.search(pattern, i)
            #         if match:
            #             pageno = match.group(1)
            #         img_info, img_token_info = img_summary(os.path.join(img_path, i))
            #         ###testing###### 
            #         # print(img_info)
            #         img_doc = Document(img_info, metadata={'source': os.path.basename(file), 'page': pageno})
            #         # print(img_doc)
            #         img_docs = text_splitter.split_documents([img_doc])
            

            
           
            print(has_text,"Has_text")
            if has_text :
                for chunk in chunks:
                            page_no = chunk["page"]
                            document = {
                                "id": str(uuid.uuid4()),
                                "content":chunk["content"],
                                "title": title,
                                "url": url,
                                # "page_number": chunk["metadata"].get("page_number", 1)
                                #"page_number": chunk["page_no"],
                                "page_number": {page_no},
                                "page_number": chunk.get("page"),
                                "url": f"{url}#page={page_no}"
                                #"page_number": chunk.metadata.get("page_number", 1)  # Include page number
                                #"page_number": chunk.get("metadata", {}).get("page_number", 1)
                            }
                            batch.append(document)
                            # if len(batch) >= BATCH_SIZE:
                            #    search_client.upload_documents(batch)
                                # batch = []
        logging.debug("print inside indexcreation.py 461 line")

        # Upload any remaining documents in the last batch
        if has_text:
            
            search_client.upload_documents(batch)
            # if batch:
                # upload_chunks_in_batches(search_client, batch)

        # print(f"Processed and indexed file: {blob_name}")

    print(f"Index creation and data upload completed for user {user_name}")

    
class Document:
    def __init__(self, page_content, metadata=None):
        self.page_content = page_content
        self.metadata = metadata if metadata is not None else {}

    def __repr__(self):
        return f"Document(page_content={self.page_content}, metadata={self.metadata})"
    
    def get_page_content(self):
        return self.page_content
