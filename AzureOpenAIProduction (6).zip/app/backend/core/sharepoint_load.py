import os
import json
from pathlib import Path
from dotenv import load_dotenv
import urllib
import json
import logging
import requests
from urllib.parse import parse_qs, urlparse, unquote
import time
import platform

#setting environment
ENV_FILE = os.getenv("ENV_FILE") or ".env_local"
system_platform = platform.system()
if system_platform == "Linux":           
    LOCAL_TMP_FOLDER = f"/home/tempfile/"
elif system_platform == "Windows":
    LOCAL_TMP_FOLDER = f"{Path(__file__).parent.parent.absolute().as_posix()}/tempfile/"
else:
    raise OSError(f"Unsupported platform: {system_platform}")

uplevel_folder = f"{Path(__file__).parent.parent.absolute().as_posix()}/"
env_location = uplevel_folder + ENV_FILE
load_dotenv(env_location)
VERSION =  os.environ["AZURE_OPENAI_API_VERSION"]
SHARE_POINT_DOC = "Shared Documents"
BATCH_SIZE = 40

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.info(f"parent absolute path: {Path(__file__).parent.parent.absolute().as_posix()}")
print(f"parent absolute path: {Path(__file__).parent.parent.absolute().as_posix()}")

class LoadSharePoint:
    conn = None
    site_url = ""
    group_name = ""
    total_files: int = 0
    total_files_size: float = 0.0
    local_tmp_files: list = []
    processed_files: list = []
    user_folder: str
    user_name: str
    logs = []

    def __init__(self, access_token,user_name):
        self.access_token = access_token
        # logger.info(f"Access Token: {access_token}")
        self.base_graph_url = "https://graph.microsoft.com/v1.0"
        self.user_name = user_name
        if (not os.path.exists(LOCAL_TMP_FOLDER)) or (not os.path.isdir(LOCAL_TMP_FOLDER)):
            os.mkdir(LOCAL_TMP_FOLDER)
        self.user_folder = LOCAL_TMP_FOLDER + user_name
        logger.info(f"self.user_folder, LOCAL_TMP_FOLDER in init: {self.user_folder},{LOCAL_TMP_FOLDER}")
        print(f"self.user_folder in init: {self.user_folder}")
        if (not os.path.exists(self.user_folder)) or (not os.path.isdir(self.user_folder)):
             os.mkdir(self.user_folder)
    
    def headers(self):
        """Return authorization headers."""
        return {"Authorization": f"Bearer {self.access_token}", "Content-Type": "application/json"}
    
    def _make_request(self, url, retries=3, backoff=1):
        """Helper function to make API requests with retry and backoff."""
        try:
            response = requests.get(url, headers=self.headers())
            # logger.info(f"Request URL: {url}, Status Code: {response.status_code}")
            if response.status_code == 401:  # Unauthorized 
                logger.error("Unauthorized access. Please check your access token.")
                raise Exception("Unauthorized access. Please check your access token.") 
            if response.status_code == 429:  # Rate limit exceeded
                logger.warning("Rate limit exceeded. Retrying...")
                time.sleep(backoff)  # Backoff before retry
                if retries > 0:
                    return self._make_request(url, retries-1, backoff*2)  # Exponentially increase backoff
                else:
                    raise Exception("Max retries reached due to rate limiting.")
            response.raise_for_status()  # Raise an error for bad HTTP status
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {str(e)}")
            raise
    
    def convert_sharepoint_url(self, sharepoint_url):
        """Normalizes various SharePoint URL formats into a consistent folder path format."""
        parsed_url = urlparse(sharepoint_url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        path = unquote(parsed_url.path)
        query_params = parse_qs(parsed_url.query)

        logger.info(f"Original SharePoint URL: {sharepoint_url}")

        # Case 1: Links like /:f:/r/Shared Documents/... (deep links)
        if ":f:/r/" in path:
            clean_path = path.split(":f:/r/")[-1]
            clean_path = clean_path.split("?")[0]  # Remove any query params
            logger.info(f"Decoded ':f:/r/' path: {clean_path}")
            return f"{base_url}/{clean_path}"

        # Case 2: AllItems.aspx with query params
        if parsed_url.path.endswith("AllItems.aspx"):
            if 'id' in query_params:
                folder_path = unquote(query_params['id'][0])
                logger.info(f"Folder path from 'id' query param: {folder_path}")
                return f"{base_url}{folder_path}"
            elif 'RootFolder' in query_params:
                folder_path = unquote(query_params['RootFolder'][0])
                logger.info(f"Folder path from 'RootFolder' query param: {folder_path}")
                return f"{base_url}{folder_path}"
            else:
                path_segments = path.strip("/").split("/")
                try:
                    idx = path_segments.index("teams") if "teams" in path_segments else path_segments.index("sites")
                    inferred_path = "/".join(path_segments[:idx + 3])  # site + doclib
                    logger.info(f"Inferred path from AllItems.aspx (no query param): {inferred_path}")
                    return f"{base_url}/{inferred_path}"
                except Exception as e:
                    logger.warning(f"Could not parse AllItems.aspx without 'id' or 'RootFolder': {e}")
                    return sharepoint_url


        # Case 3: AllItems.aspx *without* query param, try to infer
        if parsed_url.path.endswith("AllItems.aspx"):
            path_segments = path.strip("/").split("/")
            try:
                idx = path_segments.index("teams") if "teams" in path_segments else path_segments.index("sites")
                inferred_path = "/".join(path_segments[:idx + 3])  # site + doclib
                logger.info(f"Inferred path from AllItems.aspx: {inferred_path}")
                return f"{base_url}/{inferred_path}"
            except Exception as e:
                logger.warning(f"Could not parse AllItems.aspx without 'id': {e}")
                return sharepoint_url

        # Case 4: Trailing /Forms/ or /Forms/AllItems.aspx without query
        if "/Forms/" in path:
            try:
                trimmed_path = path.split("/Forms/")[0]
                logger.info(f"Trimmed /Forms/ from path: {trimmed_path}")
                return f"{base_url}{trimmed_path}"
            except Exception as e:
                logger.warning(f"Error trimming /Forms/: {e}")
                return sharepoint_url

        # Default case: return original (already clean)
        logger.info(f"Returning cleaned path: {sharepoint_url}")
        return sharepoint_url
    
    def extract_details(self, sharepoint_url):
        """Extracts site, drive, and folder information from a SharePoint URL."""
        try:
            converted_url = self.convert_sharepoint_url(sharepoint_url)
            parsed_url = urlparse(converted_url)
            path_segments = parsed_url.path.strip("/").split("/")

            logger.info(f"Parsed URL Netloc: {parsed_url.netloc}")
            logger.info(f"Path Segments: {path_segments}")

            # Identify if URL is from 'sites' or 'teams'
            if "teams" in path_segments:
                base_key = "teams"
            elif "sites" in path_segments:
                base_key = "sites"
            else:
                raise ValueError(f"Unrecognized SharePoint URL format: {sharepoint_url}")

            base_idx = path_segments.index(base_key)
            drive_keywords = ["Shared Documents", "Documents"]

            # Find where drive (library) starts
            drive_idx = next((i for i, segment in enumerate(path_segments) if segment in drive_keywords), None)
            if drive_idx is None:
                raise ValueError("Drive (e.g., 'Shared Documents') not found in path")

            # Everything between 'sites'/'teams' and drive is nested site path
            site_path_segments = path_segments[base_idx + 1:drive_idx]
            if not site_path_segments:
                raise ValueError("Site path segments could not be determined.")

            site_url_segment = f"/{base_key}/{'/'.join(site_path_segments)}"
            drive_name = path_segments[drive_idx]

            # Anything after drive = folder path inside library
            folder_path = "/".join(path_segments[drive_idx + 1:]) if len(path_segments) > drive_idx + 1 else ""

            if not folder_path:
                logger.info("No folder path found — defaulting to 'root'")
                folder_path = "root"

            self.folder_path = folder_path
            logger.info(f"Extracted Site URL Segment: {site_url_segment}")
            logger.info(f"Drive Name: {drive_name}")
            logger.info(f"Folder Path: {folder_path}")

            site_id = self.get_site_id(site_url_segment)
            drive_id = self.get_drive_id(site_id)

            return site_id, drive_id, folder_path

        except Exception as e:
            logger.error(f"Error extracting SharePoint details: {str(e)}")
            raise
    
    def get_site_id(self, site_url_segment):
        """Fetch the Site ID from the domain and site name."""
        try:
            url = f"https://graph.microsoft.com/v1.0/sites/dsg2ic.sharepoint.com:{site_url_segment}"
            # logger.info(f"Fetching Site ID from URL: {url}")
            response = self._make_request(url)
            # print("Response:", response)
            if 'id' not in response:
                raise ValueError(f"Site ID not found for {site_url_segment}")

            site_id = response["id"] # Extracting second part of the ID
            logger.info(f"Extracted Site ID: {site_id}")
            return site_id
        except Exception as e:
            logger.error(f"Error fetching Site ID: {str(e)}")
            raise
    
    def get_drive_id(self, site_id):
        """Fetch the Drive ID for a given site."""
        try:
            url = f"{self.base_graph_url}/sites/{site_id}/drive"
            response = self._make_request(url)
            
            drive_id = response.get("id")
            if not drive_id:
                raise ValueError("Drive ID not found")
            logger.info(f"Extracted Drive ID: {drive_id}")
            return drive_id
        except Exception as e:
            logger.error(f"Error fetching Drive ID: {str(e)}")
            raise

    def get_folder_id_recursive(self, site_id, drive_id, folder_path):
        """Get folder ID directly using the folder path."""
        try:
            # No folder path means we're targeting the root
            if not folder_path or folder_path.lower() == "root":
                url = f"{self.base_graph_url}/sites/{site_id}/drives/{drive_id}/root"
                print(f"Fetching root folder ID from URL")
            else:
                # Clean and encode the folder path
                folder_path = folder_path.strip('/')
                encoded_path = urllib.parse.quote(folder_path)
                url = f"{self.base_graph_url}/sites/{site_id}/drives/{drive_id}/root:/{encoded_path}"
                print(f"Fetching encodeded folder ID from URL")
            
            logger.info(f"Fetching folder ID from URL: {url}")
            # Make the request
            response = self._make_request(url)
            
            # Extract and return the folder ID
            if response and "id" in response:
                return response["id"]
            else:
                raise Exception(f"Folder '{folder_path}' not found or not accessible!")
                
        except Exception as e:
            logger.error(f"Error getting folder ID: {str(e)}")
            raise
        

    def get_files_in_folder(self, site_id, drive_id, folder_id):
        """Retrieve all files in a given folder."""
        try:
            url = f"{self.base_graph_url}/sites/{site_id}/drives/{drive_id}/items/{folder_id}/children"
            # logger.info(f"URL final: {url}")
            response = self._make_request(url)

            # Supported file extensions
            allowed_extensions = {'.pdf', '.txt', '.docx', '.pptx'}

            result = []
            for item in response.get("value", []):
                if "folder" in item:
                    # Always include folders
                    result.append({
                        "name": item["name"],
                        "size": item.get("size", 0),
                        "id": item["id"],
                        "type": "folder"
                    })
                else:
                    # It's a file — check extension
                    name_lower = item["name"].lower()
                    if any(name_lower.endswith(ext) for ext in allowed_extensions):
                        result.append({
                            "name": item["name"],
                            "size": item.get("size", 0),
                            "id": item["id"],
                            "type": "file"
                        })

            return result
        except Exception as e:
            logger.error(f"Error fetching files from folder: {str(e)}")
            raise

    def get_folder_entity_list(self, site_id, drive_id, folder_id=None):
        """
        Retrieves files and folders from a given SharePoint folder path using Microsoft Graph API.
        Adds folder count and total size (sum of files) in KB.
        """
        return_data = {}

        try:
            # Ensure we have a valid folder_id
            print(f"folder_id in get_folder_entity_list: {folder_id}")
            items = self.get_files_in_folder(site_id, drive_id, folder_id)
            data = []

            for item in items:
                item_type = item["type"]
                item_name = item["name"]
                item_size = item.get("size", 0)
                item_id = item["id"]
                if item_type == "folder":
                    # Fetch subfolder contents (count of entities & total file size)
                    subfolder_items = self.get_files_in_folder(site_id, drive_id, item_id)
                    # Skip folder if it has 0 items
                    if not subfolder_items:
                        continue
                    
                    # Check if subfolder has at least one file
                    contains_file = any(sf.get('type') == 'file' for sf in subfolder_items)
                    if not contains_file:
                        continue
                    entity_count = sum(1 for sf in subfolder_items if sf.get('type') == 'file')
                    # Sum sizes of files in subfolder
                    total_size_bytes = sum(
                        sf.get('size', 0)
                        for sf in subfolder_items
                        if sf.get('type') == 'file'
                    )
                    total_size_kb = round(total_size_bytes / 1024, 2)

                    
                    data.append(
                        self.fill_json_entity_data(
                            name=item_name,
                            type="folder",
                            id=item_id,
                            count=entity_count,
                            total_size_kb=total_size_kb
                        )
                    )
                else:
                    # File size in KB
                    size_kb = f"{round(item_size / (1024), 2)} KB"
                    data.append(
                        self.fill_json_entity_data(
                            name=item_name,
                            type="file",
                            id=item_id,
                            size_kb=size_kb
                        )
                    )

            return_data["status"] = True
            return_data["message"] = "Files and folders retrieved successfully."
            return_data["data"] = data

        except ValueError as ve:
            return_data["status"] = False
            return_data["message"] = f"ValueError: {str(ve)}"
        except Exception as e:
            return_data["status"] = False
            return_data["message"] = f"Unexpected error: {str(e)}"

        return json.dumps(return_data)
    
    
    def fill_json_entity_data(self, 
                              name: str,
                              type: str, 
                              id: str,
                              count: int = None, 
                              size_kb: float = None, 
                              total_size_kb: float = None) -> dict:
        data = {
            "name": name,
            "id": id,
            "type": type
        }
        if type == "folder":
            if count is not None:
                data["count"] = count  # Number of entities in the folder
            if total_size_kb is not None:
                data["total_size_kb"] = total_size_kb  # Total size of files in KB
        elif type == "file" and size_kb is not None:
            data["size_kb"] = size_kb  # File size in KB

        return data

    def process_sharepoint_folder(self,site_id,drive_id, folder_id: str, checked_files: list = [], checked_folders: list = []):
        try:
            logger.info(f"process sharepoint folder entry")
            self.save_files_to_local(site_id, drive_id, checked_files,checked_folders)
                        
            return {"status": True, "message": "Processing completed successfully"}
        
        except Exception as e:
            return {"status": False, "error": f"Error processing folder (ID: {folder_id}). Exception: {str(e)}"}
    

    def save_files_to_local(self, site_id, drive_id, checked_files: list = [], checked_folders: list = []):
            """Downloads selected SharePoint files and files from selected folders (excluding subfolders)."""
            print("Saving files to local...")
            error_message = ""

            # Ensure processed_files exists
            if not hasattr(self, "processed_files"):
                self.processed_files = []

            if checked_files:
                for file in checked_files:
                    try:
                        logger.info(f"Processing file from checked_files: {file}")
                        self.download_file(site_id, drive_id, file)
                        logger.info(f"Successfully downloaded: {file}")
                    except Exception as e:
                        logger.error(f"Error downloading file {file}: {e}")
            else:
                logger.info("No checked files to process.")              

            logger.info(f"outside the for loop of checked files")

            # ✅ Process checked folders (fetch only files inside them)
            if checked_folders:
                for folder in checked_folders:
                    folder_id = folder["id"]
                    folder_name = folder["name"]
                    logger.info(f"Processing folder: {folder_name} (ID: {folder_id})")

                    try:
                        folder_contents = self.get_folder_entity_list(site_id, drive_id, folder_id)
                        folder_contents = json.loads(folder_contents)  # Ensure JSON response is parsed
                        formatted_response = json.dumps(folder_contents, indent=4)
                        logger.info(f"Files and folders retrieved successfully from checked folder:\n{formatted_response}")

                        if folder_contents["status"]:
                            files_in_folder = [item for item in folder_contents["data"] if item["type"] == "file"]
                            logger.info(f"Files in folder {folder_name}: {files_in_folder}")

                            for file in files_in_folder:
                                self.download_file(site_id, drive_id, file)
                                logger.info(f"file in folder {folder_name} in save_files_to local: {file}")

                    except Exception as e:
                        error_message = f"Error fetching files from folder {folder_name}: {str(e)}"
                        print(error_message)

    def download_file(self, site_id, drive_id, file):
        """Helper function to download a single file."""
        print("Downloading file:", file)
        file_name = file["name"]
        file_id = file["id"]
        file_url = f"{self.base_graph_url}/sites/{site_id}/drives/{drive_id}/items/{file_id}/content"
        local_file_path = os.path.join(self.user_folder, file_name)

        try:
            response = requests.get(file_url, headers=self.headers(), stream=True, timeout=30)
            response.raise_for_status()

            with open(local_file_path, 'wb') as f:
                logger.info(f"local_file_path in with: {local_file_path}")
                print(f"local_file_path in with: {local_file_path}")
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            self.local_tmp_files.append({
                "name": file_name, "url": file_url, "type": "file", "local_name": file_name
            })

            if len(self.local_tmp_files) >= BATCH_SIZE:
                self.insert_files_to_rag()

        except Exception as e:
            self.processed_files.append({
                "name": file_name, "url": file_url, "type": "file",
                "status": False, "error": str(e)
            })