import fitz 
import io
from PIL import Image
import openai
import base64
import hashlib
# import cv2
import numpy as np
import hashlib
import subprocess
import aspose.words as aw
from docx import Document
from pptx import Presentation
import os
# from win32com import client
import time


from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

import queue
from spire.doc import *
from spire.doc.common import *
import pdfplumber
from PIL import Image
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTImage, LTFigure
# from docx import Document
# from docx.shared import Inches
# # from queue import Queue
# from docx.oxml.ns import qn
# from docx.oxml import OxmlElement
import os
from collections import defaultdict
from docx2pdf import convert


img_present = False
# def save_and_fix_image(lt_image, page_no, img_index, img_path):
#     # if not lt_image.stream:
#     #     return False

#     try:
#         # Extract raw image data
        
#         image_array = np.frombuffer(lt_image, np.uint8)
#         image = cv2.imdecode(image_array, cv2.IMREAD_UNCHANGED)

#         if image is None:
#             print(f"OpenCV could not decode the image on page {page_no + 1}, index {img_index + 1}.")
#             return False

#         # Save the image
#         image_name = f"pageno_{page_no + 1}_{img_index + 1}.png"
#         image_path = os.path.join(img_path, image_name)
#         cv2.imwrite(image_path, image)
#         return True

#     except Exception as e:
#         print(f"Failed to save image on page {page_no + 1}, index {img_index + 1}: {e}")
#         return False


def pdf_image(file_path, img_path):
    seen_hashes = set()
    img_present = False
    # subprocess.run(['pandoc', file_path, '-o', file_path,--pdf-engine=pdflatex'], check=True)
    # subprocess.run(['pandoc', file_path, '-o', img_path, '--pdf-engine=pdflatex'], check=True)
    # subprocess.run(['pandoc', file_path, '-o', img_path, '--pdf-engine=pdflatex'], check=True)
    # print(f"Converted {file_path} to {file_path}")
    # doc = aw.Document(file_path)
    
    # Split each page into a separate .docx or .pdf file
    # for i in range(doc.page_count):
    #     page = doc.extract_pages(i, 1)  # Extract one page at a time
    #     # page.save(f"{}/page_{i + 1}.docx")  # Save as .docx
    #     page.save(f"{img_path}/page_{i + 1}.pdf")   
    
    file_ext = os.path.splitext(file_path)[1].lower()

    try:
        if file_ext == ".pdf":
            pdf_file = fitz.open(file_path)
            for page_index in range(len(pdf_file)):
                page = pdf_file[page_index]
                image_list = page.get_images(full=True)

                if image_list:
                    img_present = True

                for image_index, img in enumerate(image_list):
                    xref = img[0]
                    base_image = pdf_file.extract_image(xref)
                    image_bytes = base_image["image"]
                    image_ext = base_image["ext"]
                    img_hash = hashlib.md5(image_bytes).hexdigest()

                    if img_hash not in seen_hashes:
                        seen_hashes.add(img_hash)
                        image_name = f"pageno_{page_index+1}_{image_index+1}.{image_ext}"
                        image_path = os.path.join(img_path, image_name)
                        with open(image_path, "wb") as img_file:
                            img_file.write(image_bytes)

        # elif file_ext == ".docx":
        #     # print('entered loop')
        #     # word = client.Dispatch("Word.Application")
        #     # doc = word.Documents.Open(os.path.abspath(file_path))
        #     # print('doc print equals')
        #     # doc.SaveAs(os.path.abspath(img_path), FileFormat=17)  # FileFormat=17 is PDF
        #     # doc.Close()
        #     # word.Quit()
        #     print(f"Converted: {img_path}")

            # doc = Document(file_path)
            # print("Document_Image_extraction")
            # for i, rel in enumerate(doc.part.rels.values()):
            #     if "image" in rel.target_ref:
            #         img_present = True
            #         img_data = rel.target_part.blob
            #         img_hash = hashlib.md5(img_data).hexdigest()

            #         if img_hash not in seen_hashes:
            #             seen_hashes.add(img_hash)
            #             ext = rel.target_ref.split(".")[-1]
            #             image_name = f"word_image_{i+1}.{ext}"
            #             image_path = os.path.join(img_path, image_name)
            #             with open(image_path, "wb") as img_file:
            #                 img_file.write(img_data)

        elif file_ext == ".pptx":
            ppt = Presentation(file_path)
            print("PPT_Image_Extraction")
            for slide_index, slide in enumerate(ppt.slides):
                for shape_index, shape in enumerate(slide.shapes):
                    try :
                        if shape.shape_type == 13 and hasattr(shape, "image"):  # IMAGE shape type
                            img_present = True
                            img = shape.image
                            img_data = img.blob
                            img_hash = hashlib.md5(img_data).hexdigest()

                            if img_hash not in seen_hashes:
                                seen_hashes.add(img_hash)
                                ext = img.ext
                                image_name = f"pageno_{slide_index+1}_{shape_index+1}.{ext}"
                                image_path = os.path.join(img_path, image_name)
                                with open(image_path, "wb") as img_file:
                                    img_file.write(img_data)
                    except AttributeError as e:
                     print(f"Skipping shape on slide {slide_index+1}, shape {shape_index+1}: {str(e)}")                

        else:
            print(f"Unsupported file type: {file_ext}")
            return False

    except Exception as e:
        print(f"Error processing file: {e}")
        return False
    # remove_blank_images(img_path,threshold=5)
    remove_small_images(img_path, min_size=5120)

    return img_present

    # except:
    #     pass
# def pdf_image(file_path, img_path):
#     """
#     Extract images from a PDF using PDFMiner.

#     Args:
#         file_path (str): Full path to the PDF file.
#         img_path (str): Directory where images will be saved.

#     Returns:
#         bool: True if images were found, False otherwise.
#     """
#     img_there = False

#     try:
#         if not os.path.exists(img_path):
#             os.makedirs(img_path)

#         # Extract pages from the PDF
#         for page_no, layout in enumerate(extract_pages(file_path)):
#             img_index = 0
#             for element in layout:
#                 if isinstance(element, LTImage):
#                     img_there |= save_and_fix_image(element, page_no, img_index, img_path)
#                     img_index += 1
#                 elif isinstance(element, LTFigure):
#                     for child in element:
#                         if isinstance(child, LTImage):
#                             img_there |= save_and_fix_image(child, page_no, img_index, img_path)
#                             img_index += 1

#     except Exception as e:
#         print(f"An error occurred during extraction: {e}")
#         img_there = False

#     return img_there          



class PPTExtractor:
    def __init__(self, output_dir):
        self.output_dir = output_dir
        self.n = 1
        self.image_present = False

    def write_image(self, shape, slide_number):
        image = shape.image
        image_bytes = image.blob
        # image_filename = '{}/image{:03d}.{}'.format(self.output_dir, self.n, image.ext)
        image_filename = '{}/pageno_{}_image{:03d}.{}'.format(self.output_dir, slide_number, self.n, image.ext)
        self.n += 1
        print(image_filename)
        with open(image_filename, 'wb') as f:
            f.write(image_bytes)

    def visitor(self, shape, slide_number):
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            for s in shape.shapes:
                self.visitor(s, slide_number)
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            self.image_present = True
            self.write_image(shape, slide_number)

    def iter_picture_shapes(self, prs):
        self.image_present = False 
        for slide_number, slide in enumerate(prs.slides, start=1):
        # for slide in prs.slides:
            for shape in slide.shapes:
                self.visitor(shape, slide_number)
        return self.image_present
    
def docx_image(file_path, img_path):
    try:
        document = Document()
        document.LoadFromFile(file_path)
        images = []

        nodes = queue.Queue()
        nodes.put(document)

        while not nodes.empty():
            node = nodes.get()
            for i in range(node.ChildObjects.Count):
                obj = node.ChildObjects[i]
                # Find the images
                if isinstance(obj, DocPicture):
                    picture = obj
                    # Append the image data to the list
                    data_bytes = picture.ImageBytes
                    images.append(data_bytes)
                elif isinstance(obj, ICompositeObject):
                    nodes.put(obj)
        for i, image_data in enumerate(images):
            file_name = f"Image-{i}.png"
            with open(os.path.join(img_path, file_name), 'wb') as image_file:
                image_file.write(image_data)

        document.Close()
        if len(images) > 0:
            image_flag = True
        return image_flag
    except:
        pass

# def docx_image(file_path, img_path):
#     try:
#         document = Document(file_path)
#         images = defaultdict(list)
#         image_flag = False

#         # Track the page number by inserting a page break and counting
#         page_number = 1

#         for rel in document.part.rels.values():
#             if "image" in rel.target_ref:
#                 image = rel.target_part
#                 image_data = image.blob
#                 images[page_number].append(image_data)

#         # Save the images with page numbers
#         for page_num, image_list in images.items():
#             for i, image_data in enumerate(image_list):
#                 file_name = f"Page{page_num}_Image-{i}.png"
#                 with open(os.path.join(img_path, file_name), 'wb') as image_file:
#                     image_file.write(image_data)

#         if images:
#             image_flag = True
#         return image_flag
#     except Exception as e:
#         print(f"An error occurred: {e}")
#         return False

# def docx_image(file_path, img_path):
#     try:
#         pdf_path = os.path.splitext(file_path)[0] + ".pdf"
#         convert(file_path, pdf_path)
#         pdf_image(pdf_path, img_path)
#         os.remove(pdf_path)
#         files = os.listdir(img_path) 
#         if len(files)>0:
#             image_flag = True
#         return image_flag
#     except:
#         pass
# def remove_blank_images(directory, threshold=10):
#     for filename in os.listdir(directory):
#         filepath = os.path.join(directory, filename)
#         try:
#             img = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
#             if img is not None:
#                 if np.std(img) < threshold:  # Low variance indicates a blank image
#                     os.remove(filepath)
#                     print(f"Removed blank image: {filepath}")
#         except Exception as e:
#             print(f"Error processing {filepath}: {e}")
def remove_small_images(directory, min_size=5120):  # min_size in bytes
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        if os.path.isfile(filepath) and os.path.getsize(filepath) < min_size:
            os.remove(filepath)
            print(f"Removed: {filepath}")            

def img_summary(img_path):
    try:
        base64_image = encode_image(img_path)
        # print("here******47")
        openai.api_type = "azure"
        # openai.api_key = "5d69dd6f0aa14121ae81066435443abf"
        openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
        # openai.api_base = "https://openai-poc-east.openai.azure.com/"
        AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
        openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
        openai.api_version = "2024-02-15-preview"
        # print("here******52")
        response = openai.ChatCompletion.create(
                    deployment_id="GPT4o",
                    messages=[
                        {"role": "system", "content": "Act as an Image Analyzer"},
                        {"role": "user", "content": [
                            {"type": "text", "text": "Generate information that is described in the image."},
                            {"type": "image_url", "image_url": {
                                "url": f"data:image/png;base64,{base64_image}"}
                            }
                        ]}
                    ],
                    temperature=0.0,
                    )
        # print(response['choices'][0]['message']['content'])
        # print("here******66")
        if (len(response['choices'][0]['message']['content'])>0) and (response["usage"]["total_tokens"] > 0):
            return(response['choices'][0]['message']['content'], response["usage"]["total_tokens"])
        else:
            return "", 0
    except:
        return "", 0
        pass
    #     return("""You might have asked something out of the context with the uploaded data, If not please be more specific in the input asked""", 0)
    
def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8") 