import os
import time
import fitz 
import shutil
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes
from msrest.authentication import CognitiveServicesCredentials
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter

count = 0

class scannned_document:

    async def split_pdf_into_images(self, pdf_document, output_folder):
        """
        Splits each page of the PDF into an image.

        Args:
            pdf_document (str): Path to the PDF file.
            output_folder (str): Folder to save the output images. Default is 'images'.
            image_format (str): Format of the output images (e.g., 'png', 'jpeg'). Default is 'png'.

        Returns:
            None
        """
        image_format='png'
        # Open the PDF file
        doc = fitz.open(pdf_document)
        
        # Create the output folder if it doesn't exist
        import os
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Iterate over each page in the PDF
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)  # Load page
            pix = page.get_pixmap()         # Render page to an image
            output_image = os.path.join(output_folder, f"page_{page_num + 1}.{image_format}")
            pix.save(output_image)          # Save image
            print(f"Saved {output_image}")

        doc.close()

    def extract_text_from_image(self, image_path):
            subscription_key = os.getenv("AZURE_COMPUTER_VISION_SUBSCRIPTION_KEY")
            endpoint = os.getenv("AZURE_COMPUTER_VISION_ENDPOINT")

            computervision_client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))

            with open(image_path, "rb") as image_stream:
                ocr_result = computervision_client.read_in_stream(image_stream, raw=True)

            operation_location = ocr_result.headers["Operation-Location"]
            operation_id = operation_location.split("/")[-1]

            while True:
                result = computervision_client.get_read_result(operation_id)
                if result.status not in ['notStarted', 'running']:
                    break
                time.sleep(1)

            extracted_text = ""
            if result.status == OperationStatusCodes.succeeded:
                read_results = result.analyze_result.read_results
                for analyzed_result in read_results:
                    for line in analyzed_result.lines:
                        extracted_text += line.text + "\n"

            return extracted_text.strip()
    

    async def create_vstore(self, pdf_document, output_folder, user_name):
        global count
        AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY_East")
        AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE_East")
        openai_api_type = "azure"
        openai_api_version = "2023-12-01-preview"  
        openai_api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com" 
        openai_api_key = AZURE_OPENAI_API_KEY
        embeddings = OpenAIEmbeddings(openai_api_base = openai_api_base,
                                openai_api_type = "azure",
                                openai_api_key=openai_api_key, 
                                openai_api_version = openai_api_version, 
                                deployment="text-embedding-ada-002"
                                    )
        text_splitter = RecursiveCharacterTextSplitter(chunk_size = 1000, chunk_overlap  = 200)

        document = []
        vector_dict ={}

        await self.split_pdf_into_images(pdf_document, output_folder)
        files = os.listdir(output_folder)

        for j, i in enumerate(files):
            img_info = self.extract_text_from_image(os.path.join(output_folder,i))
            # print(img_info)
            img_doc = Document(img_info, metadata={'source': os.path.basename(pdf_document), 'page': os.path.splitext(os.path.basename(i))[0]})
            # print(img_doc)
        #     document.append(img_doc)
            img_docs = text_splitter.split_documents([img_doc])
            vector_dict[f"vector_store_{j}"] = FAISS.from_documents(documents=img_docs, embedding=embeddings)
            if j == 0:
                vector_store = vector_dict[f"vector_store_{j}"]
            else:
                vector_store.merge_from(vector_dict[f"vector_store_{j}"])

            time.sleep(1)
        
        path = os.path.join("vector_stored", user_name, f"faiss_index_scanned_{count}")
        vector_store.save_local(path)

        if os.path.exists(output_folder):
            shutil.rmtree(output_folder)
            print(f"Directory '{output_folder}' and all its contents have been removed.")
        else:
            print(f"Directory '{output_folder}' does not exist.")

        count += 1


class Document:
    def __init__(self, page_content, metadata=None):
        self.page_content = page_content
        self.metadata = metadata if metadata is not None else {}

    def __repr__(self):
        return f"Document(page_content={self.page_content}, metadata={self.metadata})"
    
    def get_page_content(self):
        return self.page_content
    

# Example usage:
# split_pdf_into_images("your_pdf_file.pdf")
