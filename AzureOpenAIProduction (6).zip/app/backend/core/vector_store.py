import openai
import os
import pandas as pd
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import UnstructuredPDFLoader, PyPDFLoader
from langchain.document_loaders import TextLoader
from langchain.document_loaders import Docx2txtLoader
from langchain.document_loaders import UnstructuredPowerPointLoader
import logging
import os
import tiktoken
from .dblogger import log_api_response
from datetime import datetime, timedelta
from typing import Any, AsyncGenerator
from quart import session
 
from .img_extractor import pdf_image
from .img_extractor import img_summary
from .img_extractor import PPTExtractor
from .img_extractor import docx_image
# from docx2pdf import convert
 
import asyncio
import shutil
import time
import re
from pptx import Presentation
import nltk
nltk.download('punkt')
import json
 
 
count = 0
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

async def create_vectorstore(file, user_name, file_url):
    AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY_East")
    AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE_East")
    openai_api_type = "azure"
   # openai_api_version = "2023-03-15-preview"
    openai_api_version = "2023-12-01-preview"  
    openai_api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
    openai_api_key = AZURE_OPENAI_API_KEY
    embeddings = OpenAIEmbeddings(openai_api_base = openai_api_base,
                              openai_api_type = "azure",
                              openai_api_key=openai_api_key,
                              openai_api_version = openai_api_version,
                              deployment="text-embedding-ada-002",
                              #chunk_size = 1,
                            #   max_retries = 0)
                                )
    doc_flag = False
 
    if file.endswith('.pdf'):
        loader = PyPDFLoader(file)
        doc = loader.load()
 
    if file.endswith('.txt'):
        # loader = TextLoader(file)
        # doc = loader.load()
        pdf_path = convert_docx_to_pdf(file, None)
        logging.debug("pdf_path", pdf_path)
        loader = PyPDFLoader(pdf_path)
        # print(loader, "loader")
        doc = loader.load()
        # print(doc, "doc")
 
    if file.endswith('.docx'):
        # loader = Docx2txtLoader(file)
        # doc = loader.load()
             
        # Save the uploaded DOCX file
        # docx_path = os.path.join('./tempfile', file.filename)
        # print("docx_path created successfully")
        # await file.save(docx_path)
       
        # Convert DOCX to PDF
        # pdf_filename = session['user_name'] + "/" + file.split('\\')[-1] + '.pdf'
        # # pdf_filename = pdf_filename.replace('.docx')
        # pdf_path = os.path.join('./tempfile', session['user_name'], pdf_filename)
        # print("pdf_path created successfully")
        #         # Convert using docx2pdf (recommended)
        # print(pdf_path, file.split('\\')[-1], file)
        # convert(file, pdf_path)
        # print("File converted successfully")
 
       
        # loader = PyPDFLoader(pdf_path)
        # doc = loader.load()
 
        doc_flag = True
        # pdf_path = os.path.splitext(file)[0] + ".pdf"
        # convert(file, pdf_path)
        # os.remove(file)
        # file = pdf_path
        # print(pdf_path, "pdf_path")
        # print("filename")
        # print(file, "file before convert")
        # pdf_path = os.path.splitext(file)[0] + ".pdf"
        pdf_path = convert_docx_to_pdf(file, None)
        # convert_docx_to_pdf(file, pdf_path)
        # os.remove(file)
        # print(file, "file after convert")
        # print(pdf_path, "pdf_path")
        logging.debug("pdf_path", pdf_path)
        loader = PyPDFLoader(pdf_path)
        # print(loader, "loader")
        doc = loader.load()
        # print(doc, "doc")
        pdf_file_path = os.path.splitext(file)[0] + ".pdf"
        if os.path.exists(file):
            os.remove(file)
        file = pdf_file_path
 
    if file.endswith('.pptx'):
        # loader = UnstructuredPowerPointLoader(file)
        # doc = loader.load()
        # doc = []
        # slides = extract_slide_content_with_numbers(file)
        # for i in slides:
        #     ppt_doc = Document(i['content'], metadata={'source': os.path.basename(file), 'page': i["slide_number"]})
        #     doc.append(ppt_doc)
        pdf_path = convert_docx_to_pdf(file, None)
        logging.debug("pdf_path", pdf_path)
        loader = PyPDFLoader(pdf_path)
        # print(loader, "loader")
        doc = loader.load()
        # print(doc, "doc")
       
    # for j, i in enumerate(doc):
    #     try:
    #         if file.endswith(".pdf"):
    #             page_number = i.metadata["page"]
    #             # print(page_number, "page_number")
    #             page_number = page_number + 1
    #             pdf_url_with_page = f"{file_url}#page={page_number}"
    #             # print(pdf_url_with_page, "pdf_url_with_page")
    #             i.metadata["page"] = pdf_url_with_page
    #             i.metadata["source"] = file_url
    #     except:
    #         pass
   
    if file.endswith(".pdf"):
        outer_dict = {}
        for j, i in enumerate(doc):
            page_no = i.metadata["page"] + 1
            inner_dict = {"content" : i.page_content, "source_url": file_url, "page_url" : f"{file_url}#page={page_no}"}
            outer_dict[page_no] = inner_dict
            print("outer_dict",outer_dict)
       
        os.makedirs(os.path.join("temp_dir_2", user_name), exist_ok=True)
        with open(f'./temp_dir_2/{user_name}/{os.path.basename(os.path.splitext(file)[0] + ".json")}', 'w') as json_file:
            json.dump(outer_dict, json_file)
 
   # print("Doc Created")
    global count
    count += 1
    index_flag = False
 
    text_splitter = RecursiveCharacterTextSplitter(chunk_size = 1000, chunk_overlap  = 200)
    docs = text_splitter.split_documents(doc)
    # print("************************splitter****************************")
    # print(docs[0], "docs[0] 127")
    # print(docs, "docs 128")
    # print(doc, "doc 128")
 
    for j, i in enumerate(docs):
        try:
            if file.endswith(".pdf"):
                page_number = i.metadata["page"]
                # print(page_number, "page_number")
                page_number = page_number + 1
                pdf_url_with_page = f"{file_url}#page={page_number}"
                # print(pdf_url_with_page, "pdf_url_with_page")
                i.metadata["page"] = pdf_url_with_page
                i.metadata["source"] = file_url
 
            #     if (j == 0) and (i.metadata["page"] == 0):
            #         index_flag = True
            #     if index_flag:
            #         i.metadata["page"] = i.metadata["page"] + 1
            #     if doc_flag:
            #         i.metadata["source"] = os.path.basename(os.path.splitext(file)[0] + ".docx")
            #     else:
            #         i.metadata["source"] = os.path.basename(file)
 
            if file.endswith(".txt"):
                i.metadata["source"] = os.path.basename(file)
        except:
            pass
 
    vector_store_doc = FAISS.from_documents(documents=docs, embedding=embeddings)
 
    # print("Docs created", docs)
   
    timestamp = datetime.now()
    # enc = tiktoken.encoding_for_model("text-embedding-ada-002")
    input_str = ""
    for i in range(len(docs)):
        input_str = input_str + docs[i].page_content
 
    Docs = []
    ## Checking if image present and extracting information
    img_flag = False
    tempdir = "./tempfile"
    img_desc = ""
    img_tokens = 0
    pattern = r"pageno_(\d+)"
    pageno = ""
    vector_dict = {}
 
    os.makedirs(os.path.join(tempdir, session['user_name'],"images"), exist_ok=True)
    img_path = os.path.join(tempdir, session['user_name'],"images")
   
    if file.endswith('.pdf'):
        img_flag = pdf_image(file, img_path)
   
    elif file.endswith('.pptx'):
        prs = Presentation(file)
        extractor = PPTExtractor(img_path)
        img_flag = extractor.iter_picture_shapes(prs)
 
    elif file.endswith('.docx'):
        img_flag = docx_image(file, img_path)
 
    print(img_flag)
    start_time = time.time()
    if img_flag:
        files = os.listdir(img_path)  
        for j,i in enumerate(files):
            # print(j,i)
            match = re.search(pattern, i)
            if match:
                pageno = match.group(1)
            img_info, img_token_info = img_summary(os.path.join(img_path, i))
            ###testing######
            # print(img_info)
            img_doc = Document(img_info, metadata={'source': os.path.basename(file), 'page': pageno})
            # print(img_doc)
            img_docs = text_splitter.split_documents([img_doc])
            vector_dict[f"vector_store_{j}"] = FAISS.from_documents(documents=img_docs, embedding=embeddings)
            # print(img_docs)
            if j == 0:
                vector_store = vector_dict[f"vector_store_{j}"]
            else:
                vector_store.merge_from(vector_dict[f"vector_store_{j}"])
 
            img_desc = img_desc + img_info
            img_tokens = img_tokens + img_token_info
            # print(img_desc)
            # print(img_tokens, "*********************** Tokens Consumed *******************************")
 
    shutil.rmtree(img_path)
    end_time = time.time()
    print("************************************************************************************************")
    # print(end_time - start_time)
 
    input_str += img_desc
    print("*******************************************************")
    # print(input_str)
    enc = tiktoken.encoding_for_model("text-embedding-ada-002")
    embedding_tokens = len(enc.encode(input_str))
   # print("embedding_tokens", embedding_tokens)
    # await log_api_response(user=session['user_name'],input_timestamp=timestamp,api='ai-gen',model_name="text-embedding-ada-002",token=embedding_tokens)
 
    print("image_text_extracted")
    # if img_desc:
    #     img_doc = Document(img_desc, metadata={'source': file, 'page': 0})
    #     print(img_doc)
    #     print("img_doc_created_120")
    #     concatenated_docs = concatenate_documents(doc, [img_doc])
    #     print("doc_concatenated")
    #     print(concatenated_docs, type(concatenated_docs))
    #     text_splitter = RecursiveCharacterTextSplitter(chunk_size = 1000,chunk_overlap  = 200)
    #     docs = text_splitter.split_documents([concatenated_docs])
 
    print("img_document_created")
    # vector_store = FAISS.from_documents(documents=docs, embedding=embeddings)
 #   print("vector_store created", vector_store)
    path = os.path.join("vector_stored", user_name, "faiss_index_{}".format(count))
 
    if img_flag:
        vector_store.merge_from(vector_store_doc)
        vector_store.save_local(path)
    else:
        vector_store_doc.save_local(path)
 
    if doc_flag:
        os.remove(file)
 
def extract_slide_content_with_numbers(pptx_path):
    presentation = Presentation(pptx_path)
    slide_data = []
 
    for i, slide in enumerate(presentation.slides):
        slide_number = i + 1
        slide_content = ""
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                slide_content += shape.text + "\n"
            elif shape.shape_type == 19:  # Shape type 19 corresponds to a table
                table = shape.table
                for row in table.rows:
                    for cell in row.cells:
                        slide_content += cell.text + "\t"
                    slide_content += "\n"
        slide_data.append({
            "slide_number": slide_number,
            "content": slide_content.strip()
        })
 
    return slide_data
 
class Document:
    def __init__(self, page_content, metadata=None):
        self.page_content = page_content
        self.metadata = metadata if metadata is not None else {}
 
    def __repr__(self):
        return f"Document(page_content={self.page_content}, metadata={self.metadata})"
   
    def get_page_content(self):
        return self.page_content
   
def concatenate_documents(doc1, doc2):
    try:
        # print(doc1)
 
        print("doc2")
 
        # print(doc2)
        new_page_content = doc1[0].page_content + " " + doc2[0].page_content
        new_metadata = {}
        return Document(new_page_content, new_metadata)
    except Exception as e:
        print(e)
 
import os
import subprocess
import platform
 
def convert_docx_to_pdf(docx_file_path, output_dir=None):
    try:
    # Ensure the input file exists
        if not os.path.isfile(docx_file_path):
            raise FileNotFoundError(f"The file {docx_file_path} does not exist")
 
        # If no output directory is provided, use the same directory as the input file
        if output_dir is None:
            output_dir = os.path.dirname(docx_file_path)
       
        # Ensure the output directory exists
        os.makedirs(output_dir, exist_ok=True)
 
        # Determine the platform (Linux or Windows)
        system_platform = platform.system()
 
        # Build the command for LibreOffice (soffice)
        if system_platform == "Linux":
            # soffice_cmd = '/home/libreoffice/lib_office/opt/libreoffice24.2/program/soffice'  # Typically the command in Linux
            # soffice_cmd = '/home/libreoffice/lib/program/soffice'
            soffice_cmd = '/home/libreoffice/lib_office/opt/libreoffice24.2/program/soffice'
            # soffice_cmd = '/usr/bin/soffice'
            # soffice_cmd = '/opt/libreoffice24.2/program/soffice'
        elif system_platform == "Windows":
            soffice_cmd = 'C:/Program Files/LibreOffice/program/soffice.exe'
        else:
            raise OSError(f"Unsupported platform: {system_platform}")
 
        logger.info(f"output_dir in convert_docx_topdf: {output_dir}")
        # Output PDF path (same as input file but with .pdf extension)
        output_pdf_path = os.path.join(output_dir, os.path.splitext(os.path.basename(docx_file_path))[0] + ".pdf")
        logger.info(f"output_pdf_path in convert_docx_topdf: {output_pdf_path}")
        abs_docx_file_path = os.path.abspath(docx_file_path)
        logger.info(f"abs_docx_file_path in convert_docx_topdf: {abs_docx_file_path}")
        abs_output_dir = os.path.dirname(abs_docx_file_path)
        logger.info(f"abs_output_dir in convert_docx_topdf: {abs_output_dir}")
        # Construct the command to convert the file
        command = [
            soffice_cmd,
            "--headless",  # Run in headless mode (without GUI)
            "--convert-to", "pdf",  # Convert to PDF format
            "--outdir", f"{abs_output_dir}",  # Specify the output directory
            f"{abs_docx_file_path}"  # Input file path
        ]
 
       
        # Execute the command
        subprocess.run(command, check=True)
        print(f"Conversion successful: {output_pdf_path}")
        logger.info(f"Conversion successful in convert_docx_to_pdf: {output_pdf_path}")
        logging.debug(f"Conversion successful: {output_pdf_path}")
        return output_pdf_path
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"LibreOffice failed to convert {docx_file_path} to PDF: {str(e)}")