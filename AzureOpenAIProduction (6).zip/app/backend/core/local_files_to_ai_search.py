# import os, shutil
# import json
# import PyPDF2
# from pptx import Presentation
# import docx

# from core.azure_vector_database import upload_vector_database

ACCEPT_TXT_FILES = (".txt", ".md", ".TXT", ".MD")
ACCEPT_WORD_FILES = (".docx", ".doc", ".DOCX", ".DOC")
ACCEPT_PDF_FILES = (".pdf", ".PDF")
ACCEPT_PPT_FILES = (".ppt", ".pptx", ".PPT", ".PPTX")
ACCEPT_FILES = ACCEPT_TXT_FILES + ACCEPT_WORD_FILES + ACCEPT_PDF_FILES + ACCEPT_PPT_FILES

# CHUNK_SIZE = 1024
# delete_chars = ['®']



# def clean_tmp_folder(tmp_folder: str):
#     for filename in os.listdir(tmp_folder):
#         file_path = os.path.join(tmp_folder, filename)
#         try:
#             if os.path.isfile(file_path) or os.path.islink(file_path):
#                 os.unlink(file_path)
#             elif os.path.isdir(file_path):
#                 shutil.rmtree(file_path)
#         except Exception as e:
#             print('Failed to delete %s. Reason: %s' % (file_path, e))


# def spilt_txt_file_to_chunks(file_path, file_name) -> list:
#     contents = []
#     meta_json_list = []
#     with open(file_path,'r') as file:
#         chunk = []
#         content_size = 0
#         chunk_number = 1
#         for line in file:
#             for word in line.split():
#                 chunk.append(word)
#                 content_size += 1
#                 if content_size >= CHUNK_SIZE:
#                     contents.append(" ".join(chunk))
#                     meta_info = {}
#                     meta_info['page'] = chunk_number
#                     meta_info['file_name'] = file_name
#                     meta_info['file_path'] = file_path
#                     meta_json = json.dumps(meta_info)
#                     meta_json_list.append(meta_json)
#                     chunk_number += 1
#                     chunk = []
#                     content_size = 0

#         if len(chunk) >= 100 or not contents:
#             contents.append(" ".join(chunk))
#             meta_info = {}
#             meta_info['page'] = chunk_number
#             meta_info['file_name'] = file_name
#             meta_info['file_path'] = file_path
#             meta_json = json.dumps(meta_info)
#             meta_json_list.append(meta_json)
#         else:
#             contents[-1] += " " + " ".join(chunk)
    
#     return contents, meta_json_list


# def spilt_doc_file_to_chunks(file_path, file_name) -> list:
#     contents = []
    
#     doc = docx.Document(file_path)
#     chunk = []
#     meta_json_list = []
#     content_size = 0
#     chunk_number = 1
    
#     for p in doc.paragraphs:
#         for word in p.text.split():
#             chunk.append(word)
#             content_size += 1
#             if content_size >= CHUNK_SIZE:
#                 chunk_string = " ".join(chunk)
#                 for c in delete_chars:
#                     chunk_string = chunk_string.replace(c,'')
#                 contents.append(chunk_string)
#                 meta_info = {}
#                 meta_info['page'] = chunk_number
#                 meta_info['file_name'] = file_name
#                 meta_info['file_path'] = file_path
#                 meta_json = json.dumps(meta_info)
#                 meta_json_list.append(meta_json)
#                 chunk_number += 1
#                 chunk = []
#                 content_size = 0
#     if len(chunk) >= 100 or not contents:
#         contents.append(" ".join(chunk))
#         meta_info = {}
#         meta_info['page'] = chunk_number
#         meta_info['file_name'] = file_name
#         meta_info['file_path'] = file_path
#         meta_json = json.dumps(meta_info)
#         meta_json_list.append(meta_json)
#     else:
#         contents[-1] += " " + " ".join(chunk)

#     return contents, meta_json_list
        

    
# def spilt_pdf_file_to_chunks(file_path, file_name) -> list:
#     contents = []
#     meta_json_list = []
#     with open(file_path, 'rb') as file:
#         pdf_reader = PyPDF2.PdfReader(file)
#         num_pages = len(pdf_reader.pages)
#         for page_num in range(num_pages):
#             page = pdf_reader.pages[page_num]
#             text = page.extract_text()
#             contents.append(text)
#             meta_info = {}
#             meta_info['page'] = page_num + 1
#             meta_info['file_name'] = file_name
#             meta_info['file_path'] = file_path
#             meta_json = json.dumps(meta_info)
#             # meta_json = meta_json.replace('"', '\"')
#             meta_json_list.append(meta_json)

#     return contents, meta_json_list


# def spilt_ppt_file_to_chunks(file_path, file_name) -> list:
#     contents = []
#     meta_json_list = []

#     prs = Presentation(file_path)
#     page_num = 0
#     for slide in prs.slides:
#         page_num += 1
#         slide_runs = []
#         for shape in slide.shapes:
#             if not shape.has_text_frame:
#                 continue
#             for paragraph in shape.text_frame.paragraphs:
#                 for run in paragraph.runs:
#                     slide_runs.append(run.text)
#         content = "\n".join(slide_runs)
#         if content:
#             contents.append(content)
#             meta_info = {}
#             meta_info['page'] = page_num
#             meta_info['file_name'] = file_name
#             meta_info['file_path'] = file_path
#             meta_json = json.dumps(meta_info)
#             meta_json_list.append(meta_json)
    
#     return contents, meta_json_list


# def insert_record_to_vector_db(user_name, folder_path, file_name, version) -> bool:
#     response = False
#     chunks, meta_json = [], []

#     file_path = folder_path + "/" + file_name
#     if file_name.endswith(ACCEPT_TXT_FILES):
#         chunks, meta_json = spilt_txt_file_to_chunks(file_path, file_name)
#     elif file_name.endswith(ACCEPT_PDF_FILES):
#         chunks, meta_json = spilt_pdf_file_to_chunks(file_path, file_name)
#     elif file_name.endswith(ACCEPT_WORD_FILES):
#         chunks, meta_json = spilt_doc_file_to_chunks(file_path, file_name)
#     elif file_name.endswith(ACCEPT_PPT_FILES):
#         chunks, meta_json = spilt_ppt_file_to_chunks(file_path, file_name)
#     response = upload_vector_database(chunks, meta_json, user_name, file_name, version)
#     return True if response else False

