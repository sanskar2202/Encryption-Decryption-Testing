from azure.storage.blob.aio import BlobServiceClient
from azure.storage.blob import generate_blob_sas, BlobSasPermissions
from azure.core.credentials import AzureKeyCredential
from azure.ai.translation.document import DocumentTranslationClient
import os
from quart import jsonify
import urllib.parse
from datetime import datetime, timedelta 
from azure.storage.blob import BlobServiceClient, BlobClient, generate_container_sas, ContainerSasPermissions, ContainerClient
# from azure.identity import DefaultAzureCredential
# from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.storage.blob import ContentSettings
import logging 

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

AZURE_STORAGE_CONNECTION_STRING = os.getenv('AZURE_STORAGE_CONNECTION_STRING')

# AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=sapocopenai;AccountKey=H30mVmhmyKpFmLUkFSKpDO3CUe+jbcG8aGZ8TgCRNTQj5Ac5HB+649BzYypyo9eW0W9BRy9Z0oFr+ASt6hAVYw==;EndpointSuffix=core.windows.net"
AZURE_TRANSLATION_SERVICE = os.getenv('AZURE_TRANSLATION_SERVICE')
blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
source_container_name = os.getenv('AZURE_SOURCE_CONTAINER')

endpoint = f"https://{AZURE_TRANSLATION_SERVICE}.cognitiveservices.azure.com/"
# endpoint = "https://poc-devtranslator.cognitiveservices.azure.com/"
key = os.getenv('AZURE_TRANSLATION_KEY')
translator_client = DocumentTranslationClient(endpoint, AzureKeyCredential(key))

async def generate_source_uri(container_name, user_name):
    return f"https://{blob_service_client.account_name}.blob.core.windows.net/{container_name}/{user_name}"

async def generate_target_uri(container_name, file_name, language, user_name):

    datetimeappend = int((datetime.now().timestamp())*1000)
    # return f"https://{blob_service_client.account_name}.blob.core.windows.net/{container_name}/{file_name}_{language}_{datetimeappend}"
    return f"https://{blob_service_client.account_name}.blob.core.windows.net/{container_name}/{user_name}/{file_name}"
    # return f"https://{blob_service_client.account_name}.blob.core.windows.net/{container_name}/{file_name}_{language}"

# Function to translate document using Azure Translator
async def translate_document(source_uri, fileName, target_container_name, target_languages, prefix, suffix, user_name, translated_file_name, translated_files, translated_folder_name):

    try:
        # print(target_languages, "target_languages in translate_document", translated_files, " translated_files in tna-documet")
        for language in target_languages:
            # print(language, "inside languages for loop")
            decoded_source_url = urllib.parse.quote(fileName)
            # print(decoded_source_url, " decoded_source_url ")
            # source_uri_file = source_uri+decoded_source_url
            source_uri_file = source_uri+fileName
            # print(source_uri_file, " source_uri_file ", source_uri, " source_uri ")
            # base = os.path.basename(source_uri)
            base = os.path.basename(source_uri_file)
            # print(base,'os path basename source_uri')
            file_name = os.path.splitext(base)[0]
            # file_ext = os.path.splitext(base)[1]
            target_uri = await generate_target_uri(target_container_name,file_name, language, user_name)
            # print(target_uri, "target_uri in for loop")
            poller = translator_client.begin_translation(source_uri, target_uri, language, prefix = prefix, suffix = suffix)
            # poller = translator_client.begin_translation(source_uri, target_uri, language)
            # print(dir(poller), "poller in for loop")
            # poller = translator_client.begin_translation(source_uri, target_container_name, target_languages=[language])
            result = poller.result()
            # print(result, "result inside translate_doc")

            for document in result:
                if document.status == "Failed":
                    print("Document.status failed")
                    return None, None, None
                print(document, "document in result", document.translated_document_url, "document.translated_document_url",
                      document.source_document_url, "document.doc_url", document.translated_to, " document.transl_to")
                print("Document ID: {}".format(document.id))
                print("Document status: {}".format(document.status))
                
                translated_file_name_tgt = urllib.parse.unquote(document.translated_document_url).split('/')[-1]
                translated_file_name_src = urllib.parse.unquote(document.source_document_url).split('/')[-1]

                print("doc source doc url name",translated_file_name_src, "doc target doc url name",translated_file_name_tgt )


                if document.status == "Succeeded":
                    translated_document_url = document.translated_document_url
                    print("translated_document_url", translated_document_url)
                    # if language not in translated_files:
                    #     translated_files[language] = []
                    
                    # translated_files[language].append(translated_document_url)
                    decoded_translated_document_url = urllib.parse.unquote(document.translated_document_url)
                    print("decoded_translated_document_url", decoded_translated_document_url)
                    # translated_document_url_parts = translated_document_url.split('/')
                    translated_document_url_parts = decoded_translated_document_url.split('/')
                    print("translated_document_url_parts", translated_document_url_parts)
                    translated_file_name = translated_document_url_parts[-1]
                    print("translated_file_name", translated_file_name)
                    # unique_translated_file_name = f"{translated_file_name.split('.')[0]}_{language}.{translated_file_name.split('.')[-1]}"
                    unique_translated_file_name = translated_file_name
                    print("unique_translated_file_name", unique_translated_file_name)
                    unique_translated_document_url = '/'.join(translated_document_url_parts[:-1] + [unique_translated_file_name])
                    print("unique_translated_document_url", unique_translated_document_url)
                    translated_files[language] = unique_translated_document_url
                    print("translated_files[language]", translated_files[language])
                    if language not in translated_files:
                        translated_files[language] = []
                    
                    # translated_files[language].append(decoded_translated_document_url)
                    translated_files[language] =  decoded_translated_document_url
                    print("translated_files[language]", translated_files[language])
                    # translated_files = translated_document_url
                    # print("translated_files inside", translated_files)
                    print("translated_folder_name before assignment", translated_folder_name)
                    translated_folder_name = translated_document_url_parts[-2]
                    print("translated_files inside again", translated_files, "translated_folder_name inside again", translated_folder_name)

                    print("Source document location: {}".format(document.source_document_url))
                    print("Translated document location: {}".format(unique_translated_document_url))
                    print("Translated to language: {}\n".format(document.translated_to))
                    print(translated_document_url_parts[-1], "translated document url parts -1 maybe file name",
                          translated_document_url_parts[-2], "translated document url parts -2 maybe folder name")
                else:
                    print("Error Code: {}, Message: {}\n".format(document.error.code, document.error.message))

        # translated_files += translated_document_url
        # translated_folder_name += translated_document_url_parts[-2]
        # print("translated_files inside", translated_files, "translated_folder_name inside", translated_folder_name)

    except Exception as e:
        print(f"Failed to translate document: {e}")
        # return jsonify(status='translate_error', error=str(e)), 200
    
    # print("translated_files", translated_files, "translated_folder_name", translated_folder_name)
    return translated_files,translated_folder_name, translated_file_name


async def upload_file_to_azure(container_name, file_path, connection_string, directory_path):
    # Create a BlobServiceClient using the connection string
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    logging.debug(blob_service_client, "blob_service_client")
    # Create a ContainerClient
    container_client = blob_service_client.get_container_client(container_name)
    logging.debug(container_client, "container_client")
   
    # Create the container if it does not exist
    try:
        logger.info(f"inside upload_file_to_azure")
        container_client.create_container()
    except Exception as e:
        print(f"Container {container_name} already exists.")
 
    # Get the filename from the file path
    blob_name = os.path.basename(file_path)

    if directory_path:
        blob_name = os.path.join(directory_path, blob_name).replace("\\", "/")

    logger.info(f"blob_name inside upload_file_to_azure: {blob_name}")
    # Create a BlobClient
    blob_client = container_client.get_blob_client(blob_name)
   
    # Upload the file
    with open(file_path, "rb") as data:
        blob_client.upload_blob(data, overwrite=True)
        logger.info(f"blob_client inside upload_file_to_azure: {blob_client}")
        print(f"File {file_path} uploaded to container {container_name} as blob {blob_name}")
        print(f"{blob_client} blob_client after upload blob")
        logging.debug(f"File {file_path} uploaded to container {container_name} as blob {blob_name}")
        logging.debug(f"{blob_client} blob_client after upload blob")
 
async def generate_previewable_url(container_name, blob_name, expiry_hours=10):
    
    try:
        blob_service_client_prev = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
        # Create a BlobServiceClient
        # blob_service_client = BlobServiceClient(account_url=f"https://{blob_service_client.account_name}.blob.core.windows.net", credential=blob_service_client.account_key)
        print(blob_service_client_prev, "blob_service_client_prev")
        logging.debug((blob_service_client_prev, "blob_service_client_prev"))
        # Set the expiration time for the SAS token
        sas_expiry_time = datetime.now().astimezone() + timedelta(hours=expiry_hours)
        print(sas_expiry_time, "sas_expiry_time")
        logging.debug(sas_expiry_time, "sas_expiry_time")
        
        # Generate a SAS token for the blob
        sas_token = generate_blob_sas(
            account_name=blob_service_client_prev.account_name,
            container_name=container_name,
            blob_name=blob_name,
            account_key=blob_service_client_prev.credential.account_key,
            permission=BlobSasPermissions(read=True),  # Set read permissions
            expiry=sas_expiry_time,
            content_disposition="inline",# Force the file to open in the browser
            content_type="application/pdf"
        )
        logging.debug(sas_token, "sas_token")
        print(sas_token, "sas_token")
        # content_settings = ContentSettings(content_type="application/pdf", content_disposition="inline") 
        # Update blob headers if not already set correctly (optional, for existing files)
        # blob_client_prev = blob_service_client_prev.get_blob_client(container=container_name, blob=blob_name)
        # logging.debug(blob_client_prev, "blob_client_prev 183")
        # blob_client_prev.set_http_headers(content_settings=content_settings)
        # logging.debug(blob_client_prev, "blob_client_prev 185")
        # Generate the full URL with the SAS token
        print(container_name, "container_name before blob_url", blob_name, "blob_name before blob_url", sas_token, "sas_token before blob_url")
        logging.debug(container_name, "container_name before blob_url", blob_name, "blob_name before blob_url", sas_token, "sas_token before blob_url")
        blob_url = f"https://{blob_service_client_prev.account_name}.blob.core.windows.net/{container_name}/{blob_name}?{sas_token}"
        # blob_url = f"https://{blob_service_client_prev.account_name}.blob.core.windows.net/{container_name}/{blob_name}"
        print(blob_url)
        logging.debug(blob_url, "blob_url 200" )
        return blob_url
    
    except Exception as e:
        print(f"Failed to generate the URL: {e}")
 