import requests
import uuid
import json
from typing import Any, AsyncGenerator
from langdetect import detect
class Translate:
    print("Hello World")
    def __init__(self):
        self.key = "b2ea3903d30744a88bf93403e3d47da3"
        self.endpoint = "https://api.cognitive.microsofttranslator.com"
        self.location = "eastus"

    async def run_translate(self, history, overrides, user_name):
        # Extract the last bot answer
        print("Hello_RUn")
        last_bot_answer = self.extract_last_bot_answer(history)
        language_ans=detect(last_bot_answer)

        # print("History",history[-2]['bot'])
        
        if last_bot_answer:
            # Get the target language from overrides
            target_language = overrides.get("language", "en") 
            # print("Target_language",target_language) # Default to English if not provided
            
            # Function to extract text before one of the keywords
            def extract_text_before_citations(input_text):
                # List of keywords to check for
                keywords = ["**Citations**", "Citations"]
               
                # Iterate over the keywords and find which one appears first
                for keyword in keywords:
                    if keyword in input_text:
                        # Return text before the keyword
                        return input_text.split(keyword)[0].strip()
               
                # If no keyword is found, return the entire text
                return input_text.strip()
 
            # Call the function and print the result
            text_before_citations = extract_text_before_citations(last_bot_answer)
 
            translated_text = self.translate_text(text_before_citations, target_language,language_ans)
 
            translated_text += last_bot_answer.replace(text_before_citations, "")
            # Translate the last bot answer
            # translated_text = self.translate_text(last_bot_answer, target_language,language_ans)
            json_output = {
                            "choices": [
                                {
                                "finish_reason": "null",
                                "index": 0,
                                "delta": {
                                    "content": translated_text
                                }
                                }
                                        ]
                                }
            # print(json_output)
            return(json_output)
            
            # Example: Return the original and translated texts
            # return {"original_answer": last_bot_answer, "translated_text": translated_text}
        # else:
        #     # return {"error": "No bot answer found in history"}
        #     yield ' '

    def extract_last_bot_answer(self, history):
        # Check if history has enough entries and return the last bot message
        if len(history) >= 2:
            return history[-2].get("bot", None)
        return None
    async def run_translate_stream(self, history, overrides, user_name)-> AsyncGenerator[dict, None]:
        chat_cor=await self.run_translate(history, overrides, user_name)
        yield chat_cor

    def translate_text(self, text, target_language,language_ans):
        if not text:
            return None
        print("Target_Language",target_language)
        # print(language_ans)
        path = '/translate'
        constructed_url = self.endpoint + path
        params = {
            'api-version': '3.0',
            'from': [language_ans],  # Assuming the source language is English
            'to': [target_language]  # Translate to the target language provided
        }

        headers = {
            'Ocp-Apim-Subscription-Key': self.key,
            'Ocp-Apim-Subscription-Region': self.location,
            'Content-type': 'application/json',
            'X-ClientTraceId': str(uuid.uuid4())
        }

        body = [{'text': text}]

        try:
            response = requests.post(constructed_url, params=params, headers=headers, json=body)
            response.raise_for_status()  # Raise an error for bad status codes
            translations = response.json()
            
            # Extract the translated text
            translated_text = translations[0]['translations'][0]['text']
            
            return translated_text

        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")
            return {"error": str(e)}
