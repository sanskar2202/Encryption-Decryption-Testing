from typing import Any, AsyncGenerator

import openai
from azure.search.documents.aio import SearchClient
from azure.search.documents.models import QueryType

from core.messagebuilder import MessageBuilder
from core.modelhelper import get_token_limit

# from core.csv_sql import sql_approach
from core.csv_excel_sql import csv_exc_sql

from text import nonewlines
#import pypdf
from langchain.vectorstores import FAISS
from langchain.embeddings.openai import OpenAIEmbeddings
import os
import openpyxl as xl
import pandas as pd
from langchain_experimental.agents.agent_toolkits import create_csv_agent
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain.llms import OpenAI
from langchain_community.chat_models import ChatOpenAI
from langchain.callbacks import get_openai_callback

import tiktoken
from core.dblogger import log_api_response
from datetime import datetime, timedelta
import re
import shutil

import base64
import re
import json
