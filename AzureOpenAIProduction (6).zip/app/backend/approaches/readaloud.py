import requests
import uuid
import json
from typing import Any, AsyncGenerator
from langdetect import detect

import azure.cognitiveservices.speech as speechsdk

class ReadAloud:
    print("Hello World")
    def __init__(self):
        self.SPEECH_KEY = "9fd3c452d25d4848a54f9d466f5dcefc"
        self.SPEECH_REGION = "eastus"

    def speaker(self, input):
        
        speech_config = speechsdk.SpeechConfig(subscription=self.SPEECH_KEY, region=self.SPEECH_REGION)
        audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)

        speech_config.speech_synthesis_voice_name='en-US-AvaMultilingualNeural'
        speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

        speech_synthesis_result = speech_synthesizer.speak_text_async(input).get()

        if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            print("Speech synthesized for text [{}]".format(input))

        print("speaker called in ReadAloud")
        return ("speaker called in ReadAloud")