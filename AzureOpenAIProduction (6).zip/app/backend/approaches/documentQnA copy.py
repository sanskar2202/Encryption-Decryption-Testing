import difflib
from typing import Any, AsyncGenerator
import asyncio
import logging
import openai
import platform
import uuid
# import self
from azure.search.documents.aio import SearchClient
from azure.search.documents.models import QueryType
import re
from core.messagebuilder import MessageBuilder

from core.modelhelper import get_token_limit
from pathlib import Path
# from core.csv_sql import sql_approach
from core.csv_excel_sql import csv_exc_sql

from text import nonewlines
#import pypdf
from langchain.vectorstores import FAISS
from langchain.embeddings.openai import OpenAIEmbeddings
import os
import openpyxl as xl
import pandas as pd
from langchain_experimental.agents.agent_toolkits import create_csv_agent
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain.llms import OpenAI
from langchain_community.chat_models import ChatOpenAI
from langchain.callbacks import get_openai_callback
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
import tiktoken
from core.dblogger import log_api_response
from datetime import datetime, timedelta
import re
import shutil

import base64
import re
import json
import base64
import re
import json
from azure.storage.blob import generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta
from quart import session






class DocumentQnA:
    # Chat roles
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    
    system_message_chat_conversation = """
        
        You are a helpful AI assistant that answers the user's questions using the context provided to you.
        When answering any question, thoroughly go through the context provided. Ensure that you extract and present all relevant information from the context that match the user's query. 
        If there is a match, provide a clear and relevant response based on the information found in the context.
        The context you are being provided with contains information from the document(s) uploaded by the user. Utilize this information to answer the user's questions. The context is made up of chunks of data. These chunks do not denote the actual number of documents. Actual number of documnets is {upload_count}
        Follow the below instructions strictly:
            1. If the user asks to "summarize", or uses phrases such as "Tell me about this document", "What is this document about", "Can you summarize this" or similar, provide a **brief summary** of the context, highlighting the **most relevant points** in a clear and concise manner.
            2. Thorough Search: Search the entire context thoroughly to find anything relevant to the user query.
                1.1 Check all available context to make sure no important information is missed, even if it is only mentioned in one specific section of the context.
                1.2 If the query matches a specific detail in the context, even if there is only one match, provide a detailed, relevant answer.
            3. Response to Relevant Matches:
                2.1 If any relevant information is found in the context, respond clearly and concisely with the information that best addresses the user's query.
                2.2 If the user's question matches any part of the context, respond with the most relevant and concise information.
                2.3 If there is only one match, provide the answer derived from that specific piece of context.
            4. Response When No Match is Found:
                If no relevant information can be found after thoroughly searching the context, reply with:
                "Please be more specific with your query or ask something related to the documents."
            5. Do not ask follow-up questions or provide information not mentioned in the context.
            6. Provide clear and concise answers without adding unnecessary details.
            7. Translate the context into the requested language if asked.  
            8. Do not justify your answers or provide explanations beyond the relevant context.
            
        {injected_prompt}
    """
    system_message_chat_conversation_summarize = """
        
        You are a helpful AI assistant that summarizes content as per the user question using the context provided by the user. Do not justify your answers. Do not give information not mentioned in the context, but you can translate the context into any language if asked.

        {page_urls_list} : URL stored in it should be provided under the Citations from the documents which are utilized for response generation.
        
        Also provide 'page number' as 'page_number' from where response is getting generated. 'page_number' would be '1' by default here.
        Provide this information under heading "Citations", keep only heading in bold characters. Follow the **exact** below format for citations.    

        <**Citations**>

            \n* File_Link :  URL

        <**/Citations**>
        IMPORTANT: Make sure to follow above citation format!

        {injected_prompt}
    """
    def __init__(
        self,
        chatgpt_deployment: str,
        gpt4_deployement: str,
    ):
        self.chatgpt_deployment = chatgpt_deployment
        self.gpt4_deployement = gpt4_deployement
        self.chatgpt_model = "GPT4o"
        self.chatgpt_token_limit = get_token_limit(self.chatgpt_model)

    async def run_until_final_call(
        # self, user_name, history: list[dict[str, str]], overrides: dict[str, Any], should_stream: bool = False
        self, user_name, history: list[dict[str, str]], overrides: dict[str, Any], should_stream: bool = False,
    ) -> tuple:
        # try:
            user_q =  history[-1]["user"]
        #   print('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')

            AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
            AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
            openai_api_version = "2023-12-01-preview" 
            # openai_api_version = "2023-12-01-preview"
            openai_api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com" 
            openai_api_key = AZURE_OPENAI_API_KEY
            embeddings = OpenAIEmbeddings(openai_api_base = openai_api_base,
                                openai_api_type = "azure",
                                openai_api_key=openai_api_key, 
                                openai_api_version = openai_api_version, 
                                deployment="text-embedding-ada-002", 
                                #chunk_size = 16,
                                # max_retries = 0)
                                        )
            img_extensions = (".jpg", ".png", ".jpeg", ".gif", ".webp", ".JPG", ".PNG", ".JPEG", ".GIF", ".WEBP")
            structured_extensions = (".csv", ".xlsx", ".CSV", ".XLSX")
            ## For handling CSV & Excel Files
            # tempdir = "./tempfile"
            tempdir = "/home/tempfile"
            system_platform = platform.system()
            if system_platform == "Linux":           
                tempdir = "/home/tempfile"
            elif system_platform == "Windows":
                tempdir = "./tempfile"
            else:
                raise OSError(f"Unsupported platform: {system_platform}")
            if not os.path.exists(tempdir):
                os.makedirs(tempdir, exist_ok=True)

            files = os.listdir(os.path.join(tempdir, user_name))
            if os.path.isdir(os.path.join(tempdir,user_name,"images")):
                # print("image directory exists")
                shutil.rmtree(os.path.isdir(os.path.join(tempdir,user_name,"images")))
            # print(len(files), "length of files")
            flag = False
            if len(files)>0:
                os.environ["OPENAI_API_KEY"] = openai_api_key  
                agent_output = ""
            
                if files[0].endswith(img_extensions):                
                    base64_encoded = []
                    image_names = []

                    for file in files:
                        # print("***********************************************",file)
                        file_path = os.path.join(tempdir, user_name, file)
                        base64_encoded.append(self.encode_image(file_path))
                        image_names.append(file)

                    # Mapping of numbers to ordinal words
                    ordinals = {
                        1: "first", 2: "second", 3: "third", 4: "fourth", 5: "fifth",
                        6: "sixth", 7: "seventh", 8: "eighth", 9: "ninth", 10: "tenth",
                        11: "eleventh", 12: "twelfth", 13: "thirteenth", 14: "fourteenth", 15: "fifteenth",
                        16: "sixteenth", 17: "seventeenth", 18: "eighteenth", 19: "nineteenth", 20: "twentieth",
                        21: "twenty-first", 22: "twenty-second", 23: "twenty-third", 24: "twenty-fourth",
                        25: "twenty-fifth", 26: "twenty-sixth", 27: "twenty-seventh", 28: "twenty-eighth",
                        29: "twenty-ninth", 30: "thirtieth"
                    }

                    # Function to return the ordinal word
                    def get_ordinal(index):
                        return ordinals.get(index + 1, f"{index+1}th")
                    
                    # Generating the dynamic string
                    dynamic_string = "\n".join([f"{get_ordinal(index)} image : {filename}" for index, filename in enumerate(image_names)])
                    # dynamic_string = "\n".join([f"{index+1}_image_name : {filename}" for index, filename in enumerate(image_names)])
                    # print("dynamic_stringg", dynamic_string, "194")
                    img_citations= f""" <dynamic_string>
                                    {dynamic_string}
                                    </dynamic_string>

                                
                                        
                                    MOST IMPORTANT :- Do not provide any information that is not present in images provided. Do not provide information irrelevant to the images uploaded.
                                    Take image name from dynamic string provided, instead of writing first image, second image etc provide proper image name as given in dynamic string
                                    """
                    


                    system_prompt = f"""Act as an Image Analyzer. Follow below mention points
                                    1. Generate and provide response which answers and is relevant to the user's question. 
                                    2. Try to answer user's question only from the image provided.
                                    """
# 
                    # print("img_citation",img_citations, "img_citation")                
                    # Initialize the JSON structure
                    json_structure = [
                        # {"role": "system", "content": "Act as an Image Analyzer"},
                        {"role": "system", "content": img_citations},
                        {"role": "user", "content": [
                            {"type": "text", "text": user_q}
                        ]}
                    ]

                    for base64_image in base64_encoded:
                        json_structure[1]["content"].append(
                            {"type": "image_url", "image_url": {
                                "url": f"data:image/png;base64,{base64_image}"}
                            }
                        )
                        # print("base64_image",base64_image, "base64_image")
                    # print("json_structure", json_structure, "json_structure")
                    response_1, tokens_consumed = self.api_call_img(json_structure)
                    # print("response_1", response_1, "262")
                    response, tokens_consumed = self.api_call_img_2(response_1, user_q)
                    # print("response",response, "264")

                elif files[0].endswith(structured_extensions):
                
                    agent_output, tokens_consumed_sql, user_q = csv_exc_sql().sql_approach(user_q, os.path.join(tempdir,user_name,files[0]), user_name)
                    
                    tokens_consumed_descriptive = 0
                    if type(agent_output) == str:
                        if "Please specify sheetname from" in agent_output:
                            response = agent_output
                            # print(response, "response 237")
                        
                        elif agent_output == "Agent stopped due to iteration limit or time limit.":
                            agent_output = """You might have asked something out of the context with the uploaded data, If not please be more specific in the input asked"""
                            response = agent_output
                            # print(response, "response 242")

                        elif agent_output == """You might have asked something out of the context with the uploaded data, If not please be more specific in the input asked""":
                            response = agent_output   
                            # print(response, "response 246")  

                        else:
                            if "<|im_end|>" in agent_output:
                                agent_output = agent_output.replace("<|im_end|>", "")

                            response, tokens_consumed_descriptive = self.api_call(user_q, agent_output)
                            # print(response, "response 253")
                    else:
                        response, tokens_consumed_descriptive = self.api_call(user_q, agent_output)
                        # print(response, "response 256")


                    timestamp = datetime.now()
                    await log_api_response(user=user_name,input_timestamp=timestamp,api='ai-gen',model_name="GPT4o",token=tokens_consumed_descriptive+tokens_consumed_sql)
                flag = True
                
                json_output = {
                            "choices": [
                                {
                                "finish_reason": "null",
                                "index": 0,
                                "delta": {
                                    "content": response
                                }
                                }
                                        ]
                                    }
                
                return ({},json_output, flag, [])

            else:
                vector_dict = {}

                folder = os.path.join("vector_stored", user_name)
                folders = os.listdir(folder)
                # print("folders", folders)
                for i, j in enumerate(folders):
                    folder_path = os.path.join(folder, j)
                # print(folder_path)
                    vector_dict[f"vector_store_{i}"] = FAISS.load_local(folder_path, embeddings=embeddings)
                    if i == 0:
                        vector_store = vector_dict[f"vector_store_{i}"]
                    else:
                        vector_store.merge_from(vector_dict[f"vector_store_{i}"])
                    
                file_name_flag = False
                page_number_flag = False
                summarize_flag = False
                file_loaded = False
                ## matching keywords
                keywords = re.findall(r'\bsummarize\b|\bexplain briefly\b|\bbriefly\b', user_q, re.IGNORECASE)
                if keywords:
                    summarize_flag = True
                    files = os.listdir(os.path.join('./temp_dir_2/', user_name))

                    ## Extracting Page_Number
                    match_page = re.search(r'(?:page|slide)\s*(\d+)', user_q, re.IGNORECASE)
                    if match_page:
                        page_number_present = str(int(match_page.group(1)))
                        page_number_flag = True
                        # print("Page Number", page_number_present, page_number_flag)
                    
                    ## Extracting file name
                    # match = re.findall(r'[\w-]+\.pdf\b', user_q)
                    match = re.findall(r'[\w-]+\.(?:docx|txt|pptx|pdf)\b', user_q)

                    if match:
                        for file in match:
                            user_q = user_q.replace(file, file.rsplit('.', 1)[0] + '.pdf')
                        file_name_present = (os.path.splitext(match[0])[0])
                        file_name_flag = True
                        # print("File Name", file_name_present, file_name_flag)
                        ## Extracting page_number from the user_query
                    
                    if not file_name_flag and len(files) < 2:
                        with open(f'./temp_dir_2/{user_name}/{files[0]}', 'r') as json_file:
                            loaded_dict = json.load(json_file)
                        file_loaded = True

                    elif file_name_flag:
                        with open(f'./temp_dir_2/{user_name}/{file_name_present}' + '.json', 'r') as json_file:
                            loaded_dict = json.load(json_file)
                        file_loaded= True

                    elif len(files) > 1 and not file_name_flag:
                        flag = True
                        json_output = {
                            "choices": [
                                {
                                "finish_reason": "null",
                                "index": 0,
                                "delta": {
                                    "content": "Please mention file name in the input as more than 1 file is uploaded"
                                }
                                }
                                        ]
                                    }
                        return ({},json_output, flag, [])

                    if file_loaded:
                        document_content = ""
                        if page_number_flag:
                            document_content = loaded_dict[page_number_present]['content']
                            document_page = loaded_dict[page_number_present]['page_url']
                        
                        else:
                            for i in loaded_dict:
                                document_content += loaded_dict[i]['content']
                            document_source = loaded_dict[i]['source_url']


               
                similar_docs = vector_store.similarity_search_with_score(user_q, k = 4)
                # print(similar_docs, "similar_docs")
                docs = []
                for doc in similar_docs:
                    if doc[1] < 0.50:
                        docs.append(doc)
                if summarize_flag:
                    if file_name_flag and not page_number_flag:
                        page_urls_list = [document_source]
                        # print(page_urls_list, "print 612")
                    elif page_number_flag:
                        page_urls_list = [document_page]
                    elif file_loaded:
                        page_urls_list = [document_source]
                        # print(page_urls_list, "print 617")
                    user_q = f"""Provide indepth summary of the the below content, utilize only the provided content nothing else. Consider user_q before generating the summary.
                                    <content>
                                    {document_content}
                                    </content>
                                    
                                    <user_q>
                                    {user_q}
                                    </user_q>

                                    """
                else:
                    if len(docs) < 1:
                        flag = True
                        json_output = {
                            "choices": [
                                {
                                "finish_reason": "null",
                                "index": 0,
                                "delta": {
                                    "content": "Please ask something from the file(s) uploaded"
                                }
                                }
                                        ]
                                    }
                        return ({},json_output, flag, [])
                    page_urls_list = []
                    for doc in docs:
                        page_url = doc[0].metadata['page']
                        page_urls_list.append(f"Page URL: {page_url}")
                    

                    # print(page_urls_list, "page_urls_list")
                    user_q = f"""Use the below context only to answer the question. Consider only the provided context to generate the answer.
                                <Context>
                                {docs}
                                </Context>

                                <Question>
                                {user_q}
                                </Question>
                                """
                    

                deployement_type = overrides.get("model_type") or "GPT3.5"
                if deployement_type == "GPT4":
                    deployement_id = self.gpt4_deployement
                else:
                    deployement_id = self.chatgpt_deployment

                chatgpt_args = {"deployment_id": deployement_id}

                if deployement_type == "GPT4":
                    encoding_model = "gpt-4"
                else:
                    encoding_model = "gpt-3.5-turbo"

                encoding = tiktoken.encoding_for_model(encoding_model)
                q_tokens = len(encoding.encode(user_q))     
            # print(q_tokens, "tokens_q") 

                follow_up_questions_prompt = (
                    self.follow_up_questions_prompt_content if overrides.get("suggest_followup_questions") else ""
                )

               
                prompt_override = overrides.get("prompt_template")
                if prompt_override is None:
                    if summarize_flag:
                        system_message = self.system_message_chat_conversation_summarize.format(
                            injected_prompt="", follow_up_questions_prompt=follow_up_questions_prompt, page_urls_list=page_urls_list
                    )
                        
                    else:    
                        system_message = self.system_message_chat_conversation.format(
                            injected_prompt="", follow_up_questions_prompt=follow_up_questions_prompt, page_urls_list=page_urls_list
                    )
                else :
                    if summarize_flag:
                        system_message = self.system_message_chat_conversation_summarize.format(
                            injected_prompt=prompt_override[3:] + "\n", follow_up_questions_prompt=follow_up_questions_prompt, page_urls_list=page_urls_list
                    )
                    else:
                        system_message = self.system_message_chat_conversation.format(
                            injected_prompt=prompt_override[3:] + "\n", follow_up_questions_prompt=follow_up_questions_prompt, page_urls_list=page_urls_list
                    )
                
                docuqna_tokens, messages = self.get_messages_from_history(
                    system_message,
                    self.chatgpt_model,
                    history,
                    user_q,
                    [],
                    self.chatgpt_token_limit - len(user_q),
                )
              
                total_tokens= q_tokens + docuqna_tokens +20
                timestamp = datetime.now()
                await log_api_response(user=user_name,input_timestamp=timestamp,api='ai-gen',model_name='GPT4o',token=total_tokens)

                extra_info = {
                    "data_points": "",
                    "thoughts": f"Searched for:<br>{user_q}<br><br>Conversations:<br>"
                }
            #  print("--------------model_type-----------------------------")
            #  print(chatgpt_args, self.chatgpt_model, overrides.get("temperature"))
                chat_coroutine = openai.ChatCompletion.acreate(
                    **chatgpt_args,
                    model=self.chatgpt_model,
                    messages=messages,
                    temperature=overrides.get("temperature") or 0.7,
                    # max_tokens=1024,
                    n=1,
                    stream=should_stream,
                )
                

                return (extra_info, chat_coroutine, flag, page_urls_list)
   
       
    def remove_citations(self,text: str) -> str:
    # Regex pattern to match citations like [doc1], [doc2], etc.
        pattern = r'\[doc[^\]]*\]'
        
        # Use re.sub to replace the citations with an empty string
        cleaned_text = re.sub(pattern, '', text)
        
        return cleaned_text  
         
    async def run_until_final_call_1(
        # self, user_name, history: list[dict[str, str]], overrides: dict[str, Any], should_stream: bool = False
        self, user_name, history: list[dict[str, str]], overrides: dict[str, Any], should_stream: bool = False
    ) -> tuple:
        # try:
            user_q =  history[-1]["user"]
        #   print('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX')

            AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY_East")
            AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE_East")
            openai_api_version = "2023-12-01-preview" 
            # openai_api_version = "2023-12-01-preview"
            openai_api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com" 
            openai_api_key = AZURE_OPENAI_API_KEY
           
            tempdir = "/home/tempfile"
            system_platform = platform.system()
            if system_platform == "Linux":           
                tempdir = "/home/tempfile"
            elif system_platform == "Windows":
                tempdir = "./tempfile"
            else:
                raise OSError(f"Unsupported platform: {system_platform}")
            if not os.path.exists(tempdir):
                os.makedirs(tempdir, exist_ok=True)
            files = os.listdir(os.path.join(tempdir, user_name))
            if os.path.isdir(os.path.join(tempdir,user_name,"images")):
                print("image directory exists")
                shutil.rmtree(os.path.isdir(os.path.join(tempdir,user_name,"images")))
            # print(len(files), "length of files")
            flag = False


            if len(files)>0:
                    #flag = True
                    os.environ["OPENAI_API_KEY"] = openai_api_key
                    # Get the file path and size for checking the file size
                    # tempdir = "./tempfile"
                    tempdir = "/home/tempfile"
                    system_platform = platform.system()
                    if system_platform == "Linux":           
                        tempdir = "/home/tempfile"
                    elif system_platform == "Windows":
                        tempdir = "./tempfile"
                    else:
                        raise OSError(f"Unsupported platform: {system_platform}")
                    if not os.path.exists(tempdir):
                        os.makedirs(tempdir, exist_ok=True)
                    user_dir = os.path.join(tempdir,user_name )
                    file_names = [f for f in os.listdir(user_dir) if os.path.isfile(os.path.join(user_dir, f))]
                    
                    
                    # Ensure the directory exists
                    os.makedirs(user_dir, exist_ok=True)

                    # Calculate the total size of all files in the directory
                    total_size = 0

                    # Iterate over all files in the user directory
                    for file_name in os.listdir(user_dir):
                        file_path = os.path.join(user_dir, file_name)
                        
                        # Check if it's a file (not a directory)
                        if os.path.isfile(file_path):
                            # Add the file size to the total
                            total_size += os.path.getsize(file_path)
                    
                    if os.path.exists(user_dir):
                        user_q = history[-1]["user"]
                        responses = []
                        
                        summary_triggers_fuzzy = [
                            "summarize", "summary", "tell me about", "what is this document about", "can you summarize"
                        ]

                        document_count_triggers_fuzzy = [
                            "list the documents", "show the documents", "display the documents",
                            "how many documents", "count of documents", "documents count",
                            "number of documents", "view all documents", "what documents do i have",
                            "what documents are there", "list of files uploaded"
                        ]

                        document_count_patterns = [
                            r"\blist\s+(?:the\s+)?documents?\b", 
                            r"\bshow\s+(?:the\s+)?documents?\b",
                            r"\bdisplay\s+(?:the\s+)?documents?\b",
                            r"\bhow\s+many\s+documents?\b", 
                            r"\bcount\s+of\s+documents?\b",
                            r"\bdocuments?\s+count\b",
                            r"\bnumber\s+of\s+documents?\b",
                            r"\bview\s+(?:all\s+)?documents?\b",
                            r"\bwhat\s+documents?\s+(?:do\s+i\s+have|are\s+there)\b"
                        ]

                        # Function to check regex patterns
                        def matches_regex(user_input, patterns):
                            return any(re.search(pattern, user_input) for pattern in patterns)

                        # Function to check fuzzy matching
                        def matches_fuzzy(user_input, trigger_phrases, cutoff=0.8):
                            return any(difflib.get_close_matches(user_input, [phrase], cutoff=cutoff) for phrase in trigger_phrases)

                        summary_patterns = [
                            r"\bsummarize\b",  # Matches 'summarize' even if used alone
                            r"\bsummary\b",  # Matches phrases like "give me a summary"
                            r"\btell me about\b",
                            r"\bwhat is this document about\b",
                            r"\bcan you summarize\b"
                        ]                        
                        user_q_lower = user_q.lower()                       
                        if matches_regex(user_q_lower, summary_patterns) or matches_fuzzy(user_q_lower, summary_triggers_fuzzy): #using regex and fuzzy for summary
                            print("Summary pattern matched")            
                            for file_name in file_names:
                                # print(file_name,"file_name")
                                # Prepare the messages payload
                                messages = [
                                    
                                    {
                                        "role": "user",
                                        "content": f"give detailed information about {file_name}",
                                    }
                                ]
                                openai.api_type = "azure"
                                # openai.api_key = "917dc709669349df85c7e8507265c2ec"
                                # openai.api_base = "https://openai-prod-east.openai.azure.com/"
                                openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
                                AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
                                openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
                                openai.api_version = "2024-05-01-preview"
                                deployment_name="GPT4o"
                                service_name = os.getenv('AZURE_SEARCH_SERVICE_NAME')
                                search_endpoint = f"https://{service_name}.search.windows.net"
                                admin_key = os.getenv('AZURE_SEARCH_API_KEY')

                                extra_info = {
                                    "data_points": "",
                                    "thoughts": f"Searched for:<br>{file_name}<br><br>Conversations:<br>"
                                }
                                system_message = {
                                        "role": "user",
                                        "content": f"give brief summary about {file_name}",
                                    }
                                docuqna_tokens, messages = self.get_messages_from_history(
                                    # system_message_chat_conversation,
                                    system_message,
                                    self.chatgpt_model,
                                    history,
                                    file_name,
                                    [],
                                    self.chatgpt_token_limit - len(file_name),
                                )
                                # index_name = f"{user_name.split('@')[0]}-index"
                                index_name1 = re.sub(r'[^a-zA-Z0-9]', '', user_name.split('@')[0])
                                index_name = f"{index_name1}"
                                
                                # Call the OpenAI API
                                chat_coroutine = await openai.ChatCompletion.acreate(
                                    messages=messages,
                                    engine="GPT4o",
                                    data_sources=[
                                        {
                                            "type": "azure_search",
                                            "parameters": {
                                                "endpoint": search_endpoint,
                                                "index_name": index_name,
                                                "semantic_configuration": "default",
                                                "role_information": f"you are an AI assistant that summarizes {file_name}. You have to strictly provide data for summary(however less it maybe) ,Never say 'This statement is reiterated multiple times throughout the document.' ",
                                                "strictness": 2,
                                                "top_n_documents": 15,
                                                "authentication": {
                                                    "type": "api_key",
                                                    "key": f"{admin_key}"
                                                },
                                            },
                                        }
                                    ],
                                    temperature=0,
                                    top_p=1,
                                    max_tokens=4096,
                                )

                                # Extract response content
                                response_content = chat_coroutine['choices'][0]['message']['content']
                                # Append filename and response to the list
                                responses.append({"file_name": file_name, "summary": response_content})
                                
                                def format_summaries(responses):
                                    formatted_responses = []
                                    for response in responses:
                                        summary = response.get("summary", "").strip()
                                        if summary.startswith("The requested information is not available"):
                                            formatted_responses.append("No relevant information found for the document.")
                                        else:
                                            # Optionally clean up reference tags like [doc1], [doc2]
                                            summary = re.sub(r'\[doc\d+\]', '', summary)
                                            formatted_responses.append(summary)
                                    return "\n\n".join(formatted_responses)
                                    
                                response_1 = format_summaries(responses)
                                    
                                response2=response_1
                                
                            AZURE_STORAGE_CONNECTION_STRING = os.getenv('AZURE_STORAGE_CONNECTION_STRING')

                            async def generate_previewable_url(file_name, expiry_hours=10):
                                """
                                Generate a previewable SAS URL for a file in Azure Blob Storage.

                                :param file_url: Full file URL containing the blob name and page fragment.
                                :param expiry_hours: Time in hours for which the SAS URL will remain valid.
                                :return: Previewable SAS URL with #page=<number> appended.
                                """
                                try:
                                    # Create BlobServiceClient
                                    blob_name = f"{user_name}/{file_name}"
                                    blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
                                    logging.debug(f"Blob service client initialized: {blob_service_client}")
                                    
                                    # Set SAS token expiry time
                                    sas_expiry_time = datetime.now().astimezone() + timedelta(hours=expiry_hours)
                                    logging.debug(f"SAS token expiry time: {sas_expiry_time}")
                                    source_container_name = os.getenv('AZURE_BULK_UPLOAD_CONTAINER_NAME')
                                    
                                    # Generate SAS token
                                    sas_token = generate_blob_sas(
                                        account_name=blob_service_client.account_name,
                                        container_name=source_container_name,
                                        blob_name=blob_name,
                                        account_key=blob_service_client.credential.account_key,
                                        permission=BlobSasPermissions(read=True),
                                        expiry=sas_expiry_time,
                                        content_disposition="inline",  # Open file in browser
                                        content_type="application/pdf"  # Adjust based on file type if necessary
                                    )
                                    logging.debug(f"SAS token generated: {sas_token}")
                                    
                                    
                                    # Construct the full SAS URL
                                    blob_url = f"https://{blob_service_client.account_name}.blob.core.windows.net/{source_container_name}/{user_name}/{file_name}?{sas_token}#page=1"
                                    # blob_url = f"https://{blob_service_client.account_name}.blob.core.windows.net/bulk-upload-qna/{blob_name}?{sas_token}#page={page_fragment}"
                                    logging.debug(f"Generated blob URL: {blob_url}")
                                    
                                    return blob_url
                                                                
                                except Exception as e:
                                    logging.error(f"Failed to generate the URL: {e}")
                                    return None
                                
                            preview_urls_list = []  # Initialize an empty list to store preview URLs

                            for file_name in file_names:
                                preview_url = await generate_previewable_url(file_name)  # Call the function to generate the URL
                                if preview_url:  # Ensure the function returned a valid URL
                                    preview_urls_list.append(preview_url)  
                            
                            # print(preview_urls_list)
                            #page_urls_list1 = preview_urls_list
                            page_urls_list1 = preview_urls_list                 
                        
                        elif any(re.search(pattern, user_q.lower()) for pattern in [
                            r"\blist\s+(?:the\s+)?documents?\b", 
                            r"\bcount\s+(?:the\s+)?documents?\b", 
                            r"\bshow\s+(?:the\s+)?documents?\b",
                            r"\bdisplay\s+(?:the\s+)?documents?\b",
                            r"\bhow\s+many\s+documents?\b", 
                            r"\bcount\s+of\s+documents?\b",
                            r"\bdocuments?\s+count\b",
                            r"\bnumber\s+of\s+documents?\b",
                            r"\bview\s+(?:all\s+)?documents?\b",
                            r"\bwhat\s+documents?\s+(?:do\s+i\s+have|are\s+there)\b"
                        ]):
                            print("Document listing/count pattern matched")
                            
                            file_count = str(len(file_names))
                            file_names_str = ", ".join(file_names)  # Convert list to a comma-separated string

                            # Debug statements to verify values
                            print(f"File Count: {file_count}")
                            print(f"File Names: {file_names_str}")

                            # Create a formatted list of documents
                            document_list = "\n".join([f"{i+1}. {file_name}" for i, file_name in enumerate(file_names)])
                            
                            # Build response with count and list
                            response1 = f"You have {file_count} document(s) uploaded.\n\nList of documents:\n{document_list}"
                            response2 = response1

                            # Set up extra_info with appropriate content
                            extra_info = {
                                "data_points": "",
                                "thoughts": f"Searched for:<br>{user_q}<br><br>Document count: {file_count}<br>"
                            }

                            page_urls_list1 = []                            
                            
                            flag = False


                        else:
                            flag = False
                            search_service_name = os.getenv('AZURE_SEARCH_SERVICE_NAME')
                            search_endpoint = f"https://{search_service_name}.search.windows.net"
                            deployement_id="GPT4o"
                            user_q = history[-1]["user"]
                            
                            
                            content = """
                            Answer in detail. Thoroughly search the provided context for relevant information before responding.
                            If you find limited or vague content, offer a polite explanation like: 'The documents mention [topic], but do not provide detailed steps. Would you like a general explanation instead?'
                            If the answer is missing completely, ask if the user wants to refine the query or remove the document for further assistance.
                            Ask any questions to clarify and improve user queries .
                            If the requested information is not available in the provided documents, respond with: "Your documents do not mention steps of {user_query}, but you can remove the document and I can give a general explanation if you wish to know."

                            """
                            content=content.format(user_query=user_q)
                            # System message configuration
                            system_message = {
                            "role": "system",
                            "content": content                            
                            }

                            docuqna_tokens, messages = self.get_messages_from_history(
                                # system_message_chat_conversation,
                                system_message,
                                self.chatgpt_model,
                                history,
                                user_q,
                                [],
                                self.chatgpt_token_limit - len(user_q),
                            )
                            
                            openai.api_type = "azure"                           
                            AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")                            
                            openai.api_key = os.getenv('AZURE_OPENAI_API_KEY')
                            openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com/"
                            openai.api_version = "2024-05-01-preview"
                            deployment_name="GPT4o"
                            service_name = os.getenv('AZURE_SEARCH_SERVICE_NAME')
                            search_endpoint = f"https://{service_name}.search.windows.net"
                            admin_key = os.getenv('AZURE_SEARCH_API_KEY')

                            extra_info = {
                                "data_points": "",
                                "thoughts": f"Searched for:<br>{user_q}<br><br>Conversations:<br>"
                            }
                            # index_name = f"{user_name.split('@')[0]}-index"
                            index_name1 = re.sub(r'[^a-zA-Z0-9]', '', user_name.split('@')[0])
                            index_name = f"{index_name1}"
                            # Call Azure Search API instead of OpenAI for larger files
                            chat_coroutine =  await openai.ChatCompletion.acreate(
                                messages=messages,
                                engine="GPT4o",

                                # deployment_id=deployment_id,
                                data_sources=[{
                                    "type": "azure_search",
                                    "parameters": {
                                        "endpoint": search_endpoint,
                                        "index_name": index_name,
                                        "semantic_configuration": "default",                                       
                                        "strictness": 3,
                                        "role_information": "You are an AI assistant that ONLY answers strictly based on the content retrieved from Azure Cognitive Search. DO NOT use outside knowledge. If the information is missing, clearly say: 'The requested information is not found in the provided documents.' Do not explain general concepts unless mentioned in context.",
                                        "top_n_documents": 15,
                                        "authentication": {
                                            "type": "api_key",
                                            "key": f"{admin_key}"
                                        }
                                        }
                                    }],
                                    temperature=0,
                                    top_p=1,
                                    max_tokens=4096,
                                )
                            page_urls_list = []
                            if "choices" in chat_coroutine:
                                for choice in chat_coroutine["choices"]:
                                    message = choice.get("message", {})
                                    context = message.get("context", {})
                                    citations = context.get("citations", [])
                                    for citation in citations:
                                        url = citation.get("url")  # Ensure this line is indented correctly
                                        if url:
                                            page_urls_list.append(url)

                            response_content = ""
                            response2=" "
                            response_1 = chat_coroutine['choices'][0]['message']['content']
                            response2=response_1
                            
                            if response_1.startswith("The requested information is not") or  response_1.startswith("The Dual Transformer Encoder (DTE)"):
                                
                                print("non_context")
                               
                                index_name1 = re.sub(r'[^a-zA-Z0-9]', '', user_name.split('@')[0])
                                index_name = f"{index_name1}"
                                service_name = os.getenv("AZURE_SEARCH_SERVICE_NAME")
                                api_key = os.getenv("AZURE_SEARCH_API_KEY")
                                endpoint = f"https://{service_name}.search.windows.net/"
                                credential = AzureKeyCredential(api_key)
                                client = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)

                                # Define your question
                                question = user_q

                                # Perform a semantic search in Azure Cognitive Search
                                results = client.search(
                                    search_text=question,                                    
                                    top=15,  # Retrieve the top 3 relevant documents
                                    select=[ "content", "title", "url", "page_number"]
                                )
                               
                                # Extract relevant data from the search results
                                data_for_gpt = []
                                for result in results:
                                    data_for_gpt.append({
                                        "content": result["content"],
                                        "title": result["title"],
                                        "url": result["url"],
                                        "page_number": result.get("page_number", None)
                                    })

                                if len(data_for_gpt) == 0:
                                    response2 = "The requested information is not found in the uploaded documents. You can try rephrasing your question or uploading additional documents if needed."
                                else:
                                    response2 = "The exact information you requested is not explicitly mentioned. However, here are some related excerpts I found:\n\n"
                                    for item in data_for_gpt[:2]:  # Show top 3 matches
                                        title = item.get('title', '')
                                        # page = item.get('page_number', 'N/A')
                                        content_snippet = item['content'][:100].strip().replace("\n", " ")
                                        response2 += f"**{title}**➡️ {content_snippet}...\n\n"

                                    response2 += "If this is not what you’re looking for, you can refine your question."
                                # response2=(response['choices'][0]['message']['content'])
                                AZURE_STORAGE_CONNECTION_STRING = os.getenv('AZURE_STORAGE_CONNECTION_STRING')

                            doc_references = re.findall(r'\[doc\d+\]', response_1)

                            # Remove the square brackets if needed
                            doc_references = [doc.strip('[]') for doc in doc_references]

                            # print(doc_references)
                            doc_to_index = {f'doc{i+1}': i for i in range(len(page_urls_list))}

                            # Extract URLs corresponding to the extracted document references
                            filtered_urls = [page_urls_list[doc_to_index[doc]] for doc in doc_references if doc in doc_to_index]

                           
                            AZURE_STORAGE_CONNECTION_STRING = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
                            
                            async def generate_previewable_url(file_url, expiry_hours=10):
                                """
                                Generate a previewable SAS URL for a file in Azure Blob Storage.

                                :param file_url: Full file URL containing the blob name and page fragment.
                                :param expiry_hours: Time in hours for which the SAS URL will remain valid.
                                :return: Previewable SAS URL with #page=<number> appended.
                                """
                                try:
                                    # Extract blob name and page number from the input URL
                                    blob_path = file_url.split("-qna/")[-1]  # Extract the full blob path after the domain
                                    blob_name, page_fragment = blob_path.split("#page=")  # Split blob name and page fragment
                                    
                                    # Remove any query parameters in the blob name
                                    blob_name = blob_name.split("?")[0]
                                    # print(blob_name,"blob_name")

                                    # Create BlobServiceClient
                                    blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
                                    logging.debug(f"Blob service client initialized: {blob_service_client}")
                                    
                                    # Set SAS token expiry time
                                    sas_expiry_time = datetime.now().astimezone() + timedelta(hours=expiry_hours)
                                    logging.debug(f"SAS token expiry time: {sas_expiry_time}")
                                    source_container_name = os.getenv('AZURE_BULK_UPLOAD_CONTAINER_NAME')
                             
                                    # Generate SAS token
                                    sas_token = generate_blob_sas(
                                        account_name=blob_service_client.account_name,
                                        container_name=source_container_name,
                                        blob_name=blob_name,
                                        account_key=blob_service_client.credential.account_key,
                                        permission=BlobSasPermissions(read=True),
                                        expiry=sas_expiry_time,
                                        content_disposition="inline",  # Open file in browser
                                        content_type="application/pdf"  # Adjust based on file type if necessary
                                    )
                                    logging.debug(f"SAS token generated: {sas_token}")
                                    
                                    # Construct the full SAS URL with the page fragment
                                    blob_url = f"https://{blob_service_client.account_name}.blob.core.windows.net/{source_container_name}/{blob_name}?{sas_token}#page={page_fragment}"
                                    logging.debug(f"Generated blob URL: {blob_url}")
                                    
                                    return blob_url
                                
                                except Exception as e:
                                    logging.error(f"Failed to generate the URL: {e}")
                                    return None
                                
                            preview_urls_list = []  # Initialize an empty list to store preview URLs

                            for url in filtered_urls:
                                preview_url = await generate_previewable_url(url)  # Call the function to generate the URL
                                if preview_url:  # Ensure the function returned a valid URL
                                    preview_urls_list.append(preview_url)  
                            
                            # print(preview_urls_list)
                            
                            page_urls_list1 = preview_urls_list
                    
                            # print(response_1,"response1")
                            
            return (extra_info, response2, flag, page_urls_list1) 

    async def run_with_streaming(self, 
        history: list[dict[str, str]], overrides: dict[str, Any], user_name,flag1: bool
    ) -> AsyncGenerator[dict, None]:
        """
        Handles streaming logic based on whether the user directory is empty or not.
        """
        
        
        if flag1:
            # Logic for when the directory is not empty
            extra_info, response1, flag, page_urls_list = await self.run_until_final_call_1(
                user_name, history, overrides, should_stream=True)
            
            
        else:
            # Logic for when its unstructred data
            extra_info, chat_coroutine, flag, page_urls_list = await self.run_until_final_call(
                user_name, history, overrides, should_stream=True
            )
         
        
        yield extra_info
        yield {"page_urls_list": page_urls_list}
        # yield page_urls_list
        if flag:
            yield chat_coroutine
                 

        else:
            response2= self.remove_citations(response1)
            if response2 == "The requested information is not available in the retrieved data. Please try another query or topic.":
                response2 = (
                "The requested information is not available in the retrieved data. "
                "If you would like to know about a specific topic or summarize a document, "
                "please specify the topic clearly or provide the document name."
           ) 
            chunk_size = 100  # Define the size of each chunk to stream
            text_len = len(response2)
    
            for i in range(0, text_len, chunk_size):
                chunk = response2[i:i+chunk_size]
                yield {"choices": [{"delta": {"content": chunk}}]} 



       
    def get_messages_from_history(
        self,
        system_prompt: str,
        model_id: str,
        history: list[dict[str, str]],
        user_conv: str,
        few_shots=[],
        max_tokens: int = 4096,
    ) -> list:
        message_builder = MessageBuilder(system_prompt, model_id)
          # Insert few-shot examples
        for shot in few_shots:
            # message_builder.insert_message(shot.get("role"), shot.get("content"))
            message_builder.append_message(shot.get("role"), shot.get("content"))
 
 
        # Insert current user conversation
        user_content = user_conv
        append_index = len(few_shots) + 1
        message_builder.insert_message(self.USER, user_content, index=append_index)
        total_token_count = message_builder.count_tokens_for_message(message_builder.messages[-1])
 
        
   
        newest_to_oldest = list(reversed(history[:-1]))
        for message in newest_to_oldest:
            potential_message_count = message_builder.count_tokens_for_message(message)
            print("potential_message_count:", potential_message_count)
            print("message:", message)
           
         #   print(message)
            if (total_token_count + potential_message_count) > max_tokens:
                #logging.debug("Reached max tokens of %d, history will be truncated", max_tokens)
                break
            if user_msg := message.get("user"):
                print("user_msg", user_msg)
                message_builder.insert_message(self.USER, user_msg, index=append_index)
            if bot_msg := message.get("bot"):
                message_builder.insert_message(self.ASSISTANT, bot_msg, index=append_index)
 
            total_token_count += potential_message_count
        return total_token_count,message_builder.messages

        # Insert few-shot examples
        # for shot in few_shots:
        #     message_builder.insert_message(shot.get("role"), shot.get("content"))

        # # Insert current user conversation
        # user_content = user_conv
        # append_index = len(few_shots) + 1
        # message_builder.insert_message(self.USER, user_content, index=append_index)
        # total_token_count = message_builder.count_tokens_for_message(message_builder.messages[-1])

        # # Handle the last message in history only
        # if history:
        #     last_two_messages = history[-1]
        #     if user_msg := last_two_messages.get("user"):
        #         message_builder.insert_message(self.USER, user_msg, index=append_index)
        #         total_token_count += message_builder.count_tokens_for_message(message_builder.messages[-1])
        #     if bot_msg := last_two_messages.get("bot"):
        #         message_builder.insert_message(self.ASSISTANT, bot_msg, index=append_index)
        #         total_token_count += message_builder.count_tokens_for_message(message_builder.messages[-1])

        # return (total_token_count, message_builder.messages)
    
        # newest_to_oldest = list(reversed(history[:-1]))
        # for message in newest_to_oldest:
        #     potential_message_count = message_builder.count_tokens_for_message(message)
        #     print("potential_message_count:", potential_message_count)
        #     print("message:", message)
            
        #  #   print(message)
        #     if (total_token_count + potential_message_count) > max_tokens:
        #         #logging.debug("Reached max tokens of %d, history will be truncated", max_tokens)
        #         break
        #     if user_msg := message.get("user"):
        #         print("user_msg", user_msg)
        #         message_builder.insert_message(self.USER, user_msg, index=append_index)

        # # Handle the last message in history only
        # # if history:
        # #     last_two_messages = history[-1]
        # #     if user_msg := last_two_messages.get("user"):
        # #         message_builder.insert_message(self.USER, user_msg, index=append_index)
        #         total_token_count += message_builder.count_tokens_for_message(message_builder.messages[-1])
        #     if bot_msg := message.get("bot"):
        #         message_builder.insert_message(self.ASSISTANT, bot_msg, index=append_index)
        #         total_token_count += message_builder.count_tokens_for_message(message_builder.messages[-1])


        

        # return (total_token_count, message_builder.messages)

    
        
    
    
    
    def api_call(self, user_q, agent_output):
        try:
            openai.api_type = "azure"
            # openai.api_key = "5d69dd6f0aa14121ae81066435443abf"
            openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
            AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
            # openai.api_base = "https://openai-poc-east.openai.azure.com/"
            openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
            openai.api_version = "2024-05-01-preview"
            user_prompt = """
                        Question : {}
                        
                        Answer : {}""".format(user_q, agent_output)

          #  print(user_prompt)
            
            response = openai.ChatCompletion.create(
                engine = "GPT4o",
                messages = [
                    {"role": "system", "content": """   
                                                    You are provided with the question and answer. 
                                                    Provide the answer as per the question. Examples are present under <Metadata> tag.                                             
                                                    Answer can be a value, dataframe, series, etc. 
                    
                                                    Most Important do not include any words in the response like "Answers:", "Answer:", "Results:", "Response:" etc. 

                                                    <Metadata>
                                                    Consider the below examples, provide such type of responses for the question and answer provided.
                                                    example :- 
                    
                                                    Question:- How many people are married.
                                                    Answer :- 2563
                                                    Response :- 2563 people are married.

                                                    Question :- how many people are there having T Stage less than T3, how many are having T stage as T2 and how many are married
                                                    Answer :- 3389, 1786, 1140
                                                    Response :- 3389 people are having T stage less than T3, 1786 are hacing T stage as T2, 1140 are having T stage T2 and are married.

                    
                                                    Question:- Average tumor size of married people.
                                                    Answer :- 30.87
                                                    Response :- Average tumor size for married people is 30.87
                    
                                                    Question :- Name all the unique countries present in sheet2
                                                    Answer :- india, australia, new zealand
                                                    Response: Here are the names of unique countries in sheet2 india, australia, new zealand.
                    
                                                        """},
                    {"role": "user", "content": user_prompt}
                ]
                )
            return(response['choices'][0]['message']['content'], response["usage"]["total_tokens"])
        except:
            return("""You might have asked something out of the context with the uploaded data, If not please be more specific in the input asked""", 0)

    
    def encode_image(self, image_path):
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8") 
        
    def api_call_img(self, message):
        try:
            
            openai.api_type = "azure"
            
            openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
           
            AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
            
            openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
            
            openai.api_version = "2024-02-15-preview"

            response = openai.ChatCompletion.create(
                        deployment_id="GPT4o",
                        messages=message,
                        temperature=0.0,
                        )
            return(response['choices'][0]['message']['content'], response["usage"]["total_tokens"])
        except:
            return("Please try again in some time", 0)
        
                
    def api_call_img_2(self, context, user_prompt):
        try:
            # base64_image = self.encode_image(img_path)
            openai.api_type = "azure"
            openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
            AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
            openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
           
            openai.api_version = "2024-02-15-preview"

            response = openai.ChatCompletion.create(
                        deployment_id="GPT4o",
                   messages = [
                    {"role": "system", "content": f"""You are given image textual information and user query, utilize only the provided information to generate response which is relevant to user question and remove other.
                                                    Include only those image names in citations from where information is getting extracted.
                                                    Do not add images names in the citations from which extracted information does not relate to the user prompt.
                                                    Include only image name from which question is asked in Citation. Do not provide any information that is not present in images.
                                                    Avoid citation when question is out of context. No citation when question is out of context.
                     
                                                    If context does not provide answer to the user query or if user query irrelavant to context, return "Please ask something from the image(s) uploaded".
                                                   
                                                    <context>
                                                    {context}
                                                    </context>
 
                                                    Follow the below response format:
 
                                                    <response>
                                                    The images provided indicate that the application requires admin approval to access resources in your organization. You need to contact an admin to grant permission.
                                                   
                                                    Citations:
                                                    \n* MicrosoftTeams-image.png
                                                    </response>
 
                                                    IMPORTANT: Make sure to follow above citation format!. Do not provide any information that is not present in the context
                                                    """},
                    {"role": "user", "content": user_prompt}
                ],

                        temperature=0.0,
                        )
            return(response['choices'][0]['message']['content'], response["usage"]["total_tokens"])
        except:
            return("Please try again in some time", 0)