# --------------------------------------------------------------------------------------------------------------------------
# Define Subscription
$subscriptionName = "DSI Apex"

$zipFileName = Read-Host "Enter the ZIP file name with extension: (zip file should be in the same directory as this script)"

# Ask the user for the environment
$environment = Read-Host "Enter the environment (dev/uat/prod)"

# Set resource group and app service based on environment
switch ($environment.ToLower()) {
    "dev" { 
        $resourceGroupName = "RG-PoC-OpenAI"
        $appServiceName = "dsi-general-assistant-dev"
    }
    "uat" { 
        $resourceGroupName = "RG-QA-OpenAI"
        $appServiceName = "chatdsi-general-assistant-uat"  
    }
    "prod" { 
        $resourceGroupName = "RG-Prod-OpenAI"
        $appServiceName = "dsi-general-assistant" 
    }
    default { 
        Write-Host "Invalid environment. Please enter dev, uat, or prod." -ForegroundColor Red
        exit 1
    }
}

Write-Host "Environment: $environment" -ForegroundColor Yellow
Write-Host "Resource Group: $resourceGroupName" -ForegroundColor Green
Write-Host "App Service Name: $appServiceName" -ForegroundColor Magenta



# Check if Azure CLI is installed
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Host "Azure CLI is not installed. Please install it first." -ForegroundColor Red
    exit 1
}

# Change to script directory (if possible)
if ($PSScriptRoot) {
    Set-Location $PSScriptRoot
}

# Login to Azure
$shouldLogin = Read-Host "Do you want to log in to Azure? (y/n)"

if ($shouldLogin.ToLower() -eq "y") {
    Write-Host "Logging in to Azure..."
    $loginResult = az login --output none 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Azure login failed. Please check your credentials." -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "Skipping Azure login as per user input." -ForegroundColor Cyan
}

# Check if subscription is already set
$currentSubscription = az account show --query "name" -o tsv
if (-not $currentSubscription -or $currentSubscription -ne $subscriptionName) {
    Write-Host "Setting Azure Subscription to $subscriptionName..."
    az account set --subscription "$subscriptionName"
}

# Show summary and ask for confirmation
Write-Host "`n===== Review Deployment Details =====" -ForegroundColor Cyan
Write-Host "Environment:        $environment"
Write-Host "Resource Group:     $resourceGroupName"
Write-Host "App Service Name:   $appServiceName"
Write-Host "ZIP File to Deploy: $zipFileName"
Write-Host "Subscription:       $subscriptionName"
Write-Host "=====================================`n"

$confirmation = Read-Host "Do you want to proceed with the deployment? (y/n)"
if ($confirmation.ToLower() -ne 'y') {
    Write-Host "Deployment cancelled by user." -ForegroundColor Yellow
    exit 0
}


# Get deployment start timestamp
$deploymentStartTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Write-Host "Deployment started at: $deploymentStartTime" -ForegroundColor Blue

# Deploy the ZIP file
Write-Host "Deploying $zipFileName to $appServiceName in $environment environment ($resourceGroupName)..."
$deployResult = az webapp deploy --name $appServiceName --resource-group $resourceGroupName --src-path $zipFileName 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "Deployment failed. Please check the error logs." -ForegroundColor Red
    Write-Host $deployResult
    exit 1
}

# Get deployment end timestamp
$deploymentEndTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Write-Host "Deployment completed successfully at: $deploymentEndTime" -ForegroundColor Green
Write-Host "Deployment to $environment finished!" -ForegroundColor Green
