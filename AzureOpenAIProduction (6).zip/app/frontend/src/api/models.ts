export const enum Approaches {
    General = "general",
    DocumentQNA = "docqna",
    Translate = "translate",
    ReadAloud = "readaloud"
}

export const enum RetrievalMode {
    Hybrid = "hybrid",
    Vectors = "vectors",
    Text = "text"
}

export type AskRequestOverrides = {
    modelType?: string;
    retrievalMode?: RetrievalMode;
    semanticRanker?: boolean;
    semanticCaptions?: boolean;
    excludeCategory?: string;
    top?: number;
    temperature?: number;
    promptTemplate?: string;
    promptTemplatePrefix?: string;
    promptTemplateSuffix?: string;
    suggestFollowupQuestions?: boolean;
};

export type AskRequest = {
    question: string;
    approach: Approaches;
    overrides?: AskRequestOverrides;
};

export type AskResponse = {
    session_id: any;
    status: string;
    answer: string;
    thoughts: string | null;
    data_points: string[];
    error?: string;
    page_urls_list?: string[];
};

export type ChatTurn = {
    user: string;
    bot?: string;
};

export type ChatRequest = {
    history: ChatTurn[];
    approach: Approaches;
    overrides?: AskRequestOverrides;
    language?: string;
    shouldStream?: boolean;
};

export type Access = {
    error?: string;
    hasModAccess: boolean;
};

export type FileUpload = {
    files: File[];
    uploadType?: boolean;
};

export type FileTranslate = {
    files: File[];
    languages: string[];
};

export type FileUploadResponse = {
    status: string;
    error?: string;
};
