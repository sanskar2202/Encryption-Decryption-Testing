import { useMemo, useState } from "react";
import { Stack, ActionButton, DefaultButton, PrimaryButton, Dialog, DialogType, DialogFooter, Dropdown, IDropdownOption } from "@fluentui/react";
import { IIconProps, initializeIcons } from "@fluentui/react";
import { TooltipHost, ITooltipHostStyles } from "@fluentui/react/lib/Tooltip";
import { IconButton } from "@fluentui/react/lib/Button";
import { useId } from "@fluentui/react-hooks";
import DOMPurify from "dompurify";
import styles from "./Answer.module.css";
import { AskResponse } from "../../api";
import { parseAnswerToHtml } from "./AnswerParser";
import { AnswerIcon } from "./AnswerIcon";
import rehypeRaw from "rehype-raw";
import rehypeHighlight from "rehype-highlight";
import Markdown from "react-markdown";
import "highlight.js/styles/github-dark.css";
import { saveAs } from "file-saver"; // For saving files
import { Document, Packer, Paragraph, TextRun } from "docx";
import jsPDF from "jspdf";
import React, { useEffect } from "react";
import japaneseFontFamily from "../../assets/NotoSansJP-Regular.ttf";
import "regenerator-runtime/runtime";
import { BsTranslate } from "react-icons/bs";
import { IoVolumeMediumOutline } from "react-icons/io5";
// import { FontSizes, IconButton } from "@fluentui/react";
import * as sdk from "microsoft-cognitiveservices-speech-sdk";
import { franc } from "franc";
import SpeechRecognition, { useSpeechRecognition } from "react-speech-recognition";
import { FaPauseCircle } from "react-icons/fa";
import { useRecoilState } from "recoil";
import { isSpeakingAtom } from "./atoms";
import { Typography, Button, Grid } from "@mui/material";
import OpenLink from "../DocumentPreview/DocumentPreview";
import { DocumentPreviewModal } from "../DocumentPreview/DocumentPreview copy";
import ArrowOutwardIcon from "@mui/icons-material/ArrowOutward";

interface Props {
    answer: AskResponse;
    onFollowupQuestionClicked: (question: string) => void;
    showFollowupQuestions?: boolean;
    isAnswerCompleted?: boolean;
    regenerateResponse?: boolean;
    regenerateQuestion: string;
    languageselected: string;
    readAloudCalled?: boolean;
    // isCitationPresent: boolean;
    // fileNames: string;
    pageUrls?: string[];
    onTranslate: (question: string, language: string) => void;
    onRead: (question: string) => void;
    onLanguageSelect: (language: string) => void;
}
const languageToVoiceMap: { [key: string]: string } = {
    eng: "en-US-AvaMultilingualNeural",
    cmn: "wuu-CN-XiaotongNeural",
    ces: "cs-CZ-VlastaNeural",
    dan: "da-DK-ChristelNeural",
    nld: "nl-NL-FennaNeural",
    fra: "fr-FR-DeniseNeural",
    deu: "de-DE-KatjaNeural",
    mag: "hi-IN-SwaraNeural",
    ita: "it-IT-ElsaNeural",
    jpn: "ja-JP-NanamiNeural",
    kor: "ko-KR-SunHiNeural",
    rus: "ru-RU-SvetlanaNeural",
    spa: "es-ES-ElviraNeural"
};
const speechConfig = sdk.SpeechConfig.fromSubscription("9fd3c452d25d4848a54f9d466f5dcefc", "eastus");
const audioConfig = sdk.AudioConfig.fromDefaultSpeakerOutput();
const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);
const languageOptions: IDropdownOption[] = [
    { key: "zh", text: "Chinese Simplified" },
    { key: "cs", text: "Czech" },
    { key: "da", text: "Danish" },
    { key: "nl", text: "Dutch" },
    { key: "en", text: "English" },
    { key: "fr", text: "French" },
    { key: "de", text: "German" },
    { key: "hi", text: "Hindi" },
    { key: "it", text: "Italian" },
    { key: "ja", text: "Japanese" },
    { key: "ko", text: "Korean" },
    { key: "ru", text: "Russian" },
    { key: "es", text: "Spanish" }
    // Add more languages as needed
];

export const Answer = ({
    answer,
    onFollowupQuestionClicked,
    showFollowupQuestions,
    isAnswerCompleted,
    regenerateResponse,
    regenerateQuestion,
    onTranslate,
    pageUrls
}: Props) => {
    const parsedAnswer = useMemo(() => parseAnswerToHtml(answer.answer), [answer]);
    // // console.log('Page URLs:', pageUrls);
    const uniqueLinks = Array.from(
        new Map(
            (pageUrls || []).map(url => {
                // Extract the portion of the URL before the query string or fragment
                const baseUrl = url.split("?")[0]; // Remove query parameters
                const cleanUrl = baseUrl.split("#")[0]; // Remove fragment

                // Extract the file name (before ".pdf")
                const urlParts = cleanUrl.split("/");
                const fileName = urlParts[urlParts.length - 1].split(".pdf")[0]; // Filename without extension

                // Extract the page number (after "#page=")
                const pageNumber = url.includes("#page=") ? url.split("#page=")[1] : null;

                // Create a unique key
                const key = `${fileName}#page=${pageNumber}`;
                return [key, { url, pageNumber, documentName: fileName }];
            })
        ).values()
    );

    const linksAndPageNumbers = Array.from(uniqueLinks);
    const sanitizeParsedAnswer = (answerHtml: string) => {
        //
        const citationRegex =
            /(\*\*Citations\*\*|\*\*引文\*\*|\*\*Citace\*\*|\*\*Citat\*\*|\*\*Citaat\*\*|\*\*Citer\*\*|\*\*Zitate\*\*|\*\*उद्धरण\*\*|\*\*Citazione\*\*|\*\*引用\*\*|\*\*인용\*\*|\*\*Цитата\*\*|\*\*Cita\*\*|\*\*Gänsefüßchen\*\*|\*\*Кавычки\*\*|\*\*Comillas\*\*|\*\*Цитаты\*\*|\*\*Citas\*\*|\*\*Datierung\*\*|\*\*引用符\*\*)/;
        const citationIndex = answerHtml.search(citationRegex);
        // const citationIndex = answerHtml.indexOf("**Zitate**"||"**Citation");
        //

        if (citationIndex !== -1) {
            return answerHtml.slice(0, citationIndex).trim();
        }
        return answerHtml; // Return the original if no citations found
    };

    const handleExportTXT = () => {
        const txtBlob = new Blob([parsedAnswer.answerHtml], { type: "text/plain;charset=utf-8" });
        saveAs(txtBlob, "response.txt");
    };

    function extractRelevantText(fullText: string): string {
        // Regex to match everything between **Citations** and **/Citations**
        const citationRegex = /\*\*Citations\*\*[\s\S]*?\*\*\/Citations\*\*/g;
        // Replace the citation with an empty string, leaving only the relevant text
        const cleanedText = fullText.replace(citationRegex, "").trim();
        return cleanedText;
    }
    const handleExportPDF = async () => {
        const doc = new jsPDF();
        const margin = 20; // Set your desired margin value
        const topMargin = margin; // Adjust this value to set the top margin
        const bottomMargin = margin; // Adjust this value to set the bottom margin
        let cursorY = topMargin;
        let remainingText = parsedAnswer.answerHtml;
        const lineHeight = 6; // Assuming a line height of 12 units (adjust as needed)
        const availableHeight = doc.internal.pageSize.height - topMargin - bottomMargin;

        const fontSize = 12; // Set your desired smaller font size
        doc.setFontSize(fontSize);
        const fontUrl = japaneseFontFamily;
        // Fetch the TTF font file as an ArrayBuffer
        const fontBytes = await fetch(fontUrl).then(res => res.arrayBuffer());
        // Convert the ArrayBuffer to a Base64 string
        const base64String = btoa(new Uint8Array(fontBytes).reduce((data, byte) => data + String.fromCharCode(byte), ""));
        doc.addFileToVFS("NotoSansJP-Regular.ttf", base64String);
        doc.addFont("NotoSansJP-Regular.ttf", "NotoSansJP", "normal");
        doc.setFont("NotoSansJP");
        const addNewPage = () => {
            doc.addPage();
            cursorY = topMargin;
        };
        const lines = doc.splitTextToSize(remainingText, doc.internal.pageSize.width - 2 * margin);
        lines.forEach((line: string) => {
            if (cursorY + lineHeight > availableHeight) {
                addNewPage();
            }
            doc.text(line, margin, cursorY);
            cursorY += lineHeight;
        });
        doc.save("response.pdf");
    };

    const preprocessHTML = (html: string): string => {
        const processedHtml = html.replace(/\n/g, "<br>");
        return processedHtml;
    };
    const [responseText, setResponseText] = useState("");
    const detectLanguage = async (): Promise<string> => {
        try {
            // Detect language code
            // const detectedLanguage: string = franc(textString, { minLength: 3 });
            const newtext = extractRelevantText(textString);
            const detectedLanguage: string = franc(newtext, { minLength: 3 });
            //
            const languageMap: Record<string, string> = {
                eng: "en-US",
                eng_gb: "en-GB",
                eng_au: "en-AU",
                spa: "es-ES",
                spa_mx: "es-MX",
                spa_us: "es-US",
                fra: "fr-FR",
                fra_ca: "fr-CA",
                deu: "de-DE",
                ita: "it-IT",
                por: "pt-PT",
                por_br: "pt-BR",
                rus: "ru-RU",
                zho: "zh-CN",
                zho_hk: "zh-HK",
                zho_tw: "zh-TW",
                jpn: "ja-JP",
                kor: "ko-KR",
                ara: "ar-SA",
                ara_eg: "ar-EG",
                nld: "nl-NL",
                hin: "hi-IN",
                ben: "bn-IN",
                urd: "ur-PK",
                ell: "el-GR",
                tur: "tr-TR",
                heb: "he-IL",
                pol: "pl-PL",
                dan: "da-DK",
                swe: "sv-SE",
                fin: "fi-FI",
                nor: "nb-NO",
                tha: "th-TH",
                vie: "vi-VN",
                ind: "id-ID",
                ces: "cs-CZ", // Czech (Czech Republic)
                sco: "sco", // Scots (No specific locale; use 'sco')
                bho: "hi-IN",
                sot: "st-ZA",
                som: "en-US",
                cmn: "zh-CN" // Indonesian (Indonesia)// German
            };
            const defaultLanguage: string = "en-US";
            const languageName: string = languageMap[detectedLanguage] || defaultLanguage;
            if (languageMap[detectedLanguage] === undefined) {
                return "undefined";
            }
            //

            return languageName; // return the detected language
        } catch (err) {
            setResponseText("I'm sorry, I couldn't process that request. Could you try again?");
            return "en-US"; // return default if detection fails
        }
    };
    const { resetTranscript } = useSpeechRecognition();
    const [isSpeaking, setIsSpeaking] = useRecoilState(isSpeakingAtom);
    useEffect(() => {
        if (isSpeaking) {
        }
    }, [isSpeaking]);
    const handleSpeech = async (): Promise<void> => {
        resetTranscript();
        //
        const detectedLanguage: string = await detectLanguage();
        // const detectedLanguage = franc(textString, { minLength: 3 });

        if (detectedLanguage === "undefined") {
            const utterance: SpeechSynthesisUtterance = new SpeechSynthesisUtterance("I don't speak this language");
            window.speechSynthesis.speak(utterance);
            return;
        }

        // Use the detected language directly
        const newtext = extractRelevantText(textString);
        const utterance: SpeechSynthesisUtterance = new SpeechSynthesisUtterance(newtext);
        // const utterance: SpeechSynthesisUtterance = new SpeechSynthesisUtterance(textString);
        utterance.lang = detectedLanguage;
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        window.speechSynthesis.speak(utterance);
    };
    const handleStopSpeaking = () => {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
    };

    const handleExportDOCX = async () => {
        const processedHtml = preprocessHTML(parsedAnswer.answerHtml);
        const tempElement = document.createElement("div");
        tempElement.innerHTML = processedHtml;

        // Extract text content
        const paragraphs = Array.from(tempElement.childNodes).map(node => {
            if (node.nodeType === Node.TEXT_NODE) {
                return new Paragraph({
                    children: [new TextRun(node.textContent || "")]
                });
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                const element = node as HTMLElement;
                const textRuns = Array.from(element.childNodes).map(childNode => {
                    if (childNode.nodeType === Node.TEXT_NODE) {
                        return new TextRun(childNode.textContent || "");
                    } else if (childNode.nodeType === Node.ELEMENT_NODE) {
                        const childElement = childNode as HTMLElement;
                        return new TextRun(childElement.innerText);
                    } else {
                        return new TextRun("");
                    }
                });
                return new Paragraph({
                    children: textRuns
                });
            } else {
                return new Paragraph({
                    children: [new TextRun("")]
                });
            }
        });

        // Create document
        const doc = new Document({
            sections: [
                {
                    properties: {},
                    children: paragraphs
                }
            ]
        });

        // Generate blob
        const blob = await Packer.toBlob(doc);

        saveAs(blob, "response.docx");
    };

    const [showOptions, setShowOptions] = useState(false);
    const [isTranslating, setIsTranslating] = useState(false);
    const [exportFormat, setExportFormat] = useState<string | undefined>(undefined);
    const pdftooltipId = useId("tooltip_pdf");
    const wordtooltipID = useId("tooltip_word");
    const texttooltipID = useId("tooltip_txt");

    const hostStyles: Partial<ITooltipHostStyles> = {
        root: {
            display: "inline-block"
        }
    };
    initializeIcons();
    const wordIcon: IIconProps = { iconName: "WordDocument" };
    const pdfIcon: IIconProps = { iconName: "PDF" };
    const txtIcon: IIconProps = { iconName: "TextDocument" };
    const [isTranslateDialogVisible, setIsTranslateDialogVisible] = useState(false);
    const [selectedLanguage, setSelectedLanguage] = useState<string | undefined>(undefined);
    const showTranslateDialog = () => setIsTranslateDialogVisible(true);
    const hideTranslateDialog = () => setIsTranslateDialogVisible(false);
    const handleLanguageChange = (event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption) => {
        setSelectedLanguage(option?.key as string);
    };
    const [readAloudCalled, setReadAloudCalled] = useState(false);
    const textString: string = parsedAnswer.answerHtml || "";
    useEffect(() => {
        if (readAloudCalled) {
            // makeApiRequest(lastQuestionRef.current);
            const detectedLang = franc(textString, { minLength: 3 });

            const voice = languageToVoiceMap[detectedLang] || "en-US-AriaNeural";
            speechConfig.speechSynthesisVoiceName = voice;

            synthesizer.speakTextAsync(
                textString,
                () => {},
                () => {}
            );
            setReadAloudCalled(false); // Reset after the call
        }
    }, [readAloudCalled]);
    const handleTranslate = () => {
        if (selectedLanguage && !isTranslating) {
            // Handle translation logic here
            setIsTranslating(true);

            onTranslate(regenerateQuestion, selectedLanguage);
            hideTranslateDialog();
        }
    };
    const [openModal, setOpenModal] = useState(false);
    const [currentUrl, setCurrentUrl] = useState("");
    const handleOpenModal = (url: string) => {
        setCurrentUrl(url);
        setOpenModal(true);
    };
    const handleCloseModal = () => setOpenModal(false);

    return (
        <Stack className={`${styles.answerContainer}`} verticalAlign="space-between">
            <Stack.Item>
                <Stack horizontal horizontalAlign="space-between">
                    <AnswerIcon />
                    {!isAnswerCompleted && (
                        <>
                            <Stack horizontal>
                                <IconButton
                                    style={{ fontSize: "20px", background: "none", alignItems: "baseline" }}
                                    iconProps={regenerateResponse ? { iconName: "Read Aloud" } : { iconName: "" }} // Only set the icon when regenerateResponse is true
                                    title={isSpeaking ? "Stop Reading" : "Start Reading"}
                                    onClick={isSpeaking ? handleStopSpeaking : handleSpeech}
                                    disabled={!regenerateResponse} // Disable the button if regenerateResponse is false
                                >
                                    {regenerateResponse && (isSpeaking ? <FaPauseCircle /> : <IoVolumeMediumOutline />)}
                                </IconButton>

                                <IconButton
                                    style={{ fontSize: "20px", background: "none", alignItems: "baseline" }}
                                    title="Translate"
                                    onClick={() => {
                                        showTranslateDialog(); // Call showTranslateDialog function if needed
                                    }}
                                    disabled={regenerateResponse ? false : true}
                                >
                                    <BsTranslate />
                                </IconButton>

                                <ActionButton
                                    style={{ color: "black", background: "none" }}
                                    iconProps={regenerateResponse ? { iconName: "Refresh" } : { iconName: "" }}
                                    title="Regenerate"
                                    ariaLabel="Refresh"
                                    onClick={() => {
                                        handleStopSpeaking();
                                        onFollowupQuestionClicked(regenerateQuestion);
                                    }}
                                    disabled={regenerateResponse ? false : true}
                                ></ActionButton>
                                <ActionButton
                                    style={{ color: "black", background: "none" }}
                                    iconProps={{ iconName: "Copy" }}
                                    title="Copy to clipboard"
                                    ariaLabel="Copy Code content"
                                    onClick={() => {
                                        navigator.clipboard.writeText(parsedAnswer.answerHtml);
                                    }}
                                    disabled={isAnswerCompleted ? true : false}
                                ></ActionButton>
                                <ActionButton
                                    style={{ color: "black", background: "none" }}
                                    iconProps={{ iconName: "Download" }}
                                    title="Export"
                                    onClick={() => setShowOptions(!showOptions)}
                                ></ActionButton>
                                {showOptions && (
                                    <Stack horizontal tokens={{ childrenGap: 10 }}>
                                        <TooltipHost content="PDF" id={pdftooltipId} styles={hostStyles}>
                                            <div>
                                                <IconButton
                                                    style={{
                                                        color: "red"
                                                    }}
                                                    onClick={handleExportPDF}
                                                    iconProps={pdfIcon}
                                                ></IconButton>
                                            </div>
                                        </TooltipHost>
                                        <TooltipHost content="TXT" id={texttooltipID} styles={hostStyles}>
                                            <div>
                                                <IconButton
                                                    style={{
                                                        color: "black"
                                                    }}
                                                    onClick={handleExportTXT}
                                                    iconProps={txtIcon}
                                                ></IconButton>
                                            </div>
                                        </TooltipHost>
                                        <TooltipHost content="DOCX" id={wordtooltipID} styles={hostStyles}>
                                            <div>
                                                <IconButton
                                                    style={{
                                                        color: "blue"
                                                    }}
                                                    onClick={handleExportDOCX}
                                                    iconProps={wordIcon}
                                                ></IconButton>
                                            </div>
                                        </TooltipHost>
                                    </Stack>
                                )}
                            </Stack>
                        </>
                    )}
                </Stack>
            </Stack.Item>

            {
                <>
                    <Stack.Item grow className={`${styles.answerStackItem}`}>
                        <Markdown rehypePlugins={[rehypeRaw as any, rehypeHighlight]}>{sanitizeParsedAnswer(parsedAnswer.answerHtml)}</Markdown>
                    </Stack.Item>
                    {!!parsedAnswer.followupQuestions.length && showFollowupQuestions && onFollowupQuestionClicked && (
                        <Stack.Item className={`${styles.answerStackItem}`}>
                            <Stack horizontal wrap className={`${styles.followupQuestionsList}`} tokens={{ childrenGap: 6 }}>
                                <span className={styles.followupQuestionLearnMore}>Follow-up questions:</span>
                                {parsedAnswer.followupQuestions.map((x, i) => {
                                    return (
                                        <a key={i} className={styles.followupQuestion} title={x} onClick={() => onFollowupQuestionClicked(x)}>
                                            {`${x}`}
                                        </a>
                                    );
                                })}
                            </Stack>
                        </Stack.Item>
                    )}
                    {pageUrls && !isAnswerCompleted && (
                        // {
                        <>
                            <Stack horizontal tokens={{ childrenGap: 10 }}>
                                <Grid container spacing={2}>
                                    {linksAndPageNumbers.map(({ url, pageNumber, documentName }, index) => (
                                        <Grid
                                            item
                                            xs={12}
                                            sm={4}
                                            key={index}
                                            sx={{
                                                maxWidth: "fit-content",
                                                flexShrink: 0 // Prevent shrinking in a flex container
                                            }}
                                        >
                                            <Button
                                                variant="contained"
                                                color="primary"
                                                onClick={() => handleOpenModal(url ?? "")}
                                                size="small"
                                                disableElevation
                                                endIcon={<ArrowOutwardIcon />}
                                                sx={{
                                                    backgroundColor: "#c9eef6",
                                                    color: "#000",
                                                    padding: "2px 10px",
                                                    borderRadius: "4px",
                                                    textTransform: "none",
                                                    fontFamily: "inherit",
                                                    fontSize: "11px",
                                                    "&:hover": {
                                                        backgroundColor: "#7ce5fb"
                                                    },
                                                    "& .MuiButton-endIcon svg": {
                                                        marginLeft: "-4px",
                                                        fontSize: "16px",
                                                        color: "#0078d4"
                                                    }
                                                }}
                                            >
                                                {pageNumber != null ? `${documentName} : page ${pageNumber}` : `${documentName}`}
                                            </Button>
                                            <DocumentPreviewModal open={openModal} onClose={handleCloseModal} documentUrl={currentUrl ?? ""} />
                                        </Grid>
                                    ))}
                                </Grid>
                            </Stack>
                        </>
                    )}
                </>
            }
            <Dialog
                hidden={!isTranslateDialogVisible}
                onDismiss={hideTranslateDialog}
                dialogContentProps={{
                    type: DialogType.largeHeader,
                    title: "Translate",
                    subText: "Select the language you want to translate the response to."
                }}
            >
                <Dropdown placeholder="Select a language" options={languageOptions} onChange={handleLanguageChange} />
                <DialogFooter>
                    <PrimaryButton
                        onClick={() => {
                            handleStopSpeaking();
                            handleTranslate();
                        }}
                        text="Translate"
                    />
                    <DefaultButton onClick={hideTranslateDialog} text="Cancel" />
                </DialogFooter>
            </Dialog>
        </Stack>
    );
};
