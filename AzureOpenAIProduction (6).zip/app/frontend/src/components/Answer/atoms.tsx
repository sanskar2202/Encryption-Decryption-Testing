import { atom } from "recoil";

export const isSpeakingAtom = atom<boolean>({
    key: "isSpeakingAtom",
    default: false
});

export const fileSizeExceededAtom = atom<{
    fileSizeExceeded: boolean;
    totalSize: number;
}>({
    key: 'fileUploadState',
    default: {
        fileSizeExceeded: false,
        totalSize: 0,
    },
});



