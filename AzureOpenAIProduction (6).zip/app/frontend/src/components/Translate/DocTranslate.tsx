import React, { useState } from "react";
import "./DocTranslate.css";
import { Box } from "@mui/material";
import { BsTranslate } from "react-icons/bs";
import { FontSizes, IconButton } from "@fluentui/react";

interface Option {
    value: string;
    label: string;
}

const options: Option[] = [
    { value: "ja", label: "Japanese" },
    { value: "es", label: "Spanish" },
    { value: "ru", label: "Russian" },
    { value: "zh", label: "Chinese" },
    { value: "de", label: "German" },
    { value: "fr", label: "French" },
    { value: "ko", label: "Korean" },
    { value: "hi", label: "Hindi" },
    { value: "cs", label: "Czech" },
    { value: "da", label: "Danish" },
    { value: "nl", label: "Dutch" },
    { value: "en", label: "English" },
    //   { value: "ga", label: "Irish" },
    { value: "it", label: "Italian" }
    // Add more options as needed
];

interface TranslateDropdownProps {
    onTranslateRequest: (event: React.FormEvent, selectedLanguages: string[]) => void;
    disabled: boolean;
    files: File[];
    isTranslating: boolean;
    translateEnabled: boolean;
}

const TranslateDropdown: React.FC<TranslateDropdownProps> = ({ onTranslateRequest, files, isTranslating, translateEnabled }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
    const [searchTerm, setSearchTerm] = useState("");

    const handleButtonClick = () => {
        setIsOpen(!isOpen);
    };

    const handleOptionClick = (value: string) => {
        setSelectedOptions(prevSelectedOptions => {
            if (prevSelectedOptions.includes(value)) {
                return prevSelectedOptions.filter(option => option !== value);
            } else if (prevSelectedOptions.length < 3) {
                return [...prevSelectedOptions, value];
            } else {
                return prevSelectedOptions;
            }
        });
    };

    const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(event.target.value);
    };

    const handleTranslate = (event: React.FormEvent) => {
        event.preventDefault();
        onTranslateRequest(event, selectedOptions);
        setIsOpen(false);
    };

    const filteredOptions = options.filter(option => option.label.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
        <div className="dropdown">
            <Box sx={{ width: "50%" }}>
                
            <button
                    onClick={handleButtonClick}
                    className={files.length !== 1 ? "buttonSubmitDisabled" : "buttonSubmitEnabled"}
                    disabled={files.length !== 1}
                    type="button"
                    title="Translate"
                >
                    TRANSLATE
                </button>
            </Box>
            {isOpen && (
                <div className="dropdown-menu dropup">
                    <Box
                        sx={{
                            overflowY: "auto"
                        }}
                    >
                        <div className="dropdown-header">
                            <h3>Choose up to three languages</h3>
                            <input type="text" placeholder="Search..." value={searchTerm} onChange={handleSearchChange} className="search-input" />
                            <div className="total-languages">Total languages: {options.length}</div>
                        </div>
                        <div className="dropdown-content">
                            {filteredOptions.map(option => (
                                <div key={option.value} className="dropdown-item">
                                    <input
                                        type="checkbox"
                                        id={option.value}
                                        checked={selectedOptions.includes(option.value)}
                                        onChange={() => handleOptionClick(option.value)}
                                        disabled={!selectedOptions.includes(option.value) && selectedOptions.length >= 3}
                                    />
                                    <label htmlFor={option.value}>{option.label}</label>
                                </div>
                            ))}
                        </div>
                    </Box>
                    <Box
                        sx={{
                            height: "auto"
                        }}
                    >
                        {/* <div className="doc-translate"> */}
                        <button
                            onClick={handleTranslate}
                            className={selectedOptions.length === 0 || files.length !== 1 ? "buttonSubmitDisabled" : "buttonSubmitEnabled"}
                            disabled={selectedOptions.length === 0 || files.length !== 1}
                            // className={selectedOptions.length === 0 || files.length === 0 ? "buttonSubmitDisabled" : "buttonSubmitEnabled"}
                            // disabled={selectedOptions.length === 0 || files.length === 0}
                            type="submit"
                            title="Submit and Translate"
                        >
                            Submit and Translate
                        </button>
                        {/* </div> */}
                        {/* <button
                onClick={handleTranslate}
                className={selectedOptions.length === 0 || files.length === 0 ? "button-disabled" : "button-enabled"}
                disabled={selectedOptions.length === 0 || files.length === 0}
            >
                Submit and Translate
            </button> */}
                    </Box>
                </div>
            )}
            {/* {selectedOptions.length > 0 && (
        <div className="selected-options">
          <strong>Selected:</strong> {selectedOptions.map(optionValue => options.find(option => option.value === optionValue)?.label).join(", ")}
        </div>
      )} */}
        </div>
    );
};

export default TranslateDropdown;
