import * as React from "react";
import { useMediaQuery, useTheme } from "@mui/material";
import "./FileUpload.css";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import { TextField, Divider, Backdrop, CircularProgress, Snackbar, Alert, Tooltip, AlertTitle } from "@mui/material";
import { ArrowUpload24Regular, CheckmarkCircle24Filled, Dismiss24Regular, DeleteDismiss24Filled, Box20Filled } from "@fluentui/react-icons";
import Dropzone from "react-dropzone";
// import FileUploadIcon from "@mui/icons-material/FileUpload";
import { AiOutlineFile } from "react-icons/ai";
import { display } from "html2canvas/dist/types/css/property-descriptors/display";
import TranslateDropdown from "../Translate/DocTranslate";
import { useState, useEffect } from "react";
import { FileUpload, translateApi } from "../../api";
import { Separator, Stack, ActionButton } from "@fluentui/react";
import { saveAs } from "file-saver";
// import { BlobServiceClient } from "@azure/storage-blob";
import { TfiDownload } from "react-icons/tfi";
import drop from "/src/assets/drop.svg";
interface Props {
    open: boolean;
    fileNames: string[];
    isEmbeddingsLoading: boolean;
    embeddingsLoaded: boolean;
    openAlert: boolean;
    translateOpenAlert: boolean;
    openWarning: boolean;
    infoAlert: boolean;
    openDocClearAlert: boolean;
    openDocClearAlertForTranslate: boolean;
    handleCloseModal: () => void;
    handleSubmitFile: (event: React.FormEvent, uploadType?: boolean) => void;
    handleFileUpload: (uploadedFiles: File[]) => void;
    handleAlertClose: () => void;
    // handleWarningClose: () => void;
    clearEmbeddings: () => void;
    deleteEmbeddings: () => void;
    deleteTranslate: () => void;
    openSnackbar: boolean;
    snackbarMessage: string;
    handleSnackbarClose: () => void;
    translateEnabled: boolean;
    // handleinfoAlertClose: () => void;
    files: File[];
    handleTranslateRequest: (event: React.FormEvent, languages: string[]) => void;
    translatedURL: { [key: string]: string };
    targetBlobClient: string;
    connString: string;
    targetContainer: string;
    translatedFolder: string;
    isTranslating: boolean;
    translatedFileName: string;
    fileSelector: string;
    setOpenSnackbar: (value: boolean) => void;
    setSnackbarMessage: (value: string) => void;
    // languages: string[];
}

interface Option {
    value: string;
    label: string;
}

export default function FileTranslateModal({
    open,
    fileNames,
    isEmbeddingsLoading,
    embeddingsLoaded,
    openAlert,
    translateOpenAlert,
    openWarning,
    infoAlert,
    openDocClearAlert,
    openDocClearAlertForTranslate,
    handleCloseModal,
    handleSubmitFile,
    handleFileUpload,
    handleAlertClose,
    // handleWarningClose,
    // handleinfoAlertClose,
    clearEmbeddings,
    deleteEmbeddings,
    deleteTranslate,
    openSnackbar,
    snackbarMessage,
    handleSnackbarClose,
    translateEnabled,
    files,
    handleTranslateRequest,
    translatedURL,
    targetBlobClient,
    connString,
    targetContainer,
    translatedFolder,
    isTranslating,
    translatedFileName,
    setOpenSnackbar,
    setSnackbarMessage,
    fileSelector
}: Props) {
    const [selectedfileName, setSelectedFileName] = useState<string>();
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error" | "info" | "warning">("info");
    const fetchData = () => {
        if (translatedFolder.length > 1) {
            const decodedUrl = translatedURL; // translatedURL is expected to be an object with language codes as keys

            if (decodedUrl) {
                const urlElements = Object.entries(decodedUrl).map(([lang, urlArr]) => {
                    const url = urlArr[0]; // Assuming there's one URL per language
                    return (
                        <div key={lang}>
                            <Typography variant="body2">
                                {lang.toUpperCase()}:{" "}
                                <a href={url} target="_blank" rel="noopener noreferrer">
                                    {url}
                                </a>
                            </Typography>
                        </div>
                    );
                });

                // Assuming you want to set these URL elements somewhere else
                // setUrlElements(urlElements);

                // Extract the file name from the first URL
                const firstUrl = Object.values(decodedUrl)[0][0]; // Take the first URL
                const urlSegments = firstUrl.split("/");

                const fileNameWithExtension = urlSegments[urlSegments.length - 1];

                const dotIndex = fileNameWithExtension.lastIndexOf(".");

                const fileName = dotIndex !== -1 ? fileNameWithExtension.substring(0, dotIndex) : fileNameWithExtension;

                const extension = dotIndex !== -1 ? fileNameWithExtension.substring(dotIndex + 1) : "";

                // setSelectedFileName(fileName + "_" + "languages" + "." + extension);
            }
        }
    };

    const downloadDoc = async (translatedURL: string) => {
        const response = await fetch(translatedURL);
        if (!response.ok) {
            throw new Error("Network response was not ok");
        }
        const blob = await response.blob();

        fetchData();

        if (translatedFolder.length > 1) {
            const decodedUrl = decodeURIComponent(translatedURL);
            const urlSegments = decodedUrl.split("/");

            // const urlSegments = translatedURL.split("/");
            const fileNameWithExtension = urlSegments[urlSegments.length - 1];
            const dotIndex = fileNameWithExtension.lastIndexOf(".");

            const fileName = dotIndex !== -1 ? fileNameWithExtension.substring(0, dotIndex) : fileNameWithExtension;
            const extension = dotIndex !== -1 ? fileNameWithExtension.substring(dotIndex + 1) : "";

            const extractLanguageCode = (translatedFolder: string): string | null => {
                // Define the regular expression to match the pattern
                const regex = /_([a-z]{2})_\d+$/;

                // Execute the regex on the translatedFolder string
                const match = translatedFolder.match(regex);

                // If there's a match, return the first capturing group (the language code)
                if (match && match[1]) {
                    return match[1];
                }

                // If no match, return null
                return null;
            };

            const languageCode = extractLanguageCode(translatedFolder);

            // return { fileName, extension };
        }
        // const deleteTargetContainerResponse = await doctranslateApi(request);

        const fileNameExt = "";
        const target_folder_file_path = translatedFolder + "/" + fileNameExt;
    };

    const options: Option[] = [
        { value: "ja", label: "Japanese" },
        { value: "es", label: "Spanish" },
        { value: "ru", label: "Russian" },
        { value: "zh", label: "Chinese" },
        { value: "de", label: "German" },
        { value: "fr", label: "French" },
        { value: "ko", label: "Korean" },
        { value: "hi", label: "Hindi" },
        { value: "cs", label: "Czech" },
        { value: "da", label: "Danish" },
        { value: "nl", label: "Dutch" },
        { value: "en", label: "English" },
        { value: "ga", label: "Irish" },
        { value: "it", label: "Italian" }
        // Add more options as needed
    ];

    const downloadDocument = async (url: string) => {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error("Failed to download file");
            }
            const blob = await response.blob();

            // Extract the file name from the URL
            const urlSegments = url.split("/");
            const fileNameWithExtension = urlSegments[urlSegments.length - 1];

            // Use the original file name and extension
            saveAs(blob, fileNameWithExtension);
        } catch (error) {
            console.error("Error downloading the file: ", error);
        }
    };
    //
    const languageMap = new Map<string, string>(options.map(option => [option.value, option.label]));
    const theme = useTheme();
    const isSmallScreen = useMediaQuery("(max-width:700px)");
    return (
        <div>
            <Modal
                open={open}
                onClose={handleCloseModal}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                slots={{
                    backdrop: Backdrop
                }}
                slotProps={{
                    backdrop: {
                        style: { backgroundColor: "rgba(0, 0, 0, 0.25)" }
                    }
                }}
            >
                <Box>
                    <Box className="upload-box">
                        <Button
                            variant="text"
                            onClick={handleCloseModal}
                            sx={{
                                position: "absolute",
                                right: "2%",
                                padding: 0, // Remove any padding
                                minWidth: "auto", // Allow the button to shrink to fit its content
                                width: "auto", // Ensure the button width is auto
                                height: "auto", // Ensure the button height is auto
                                display: "flex", // Ensure the button content is centered
                                alignItems: "center", // Center the content vertically
                                justifyContent: "center" // Center the content horizontally
                            }}
                        >
                            <Dismiss24Regular />
                        </Button>

                        <Box
                            sx={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                width: "100%" // Ensure the Box takes the full width of its container
                            }}
                        >
                            <Typography id="modal-modal-title" variant="h6" component="h2">
                                {fileSelector === "translate" ? "Translate Document" : "none"}
                            </Typography>
                        </Box>

                        {/* <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                        Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
                    </Typography> */}
                        {isTranslating && (
                            <Backdrop open={isTranslating} style={{ zIndex: 1200 }}>
                                <CircularProgress color="inherit" />
                            </Backdrop>
                        )}
                        <form onSubmit={handleSubmitFile}>
                            <Box sx={{ px: 2, m: 2, height: "80%" }}>
                                <Dropzone
                                    onDrop={acceptedFiles => {
                                        const totalSize = acceptedFiles.reduce((acc, file) => acc + file.size, 0);
                                        const maxSize = 1; // 200 MB in bytes
                                        const supportedFormats = [
                                            "application/pdf",
                                            "text/plain",
                                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                            "text/csv",
                                            "application/vnd.ms-excel",
                                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                        ];
                                        const validFiles = acceptedFiles.filter(file => supportedFormats.includes(file.type));
                                        const invalidFiles = acceptedFiles.filter(file => !supportedFormats.includes(file.type));
                                        const totalFiles = validFiles.length;

                                        if (invalidFiles.length > 0) {
                                            setSnackbarMessage(
                                                "Some selected file(s) are unsupported. Only valid files (PDF, PPT, DOCX, TXT, CSV, XLSX) will be processed."
                                            );
                                            setSnackbarSeverity("warning");
                                            setOpenSnackbar(true);
                                        }

                                        // if (totalSize > maxSize) {
                                        //     setSnackbarMessage("Total file size of valid files exceeds 10 MB. Please upload smaller files.");
                                        //     setSnackbarSeverity("error");
                                        //     setOpenSnackbar(true);
                                        if (totalFiles > 1) {
                                            setSnackbarMessage("Upload only 1 file.");
                                            setSnackbarSeverity("error");
                                            setOpenSnackbar(true);
                                        } else if (validFiles.length > 0) {
                                            handleFileUpload(validFiles); // Process only valid files
                                        }
                                    }}
                                >
                                    {({ getRootProps, getInputProps }) => (
                                        <Box
                                            {...getRootProps()}
                                            className="center-column"
                                            sx={{
                                                height: 360,
                                                width: "100%",
                                                p: 2,
                                                border: "1px dashed grey",
                                                borderTop: "4px solid #0197f6",
                                                borderRadius: "16px"
                                            }}
                                        >
                                            <input {...getInputProps()} />
                                            <Box>
                                                {fileNames.length > 0 ? (
                                                    <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                        <AiOutlineFile style={{ fontSize: 30, margin: "auto", marginTop: 30, marginBottom: 10 }} />
                                                        <Typography sx={{ m: "auto" }}>Selected file:</Typography>
                                                        <ul>
                                                            {fileNames.map((name, index) => (
                                                                <li key={index}>{name}</li>
                                                            ))}
                                                        </ul>
                                                    </Box>
                                                ) : (
                                                    // <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                    //     {/* <FileUploadIcon style={{ fontSize: 30 }} /> */}
                                                    //     <ArrowUpload24Regular style={{ fontSize: 30, margin: "auto", marginTop: 30, marginBottom: 10 }} />
                                                    //     {fileSelector === "translate" && (
                                                    //         <Typography sx={{ m: "auto", textAlign: "center", wordWrap: "break-word", width: "100%" }}>
                                                    //             Drag and drop a file or Click to browse
                                                    //             <br />
                                                    //             <br />
                                                    //             Supported file formats:
                                                    //             <br />
                                                    //             PDF, TXT, DOCX, PPTX, CSV, XLSX
                                                    //             <br />
                                                    //             <br />
                                                    //             <Typography sx={{ fontSize: "0.95rem" }}>
                                                    //                 *Disclaimer: Uploaded files are for translation only, not for queries.
                                                    //             </Typography>
                                                    //             <br />
                                                    //         </Typography>
                                                    //     )}

                                                    //     <Typography sx={{ m: "auto" }}>{"[Total File Size Limit: 10MB]"}</Typography>
                                                    // </Box>
                                                    <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                        <Typography
                                                            variant="body2"
                                                            sx={{
                                                                color: "#9E9D9D",
                                                                textAlign: "center",
                                                                paddingBottom: "3px",
                                                                margin: "auto",
                                                                width: "80%",
                                                                fontSize: "14px"
                                                            }}
                                                        >
                                                            {/* <span style={{ fontWeight: "bold" }}>Disclaimer:</span> The information provided on this
                                                                    platform is for general informational purposes only. All content is provided in good faith;
                                                                    however, we make no representation or warranty of any kind regarding the accuracy, adequacy,
                                                                    validity, reliability, or completeness of any information on the site. */}
                                                            <br />
                                                            Total file size limit is <span style={{ fontWeight: "bold" }}>10 MB</span> for successful upload.
                                                        </Typography>

                                                        <Box
                                                            component="img"
                                                            src={drop}
                                                            alt="Dropzone upload"
                                                            sx={{
                                                                width: "auto",
                                                                height: 180
                                                            }}
                                                        />
                                                        <Typography
                                                            sx={
                                                                isSmallScreen
                                                                    ? {
                                                                          display: "inline",
                                                                          fontWeight: "bold",
                                                                          mx: "auto",
                                                                          fontSize: 11,
                                                                          textAlign: "center"
                                                                      }
                                                                    : {
                                                                          m: "1rem auto",
                                                                          textAlign: "center",
                                                                          wordWrap: "break-word",
                                                                          width: "100%",
                                                                          fontSize: "20px"
                                                                      }
                                                            }
                                                        >
                                                            Drag and drop your file here for{" "}
                                                            <span style={{ textDecoration: "underline", fontWeight: "600" }}>Translation</span>
                                                            <br />
                                                            Supported File Formats: (PDF, TXT, DOCX, PPTX, CSV, XLSX)
                                                            <Typography sx={{ fontSize: "0.95rem" }}>
                                                                *Disclaimer: Uploaded file is for translation only, not for queries.
                                                            </Typography>
                                                        </Typography>
                                                    </Box>
                                                )}
                                            </Box>
                                        </Box>
                                    )}
                                </Dropzone>
                                {embeddingsLoaded && (
                                    <Box sx={{ marginTop: -4, marginLeft: 1 }}>
                                        <CheckmarkCircle24Filled color="green" />
                                    </Box>
                                )}
                            </Box>
                            {translatedFolder.length > 1 && (
                                <Stack horizontal>
                                    <Typography sx={{ m: "auto", textAlign: "center" }}>
                                        <i>File(s) translated by AI</i>
                                        <br />
                                        {translatedFolder.length === 1 ? (
                                            <div>
                                                <Typography component="span">Document:</Typography>
                                                <Button
                                                    variant="contained"
                                                    color="primary"
                                                    onClick={() => downloadDocument(Object.values(translatedURL)[0][0])}
                                                    sx={{ ml: 1, minWidth: 40 }}
                                                >
                                                    <TfiDownload />
                                                </Button>
                                            </div>
                                        ) : (
                                            <>
                                                Translated Documents:
                                                <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                                                    {Object.keys(translatedURL).map((lang, index) => (
                                                        <div key={index} style={{ display: "flex", alignItems: "center", gap: 4 }}>
                                                            <Typography component="span">
                                                                {languageMap.get(lang)?.toUpperCase() || lang.toUpperCase()}:
                                                            </Typography>
                                                            <Button
                                                                variant="contained"
                                                                color="primary"
                                                                onClick={() => downloadDocument(translatedURL[lang])}
                                                                sx={{ minWidth: 40 }}
                                                            >
                                                                <TfiDownload />
                                                            </Button>
                                                        </div>
                                                    ))}
                                                </div>
                                            </>
                                        )}
                                    </Typography>
                                </Stack>
                            )}

                            <Box sx={{ py: 4 }}>
                                <Typography variant="h6"></Typography>
                                <Divider />
                            </Box>
                            {/* </Box> */}
                            {/* </div> */}
                        </form>
                        <div className="center-column-translate">
                            {fileSelector === "file" || fileSelector === "image" ? (
                                <>
                                    <button
                                        className={files.length === 0 ? "buttonSubmitDisabled" : "buttonSubmitEnabled"}
                                        onClick={handleSubmitFile}
                                        type="submit"
                                        title="Submit"
                                    >
                                        SUBMIT
                                    </button>
                                    <div style={{ width: "100%" }}></div>
                                </>
                            ) : fileSelector === "translate" ? (
                                <TranslateDropdown
                                    onTranslateRequest={handleTranslateRequest}
                                    disabled={files.length > 1} // Disable translate button if more than one file is uploaded
                                    files={files}
                                    isTranslating={isTranslating}
                                    translateEnabled={translateEnabled}
                                />
                            ) : null}
                            <Tooltip title="Delete File" placement="right">
                                <Button
                                    sx={{ width: "200px", opacity: files.length === 0 ? 0.4 : 1 }}
                                    className={files.length === 0 && Object.keys(translatedURL).length === 0 ? "deleteDisabled" : ""}
                                >
                                    <DeleteDismiss24Filled color="red" onClick={deleteTranslate} />
                                </Button>
                            </Tooltip>
                            {/* </Box> */}
                        </div>

                        <Backdrop sx={{ color: "#fff", zIndex: theme => theme.zIndex.drawer + 4 }} open={isEmbeddingsLoading}>
                            <CircularProgress color="inherit" />
                        </Backdrop>
                    </Box>
                    <Box
                        sx={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            marginRight: "10%",
                            Top: "10%"
                        }}
                    >
                        <Snackbar
                            open={translateOpenAlert}
                            autoHideDuration={null}
                            onClose={handleAlertClose}
                            anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        >
                            {/* <Alert onClose={handleAlertClose} severity="success" sx={{ width: "100%" }}> */}
                            <Alert severity="success" sx={{ width: "100%" }}>
                                File Translated Successfully!
                            </Alert>
                        </Snackbar>
                        <Snackbar open={openAlert} autoHideDuration={null} onClose={handleAlertClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                            {/* <Alert onClose={handleAlertClose} severity="success" sx={{ width: "100%" }}> */}
                            <Alert severity="success" sx={{ width: "100%" }}>
                                File uploaded successfully!
                            </Alert>
                        </Snackbar>
                        <Snackbar
                            open={openDocClearAlertForTranslate}
                            autoHideDuration={12000}
                            onClose={handleAlertClose}
                            anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        >
                            <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                                The uploaded file is deleted
                            </Alert>
                        </Snackbar>
                        <Snackbar
                            open={openSnackbar} // State controlling whether the Snackbar is open
                            autoHideDuration={null}
                            onClose={handleAlertClose} // Function to handle closing the Snackbar
                            anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        >
                            <Alert severity="error" sx={{ width: "100%" }}>
                                {snackbarMessage}
                            </Alert>
                        </Snackbar>
                    </Box>
                    {/* </Box> */}
                </Box>
            </Modal>
            {/* <Snackbar open={openDocClearAlert} autoHideDuration={12000} onClose={handleAlertClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                    The uploaded file is deleted
                </Alert>
            </Snackbar> */}
            <Snackbar open={infoAlert} autoHideDuration={6000} onClose={handleAlertClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                    File with size above 5MB takes more time to process, Please be patient !
                </Alert>
            </Snackbar>
        </div>
    );
}
