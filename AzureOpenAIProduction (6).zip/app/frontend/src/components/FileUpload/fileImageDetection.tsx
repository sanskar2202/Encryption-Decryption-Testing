import JSZip from "jszip";
import { PDFDocument } from "pdf-lib";
import mammoth from "mammoth";
import * as pdfjsLib from "pdfjs-dist";
import { GlobalWorkerOptions } from "pdfjs-dist";
// import { GlobalWorkerOptions } from "pdfjs-dist";
// import pdfWorker from "pdfjs-dist/build/pdf.worker.min.js";
//  import workerSrc from "pdfjs-dist/build/pdf.worker.mjs";
// GlobalWorkerOptions.workerSrc = workerSrc;
// GlobalWorkerOptions.workerSrc = pdfWorker;
// GlobalWorkerOptions.workerSrc = pdfWorker;

// Set the workerSrc to a CDN-hosted worker file
// GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.9.155/pdf.worker.min.js`;

// pdfjsLib.GlobalWorkerOptions.workerSrc = "./pdf.worker.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();

interface ImageDetectionResult {
    images: string[]; // Array of image URLs (Data URLs)
}

const resetState = () => {
    // This function clears any global or module-level states if needed.
    //// console.log("State has been reset.");
};

const fileImageDetection = async (file: File): Promise<ImageDetectionResult> => {
    // Reset state on every call
    resetState();

    const fileType = file.type;
    let images: string[] = [];

    try {
        if (fileType === "application/pdf") {
            // Handle PDF files
            images = await extractImagesFromPDF(file);
            // // console.log(`Number of images detecteds: ${images}`);
        } else if (file.name.endsWith(".docx")) {
            // Handle DOCX files
            images = await extractImagesFromDOCX(file);
        } else if (file.name.endsWith(".pptx")) {
            // Handle PPTX files
            images = await extractImagesFromPPTX(file);
        } else {
            throw new Error("Unsupported file type");
        }
    } catch (error) {
        console.error("Error detecting images:", error);
        // Optionally, provide user feedback
    }

    return { images };
};
/////////////////////////////
const extractImagesFromPDF = async (file: File): Promise<string[]> => {
    const arrayBuffer = await file.arrayBuffer();
    const images: string[] = [];

    try {
        // Load PDF document using pdf.js
        const pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
        const numPages = pdfDoc.numPages;

        for (let pageNum = 1; pageNum <= numPages; pageNum++) {
            const page = await pdfDoc.getPage(pageNum);

            // Extract operator list to detect image-related operations
            const operatorList = await page.getOperatorList();
            const imageOperators = operatorList.fnArray.filter((fn: number) =>
                [pdfjsLib.OPS.paintInlineImageXObject, pdfjsLib.OPS.paintImageXObject].includes(fn)
            );

            if (imageOperators.length > 0) {
                // Use the page's viewport to get the size
                const viewport = page.getViewport({ scale: 1 });

                // Create a canvas to render the page content
                const canvas = document.createElement("canvas");
                canvas.width = viewport.width;
                canvas.height = viewport.height;

                const context = canvas.getContext("2d");
                if (!context) continue;

                // Render the page onto the canvas
                const renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };
                await page.render(renderContext).promise;

                // Extract image data from the rendered canvas
                const imageDataUrl = canvas.toDataURL("image/png");
                images.push(imageDataUrl);
            }
        }
    } catch (error) {
        console.error("Error extracting images from PDF:", error);
        throw error; // Re-throw the error for higher-level handling
    }

    return images;
};

/////////////////////////////
// const extractImagesFromPDF = async (file: File): Promise<string[]> => {
//   const arrayBuffer = await file.arrayBuffer();
//   const images: string[] = [];

//   try {
//     // Load PDF document using pdf.js
//     const pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
//     const numPages = pdfDoc.numPages;

//     for (let pageNum = 1; pageNum <= numPages; pageNum++) {
//       const page = await pdfDoc.getPage(pageNum);

//       // Use the page's viewport to get the size
//       const viewport = page.getViewport({ scale: 1 });

//       // Create a canvas to render the page content
//       const canvas = document.createElement("canvas");
//       canvas.width = viewport.width;
//       canvas.height = viewport.height;

//       const context = canvas.getContext("2d");
//       if (!context) continue;

//       // Render the page onto the canvas
//       const renderContext = {
//         canvasContext: context,
//         viewport: viewport,
//       };
//       await page.render(renderContext).promise;

//       // Extract image data from the rendered canvas
//       const imageDataUrl = canvas.toDataURL("image/png");
//       images.push(imageDataUrl);
//     }

//   } catch (error) {
//     console.error("Error extracting images from PDF:", error);
//     throw error; // Re-throw the error for higher-level handling
//   }

//   return images;
// };

/////////////////////////////
// const extractImagesFromPDF = async (file: File): Promise<string[]> => {
//   const arrayBuffer = await file.arrayBuffer();
//   const images: string[] = [];

//   try {
//     // Load PDF document using pdf.js
//     const pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
//     const numPages = pdfDoc.numPages;

//     for (let pageNum = 1; pageNum <= numPages; pageNum++) {
//       const page = await pdfDoc.getPage(pageNum);

//       // Extract operator list to detect images
//       const operatorList = await page.getOperatorList();
//       const imageOperators = operatorList.fnArray.map((fn: number, index: number) => {
//         if ([pdfjsLib.OPS.paintInlineImageXObject, pdfjsLib.OPS.paintImageXObject].includes(fn)) {
//           return operatorList.argsArray[index];
//         }
//         return null;
//       }).filter((arg) => arg !== null);

//       // Convert each detected image into a Data URL
//       for (const imageArgs of imageOperators) {
//         const canvas = document.createElement("canvas");
//         const context = canvas.getContext("2d");
//         if (context && imageArgs) {
//           const [imageData] = imageArgs;
//           canvas.width = imageData.width;
//           canvas.height = imageData.height;
//           const imageBitmap = await createImageBitmap(imageData);
//           context.drawImage(imageBitmap, 0, 0);
//           images.push(canvas.toDataURL());
//         }
//       }
//     }

//   } catch (error) {
//     console.error("Error extracting images from PDF:", error);
//     throw error; // Re-throw the error for higher-level handling
//   }

//   return images;
// };

///////////////////////////////////////////////////////////////////////////
// const extractImagesFromPDF = async (file: File): Promise<number> => {
//   const arrayBuffer = await file.arrayBuffer();
//   // console.log(arrayBuffer, "arrayBufer");
//   const images: string[] = [];
//   // console.log(images, "images");

//   let extractedText = "";
//   // let totalImages: string[] = [];
//   let totalImages = 0;

//   try {
//       // console.log("inside try block");
//       // Load PDF document using pdf.js
//       const pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
//       // console.log(pdfDoc, "pdfDoc");
//       const numPages = pdfDoc.numPages;
//       // console.log(`Number of pages in the PDF: ${numPages}`);

//       for (let pageNum = 1; pageNum <= numPages; pageNum++) {
//           const page = await pdfDoc.getPage(pageNum);

//           // Extract text content
//           const textContent = await page.getTextContent();
//           const pageText = textContent.items.map((item: any) => item.str).join(" ");
//           extractedText += `Page ${pageNum} Text:\n${pageText}\n\n`;

//           // Detect images
//           const operatorList = await page.getOperatorList();
//           const imageOperators = operatorList.fnArray.filter(
//               (fn: number) => [pdfjsLib.OPS.paintInlineImageXObject, pdfjsLib.OPS.paintImageXObject].includes(fn)
//               // [pdfjsLib.OPS.paintJpegXObject, pdfjsLib.OPS.paintImageXObject].includes(fn)
//           );

//           totalImages += imageOperators.length;
//       }

//       // console.log(totalImages, "totalImages");
//       // console.log(extractedText, "extractedText");
//       // alert(extractedText);
//       alert(totalImages);

//       if (extractedText != "") {
//           alert("text  present");
//       } else {
//           alert("text not preseent");
//       }

//       if (totalImages == 0) {
//           images.push("");
//       } else {
//           images.push("image present");
//       }

//       // //existing code - commenting to test it
//       // // Extract images using canvas rendering
//       // const canvas = document.createElement("canvas");
//       // const context = canvas.getContext("2d");

//       // if (context) {
//       //     const viewport = page.getViewport({ scale: 1.0 });
//       //     canvas.height = viewport.height;
//       //     canvas.width = viewport.width;

//       //     // Render page to canvas
//       //     await page.render({
//       //         canvasContext: context,
//       //         viewport: viewport
//       //     }).promise;

//       //     // Get image data URL from canvas
//       //     const imageDataUrl = canvas.toDataURL();
//       //     images.push(imageDataUrl);
//       // } else {
//       //     throw new Error("Failed to get canvas context");
//       // }
//       // }
//   } catch (error) {
//       console.error("Error extracting images from PDF:", error);
//       throw error; // Re-throw the error for higher-level handling
//   }

//   // return totalImages;
//   return totalImages;
// };

////////////////////////////////////////////////////////////////////////////////

// // Extract images from PDF using pdf.js (without worker)
// const extractImagesFromPDF = async (file: File): Promise<string[]> => {
//   const arrayBuffer = await file.arrayBuffer();
//   const images: string[] = [];

//   try {
//     // Load PDF document using pdf.js
//     const pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
//     const numPages = pdfDoc.numPages;
//     // console.log(`Number of pages in the PDF: ${numPages}`);

//     for (let pageNum = 1; pageNum <= numPages; pageNum++) {
//       const page = await pdfDoc.getPage(pageNum);

//       // Extract images using canvas rendering
//       const canvas = document.createElement("canvas");
//       const context = canvas.getContext("2d");

//       if (context) {
//         const viewport = page.getViewport({ scale: 1.0 });
//         canvas.height = viewport.height;
//         canvas.width = viewport.width;

//         // Render page to canvas
//         await page.render({
//           canvasContext: context,
//           viewport: viewport,
//         }).promise;

//         // Get image data URL from canvas
//         const imageDataUrl = canvas.toDataURL();
//         images.push(imageDataUrl);
//       } else {
//         throw new Error("Failed to get canvas context");
//       }
//     }
//   } catch (error) {
//     console.error("Error extracting images from PDF:", error);
//     throw error; // Re-throw the error for higher-level handling
//   }

//   return images;
// };

// Extract images from DOCX
const extractImagesFromDOCX = async (file: File): Promise<string[]> => {
    const arrayBuffer = await file.arrayBuffer();
    const zip = await JSZip.loadAsync(arrayBuffer);
    const images: string[] = [];
    // let images =0;

    try {
        // Extract images from DOCX
        const imageFiles = Object.keys(zip.files).filter(path => path.startsWith("word/media/"));
        for (const imagePath of imageFiles) {
            const fileData = await zip.files[imagePath].async("blob");
            const imageDataUrl = URL.createObjectURL(fileData);
            images.push(imageDataUrl);
        }
    } catch (error) {
        console.error("Error extracting images from DOCX:", error);
        throw error; // Re-throw the error for higher-level handling
    }

    return images;
};

// Extract images from PPTX
const extractImagesFromPPTX = async (file: File): Promise<string[]> => {
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const images: string[] = [];

    try {
        // Extract images from PPTX
        const imageFiles = Object.keys(zip.files).filter(path => path.startsWith("ppt/media/"));
        for (const imagePath of imageFiles) {
            const fileData = await zip.files[imagePath].async("blob");
            const imageDataUrl = URL.createObjectURL(fileData);
            images.push(imageDataUrl);
        }
    } catch (error) {
        console.error("Error extracting images from PPTX:", error);
        throw error; // Re-throw the error for higher-level handling
    }

    return images;
};

export default fileImageDetection;
