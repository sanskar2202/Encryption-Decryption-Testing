import * as React from "react";
import { AlertColor, useMediaQuery, useTheme } from "@mui/material";
import "./FileUpload.css";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import { TextField, Divider, Backdrop, CircularProgress, Snackbar, Alert, Tooltip, InputAdornment, IconButton, AlertTitle } from "@mui/material";
import { ArrowUpload24Regular, CheckmarkCircle24Filled, Dismiss24Regular, DeleteDismiss24Filled, Box20Filled } from "@fluentui/react-icons";
import { FaLinkSlash } from "react-icons/fa6";
import Dropzone from "react-dropzone";
// import FileUploadIcon from "@mui/icons-material/FileUpload";
import { AiOutlineFile } from "react-icons/ai";
import { display } from "html2canvas/dist/types/css/property-descriptors/display";
import TranslateDropdown from "../Translate/DocTranslate";
import { useState, useEffect } from "react";
import { FileUpload, translateApi } from "../../api";
import { Separator, Stack, ActionButton } from "@fluentui/react";
import { saveAs } from "file-saver";
// import { BlobServiceClient } from "@azure/storage-blob";
import { TfiDownload } from "react-icons/tfi";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import imageupicon from "/src/assets/imageupicon.png";
import SharePointLogo from "/src/assets/SharePoint-Logo.png";
import fileupload from "/src/assets/fileupload.png";
import excelupload from "/src/assets/excelupload.png";
import docxIcon from "/src/assets/docxIconpng.png";
import pptxicon from "/src/assets/pptxicon.png";
import drop from "/src/assets/drop.svg";
import imageUpload from "/src/assets/image-upload.svg";
import spuploadbanner from "/src/assets/spupload.png";
import { processSharePointFilesApi, getSharePointFileListApi } from "../../api";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useRecoilValue } from "recoil";
import { fileSizeExceededAtom } from "../../components/Answer/atoms";
import config from "../../../config.json"
import { useSetRecoilState } from "recoil";
import FileSizeExceededPopup from "../WarningPopup/FileSizeExceededPopup";
import CustomAlert, { SnackbarPosition } from "../Custom Alerts/CustomAlert";
import { useGlobalAlerts } from "../Custom Alerts/GlobalAlertsProvider";

interface Props {
    open: boolean;
    fileNames: string[];
    isEmbeddingsLoading: boolean;
    isFileProcessed: boolean;
    isUploadClicked: boolean;
    setIsUploadClicked: (value: boolean) => void;
    setIsCancelled: (value: boolean) => void;
    isCancelled: boolean;
    embeddingsLoaded: boolean;
    openAlert: boolean;
    translateOpenAlert: boolean;
    openWarning: boolean;
    infoAlert: boolean;
    isUploadEnabled: boolean;
    setIsUploadEnabled: (value: boolean) => void;
    openDocClearAlert: boolean;
    handleCloseModal: () => void;
    handleSubmitFile: (event: React.FormEvent) => void;
    handleSubmitFileforCSV_Excel_and_Images: (event: React.FormEvent) => void;
    handleFileUpload: (uploadedFiles: File[]) => void;
    handleAlertClose: () => void;
    fileUploadValidity: () => void;
    deleteEmbeddings: () => void;
    deleteEmbeddingsforcitaions: () => void;
    openSnackbar: boolean;
    snackbarMessage: string;
    handleSnackbarClose: () => void;
    translateEnabled: boolean;
    openFESnackbar: boolean;
    FEsnackbarMessage: string;
    files: File[];
    handleTranslateRequest: (event: React.FormEvent, languages: string[]) => void;
    imageAlert: { isActive: boolean; imageCount: number };
    targetBlobClient: string;
    connString: string;
    targetContainer: string;
    isTranslating: boolean;
    fileSelector?: string;
    onTabChange: (label: string) => void;
    disableFUIcon: boolean;
    disableFUIconn: boolean;
    disableIUIcon: boolean;
    disableExcelIcon: boolean;
    disableSharePointIcon: boolean;
    isUploading: boolean;
    // languages: string[];
    sharepointloaded: boolean;
    setSharepointloaded: (value: boolean) => void;
    inputhsharepointurl: boolean;
    setinputhsharepointurl: (value: boolean) => void;
    setOpenSnackbar: (value: boolean) => void;
    setSnackbarMessage: (value: string) => void;
    isImageAlertProcessed: boolean;
    setIsImageAlertProcessed: (value: boolean) => void;
    openFSnackbar: boolean;
    snackbarFMessage: string;
    setOpenFSnackbar: (value: boolean) => void;
    isProceedClicked: boolean;
    setIsProceedClicked: (value: boolean) => void;
    setIsProceedClickedImages: (value: boolean) => void;
    isProceedClickedImages: boolean;
    isSPProceedClicked: boolean;
    setIsSPProceedClicked: (value: boolean) => void;
    setIsSPProceedClickedImages: (value: boolean) => void;
    isSPProceedClickedImages: boolean;
    handleUploadStart: () => void;
    activePopUp: string | null;
    setActivePopUp: (value: string | null) => void;
    sharepointFilesLoaded: boolean;
    setSharepointFilesLoaded: (value: boolean) => void;
}

interface Option {
    value: string;
    label: string;
}

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
}
function TabPanel(props: TabPanelProps) {
    const { children, value, index, ...other } = props;
    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`vertical-tabpanel-${index}`}
            aria-labelledby={`vertical-tab-${index}`}
            {...other}
            // style={{ width: "100%", minHeight: "500px" }}
            className="tab-panel"
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

export default function FileUploadModal({
    open,
    fileNames,
    isEmbeddingsLoading,
    isFileProcessed,
    activePopUp,
    setActivePopUp,
    isUploading,
    isUploadClicked,
    setIsUploadClicked,
    setIsCancelled,
    isCancelled,
    isProceedClicked,
    setIsProceedClicked,
    isProceedClickedImages,
    setIsProceedClickedImages,
    isSPProceedClicked,
    setIsSPProceedClicked,
    setIsSPProceedClickedImages,
    isSPProceedClickedImages,
    handleUploadStart,
    embeddingsLoaded,
    openAlert,
    translateOpenAlert,
    infoAlert,
    openDocClearAlert,
    handleCloseModal,
    handleSubmitFile,
    handleSubmitFileforCSV_Excel_and_Images,
    handleFileUpload,
    handleAlertClose,
    disableFUIcon,
    disableFUIconn,
    disableIUIcon,
    disableExcelIcon,
    deleteEmbeddings,
    imageAlert,
    openSnackbar,
    snackbarMessage,
    files,
    isTranslating,
    onTabChange,
    sharepointloaded,
    setSharepointloaded,
    inputhsharepointurl,
    setinputhsharepointurl,
    disableSharePointIcon,
    setSnackbarMessage,
    setOpenSnackbar,
    FEsnackbarMessage,
    openFESnackbar,
    openFSnackbar,
    snackbarFMessage,
    isImageAlertProcessed,
    setIsImageAlertProcessed,
    setOpenFSnackbar,
    fileUploadValidity,
    isUploadEnabled,
    setIsUploadEnabled,
    sharepointFilesLoaded,
    setSharepointFilesLoaded,
    deleteEmbeddingsforcitaions
}: Props) {
    const options: Option[] = [
        { value: "ja", label: "Japanese" },
        { value: "es", label: "Spanish" },
        { value: "ru", label: "Russian" },
        { value: "zh", label: "Chinese" },
        { value: "de", label: "German" },
        { value: "fr", label: "French" },
        { value: "ko", label: "Korean" },
        { value: "hi", label: "Hindi" },
        { value: "cs", label: "Czech" },
        { value: "da", label: "Danish" },
        { value: "nl", label: "Dutch" },
        { value: "en", label: "English" },
        { value: "ga", label: "Irish" },
        { value: "it", label: "Italian" }
        // Add more options as needed
    ];
    const [newFileuploaded, setnewFileuploaded] = useState<boolean>(false);
    const getFileIcon = (filename: string): string | JSX.Element => {
        const extension = filename.split(".").pop()?.toLowerCase();
        switch (extension) {
            case "pdf":
                return "📄"; // PDF icon
            case "docx":
                return <img src={docxIcon} alt="Document Icon" style={{ width: "1.5rem", height: "1.5rem", marginRight: "8px", borderRadius: "4px" }} />;
            case "pptx":
                return <img src={pptxicon} alt="PPT Icon" style={{ width: "1.5rem", height: "1.5rem", marginRight: "8px", borderRadius: "4px" }} />; // PPTX icon pptxicon
            case "xls":
                return <img src={excelupload} alt="Excel Icon" style={{ width: "1.5rem", height: "1.5rem", marginRight: "8px", borderRadius: "4px" }} />; // Excel icon
            default:
                return "📄"; // Default file icon
        }
    };

    function a11yProps(index: number) {
        return {
            id: `vertical-tab-${index}`,
            "aria-controls": `vertical-tabpanel-${index}`
        };
    }

    const tabLabels = ["file", "image", "excel", "SharePoint"];

    const [value, setValue] = React.useState(0); // Initialize the state
    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
        setValue(newValue);

        const selectedLabel = tabLabels[newValue];
        onTabChange(selectedLabel);
        
    };

    const [sharePointUrl, setSharePointUrl] = useState<string>("");
    const [sharePointData, setSharePointData] = useState<any[]>([]);
    const [selectedItems, setSelectedItems] = useState<any[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [showPassword, setShowPassword] = useState(false);
    const [folderPath, setFolderPath] = useState<string>("");

    const handleClickShowPassword = () => {
        setShowPassword(prev => !prev);
    };

    useEffect(() => {
        if (openFSnackbar) {
            setSnackbarOpen(true);
            setSnackbarOpen(openFSnackbar);
            setSnackbarMessage(snackbarFMessage);
            setOpenFSnackbar(false);
        }
    }, [openFSnackbar, snackbarFMessage]);
    const { setAlertConfig } = useGlobalAlerts();

    const handleSubmitSharePointUrl = async () => {
        setLoading(true);
        try {
            if (!sharePointUrl) {
                setAlertConfig({
                    open: true,
                    message: "Please enter a valid SharePoint URL.",
                    severity: "error",                    
                  })
                return;
            }
            if (!sharePointUrl.startsWith("https://dsg2ic.sharepoint.com/")) {
                setAlertConfig({
                    open: true,
                    message: "The SharePoint URL must start with 'https://dsg2ic.sharepoint.com/' as this is the Global SharePoint site URL for Daiichi Sankyo INC. Any other URL is not supported.",
                    severity: "error",                    
                })
                return;
            }

            const response = await getSharePointFileListApi({ url: sharePointUrl });
            const data = await response.json();

            if (data.status === "success") {
                setSharePointData(data.data.data);
                setFolderPath(data.folder_path);
                setSharepointloaded(true);
                // setAlertConfig({  //got removed on Smrithis request UAT 24th April
                //     open: true,
                //     message: "SharePoint file(s) loaded successfully.",
                //     severity: "success"
                // });
            } else if (data.status === "error") {
                setAlertConfig({
                    open: true,
                    message: data.message,
                    severity: "error"
                });
            } else {
                setAlertConfig({
                    open: true,
                    message: data.message || "Failed to load data.",
                    severity: "error"
                });
            }
        } catch (error: unknown) {
            console.error("Error fetching SharePoint file list:", error);
            let message = "An unexpected error occurred.";

            if (error instanceof Error) {
                if (error.message === "403") {
                    message = "You are not authorized to access this SharePoint site. Please check your permissions.";
                } else {
                    message = error.message;
                }
            } else if (typeof error === "string") {
                message = error;
            }
            setAlertConfig({
                open: true,
                message: message,
                severity: "error"
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!sharepointloaded) {
            setSharePointUrl("");
            setSharePointData([]);
            setSelectedItems([]);
        }
    }, [sharepointloaded]);

    // Handle "Select All" functionality
    const handleGoBackButton = () => {
        setinputhsharepointurl(false);
        setSharePointData([]);
        setSelectedItems([]);
        setSharePointUrl("");
        setSharepointloaded(false);
        setSharepointFilesLoaded(false); // Reset the state when SharePoint is not loaded
    };

    const handleSelectAll = (isChecked: boolean) => {
        const updatedData = sharePointData.map(item => ({
            ...item,
            checked: isChecked ? "True" : "False"
        }));

        setSharePointData(updatedData);

        const selected = isChecked ? updatedData : [];
        setSelectedItems(selected);
    };
    const handleSnackbarClose = () => {
        setSnackbarOpen(false);

        setOpenFSnackbar(false);
    };

    const handleSelectionChange = (event: React.ChangeEvent<HTMLInputElement>, item: { name: any }) => {
        const updatedData = sharePointData.map(dataItem => {
            if (dataItem.name === item.name) {
                return { ...dataItem, checked: event.target.checked ? "True" : "False" };
            }
            return dataItem;
        });

        setSharePointData(updatedData);

        const selected = updatedData.filter(dataItem => dataItem.checked === "True");
        setSelectedItems(selected);
    };

    const [snackbarOpen, setSnackbarOpen] = React.useState(false);
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error" | "info" | "warning">("info");

// Add this utility function to your component
    const preventErrorsWhileProcessing = () => {
        // Create a new implementation of setAlertConfig that filters out errors during processing
        const originalSetAlertConfig = setAlertConfig;
        
        // Override the global error handler temporarily
        window.onerror = function(message, source, lineno, colno, error) {
        console.log("Caught error during SharePoint processing:", message);
        return true; // Prevents the error from propagating
        };
        
        // Return a cleanup function
        return () => {
        // Restore the original error handler
        window.onerror = null;
        };
    };
    
    const handleProcessSharePointFiles = async () => {
        // If this is after user confirmation
        if (isSPProceedClicked && activePopUp === "sharepoint") {
            console.log("Processing SharePoint files without images after confirmation");
            
            // Reset states
            setIsSPProceedClicked(false);
            setActivePopUp(null);
            
            // Set loading state
            setLoading(true);
            
            try {
                // Create a copy of items to process
                const itemsToProcess = [...selectedItems];
                
                // Immediately clear any alerts
                setAlertConfig({
                    open: false,
                    message: "",
                    severity: "info"
                });
                // --- Timeout logic: create a race between the API call and a timeout ---
                try {
                    const apiPromise = processSharePointFilesApi(sharePointUrl, itemsToProcess, false);
                    const timeoutPromise = new Promise((_resolve, reject) => {
                        setTimeout(() => {
                            reject(new Error("Process timedOut"));
                        }, config.timeout); // 180 seconds
                    });
                    // --- Wait for either the API call or the timeout ---

                    // Process files
                    console.log("Calling SharePoint API with", itemsToProcess.length, "files");
                    const response = (await Promise.race([apiPromise, timeoutPromise])) as Response;
                    const data = await response.json();

                    // Successful processing
                    if (data.status === "success") {
                        console.log("SharePoint API call succeeded");
                        setSharepointloaded(true);
                        setSharepointFilesLoaded(true);

                        // Close modal
                        handleCloseModal();

                        // Show success after a delay
                        setTimeout(() => {
                            setAlertConfig({
                                open: true,
                                message: "Files Processed successfully.",
                                severity: "success"
                            });
                        }, 300);
                    } else {
                        // API returned an error
                        console.log("SharePoint API returned error:", data.message);
                        setAlertConfig({
                            open: true,
                            message: data.message || "Failed to process files.",
                            severity: "error"
                        });
                    }
                } catch (error) {
                    if (error instanceof Error && error.message === "Process timedOut") {
                        setAlertConfig({
                            open: true,
                            message:
                                'The system has timed out due to the size of the file(s) and/or other attributes, such as images. Please modify the file(s),  select less files, or use the "Continue without images" if applicable.',
                            severity: "error",
                            autoHideDuration: 10000000 // persistent
                        });
                    }
                }
            } catch (error) {
                console.error(error);
                    setAlertConfig({
                        open: true,
                        message: "An unexpected error occurred",
                        severity: "error"
                    });
                
                // Alert'An unexpected error occurred';
            } finally {
                // Clean up
                setLoading(false);
                setSelectedItems([]);
            }
            
            return; // Exit function
        }
        if (isSPProceedClickedImages && activePopUp === "sharepoint"){
            console.log("Processing SharePoint files with images after confirmation");
            
            // Reset states
            setIsSPProceedClickedImages(false);
            setActivePopUp(null);
            
            // Set loading state
            setLoading(true);
            
            try {
                // Create a copy of items to process
                const itemsToProcess = [...selectedItems];
                
                // Immediately clear any alerts
                setAlertConfig({
                    open: false,
                    message: "",
                    severity: "info"
                });
                
                // Process files
                // --- Timeout logic: create a race between the API call and a timeout ---
                try {
                    const apiPromise = processSharePointFilesApi(sharePointUrl, itemsToProcess, true);
                    const timeoutPromise = new Promise((_resolve, reject) => {
                        setTimeout(() => {
                            reject(new Error("Process timedOut"));
                        }, config.timeout); // 180 seconds
                    });
                    // --- Wait for either the API call or the timeout ---

                    // Process files
                    console.log("Calling SharePoint API with", itemsToProcess.length, "files");
                    const response = (await Promise.race([apiPromise, timeoutPromise])) as Response;
                    const data = await response.json();

                    // Successful processing
                    if (data.status === "success") {
                        console.log("SharePoint API call succeeded");
                        setSharepointloaded(true);
                        setSharepointFilesLoaded(true);

                        // Close modal
                        handleCloseModal();

                        // Show success after a delay
                        setTimeout(() => {
                            setAlertConfig({
                                open: true,
                                message: "Files Processed successfully.",
                                severity: "success"
                            });
                        }, 300);
                    } else {
                        // API returned an error
                        console.log("SharePoint API returned error:", data.message);
                        setAlertConfig({
                            open: true,
                            message: data.message || "Failed to process files.",
                            severity: "error"
                        });
                    }
                } catch (error) {
                    if (error instanceof Error && error.message === "Process timedOut") {
                        setAlertConfig({
                            open: true,
                            message:
                                'The system has timed out due to the size of the file(s) and/or other attributes, such as images. Please modify the file(s),  select less files, or use the "Continue without images" if applicable.',
                            severity: "error",
                            autoHideDuration: 10000000 // persistent
                        });
                    }
                }
            } catch (error) {
                console.error("Error processing SharePoint files:", error);
            } finally {
                // Clean up
                setLoading(false);
                setSelectedItems([]);
            }
            
            return;

        }
        
        // First call - show popup (same as before)
        console.log("First call - showing popup");
        setLoading(true);
        
        // Filter valid files
        const allowedExtensions = ["pdf", "docx", "pptx", "txt"];
        const filteredItems = selectedItems.filter(item => {
            if (item.type !== "file") return true;
            const extension = item.name.split(".").pop()?.toLowerCase() || "";
            return allowedExtensions.includes(extension);
        });
        if (filteredItems.length === 0) {
            setAlertConfig({
                open: true,
                message: "No files to process. Please select PDF, TXT, DOCX OR PPTX files.",
                severity: "error"
            });
            setLoading(false);
            return;
        }
        // —— UPDATED SIZE CALCULATION —— 
        const totalSizeKB = filteredItems.reduce((sum, item) => {
            let raw = 0;

            if (item.type === "file") {
                // file: use item.size_kb
                raw = typeof item.size_kb === "string"
                    ? parseFloat(item.size_kb.replace(/[^0-9.]/g, ""))
                    : Number(item.size_kb);
            } else if (item.type === "folder") {
                // folder: use item.total_size_kb
                raw = typeof item.total_size_kb === "string"
                    ? parseFloat(item.total_size_kb.replace(/[^0-9.]/g, ""))
                    : Number(item.total_size_kb);
            }

            const size = isNaN(raw) ? 0 : raw;
            console.log(`${item.type === "file" ? "File" : "Folder"}: ${item.name}, Size(KB): ${size}`);
            return sum + size;
        }, 0);
        const totalSizeMB = totalSizeKB / 1024;
        console.log("Total SharePoint Files Size (MB):", totalSizeMB);
    
        // Ensure totalSizeMB is a valid number
        const safeFileSizeMB = isNaN(totalSizeMB) ? 0 : totalSizeMB;
    
        // Set the file size state for the size exceeded popup
        setSpFilesSize(safeFileSizeMB);
        
        // Prepare file upload state
        setFileUploadState({
            fileSizeExceeded: true,
            totalSize: totalSizeKB * 1024 // Convert KB to bytes
        });

        setActivePopUp("sharepoint");
        setIsUploadClicked(true);
        setLoading(false);
    };
    const [sortConfig, setSortConfig] = useState({ key: "name", direction: "asc" });
    const sortedData = [...sharePointData].sort((a, b) => {
        if (sortConfig.key === "name") {
            return sortConfig.direction === "asc" ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name);
        } else if (sortConfig.key === "size") {
            return sortConfig.direction === "asc" ? a.size_kb - b.size_kb : b.size_kb - a.size_kb;
        } else if (sortConfig.key === "count") {
            return sortConfig.direction === "asc" ? a.count - b.count : b.count - a.count;
        }
        return 0;
    });

    const handleSort = (key: string) => {
        let direction = "asc";
        if (sortConfig.key === key && sortConfig.direction === "asc") {
            direction = "desc";
        }
        setSortConfig({ key, direction });
    };

    const [fileSizes, setFileSizes] = useState<number[]>([]);

    const { fileSizeExceeded, totalSize } = useRecoilValue(fileSizeExceededAtom);

    const [spFilesSize, setSpFilesSize] = useState<number>(0);
    
    const setFileUploadState = useSetRecoilState(fileSizeExceededAtom);
    const [uploadClicked, setUploadClicked] = useState<boolean>(false); // Track whether it's the first click

    const handleClickUpload = () => {
        setUploadClicked(true); // Mark as clicked once

        setIsUploadClicked(true);
    };
    const handleClickUpload2 = () => {
        // console.log("Second click: handleClickUpload2 triggered");
        setUploadClicked(false); // Mark as clicked once
        setIsProceedClicked(true);
        handleUploadStart(); // Reset state when upload starts
        const syntheticEvent = new Event("submit") as unknown as React.FormEvent;
        handleSubmitFile(syntheticEvent);
    };
    const handleImageuploadClick = (event: React.FormEvent) => {
        setnewFileuploaded(false); // Ensure the value is reset
        handleSubmitFileforCSV_Excel_and_Images(event);
    };
    const [processingCompleted, setProcessingCompleted] = useState(false);
    useEffect(() => {
        if (isSPProceedClicked && activePopUp === "sharepoint") {
            handleProcessSharePointFiles();
        }
    }, [isSPProceedClicked, activePopUp]);
    
    useEffect(() => {
        if (isSPProceedClickedImages && activePopUp === "sharepoint") {
            handleProcessSharePointFiles();
        }
    }, [isSPProceedClickedImages, activePopUp]);
    // Add the new useEffect for processingCompleted
    useEffect(() => {
        // This effect only handles showing the success message after processing completes
        if (processingCompleted) {
            // Reset the flag first
            setProcessingCompleted(false);
            
            // Show success message after a delay
            setTimeout(() => {
                setAlertConfig({
                    open: true,
                    message: "Files Processed successfully.",
                    severity: "success"
                });
            }, 500);
        }
    }, [processingCompleted]);
    const theme = useTheme();
    const isSmallScreen = useMediaQuery("(max-width:700px)");

    return (
        <div>
            <Modal
                open={open}
                onClose={handleCloseModal}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                slots={{
                    backdrop: Backdrop
                }}
                slotProps={{
                    backdrop: {
                        style: { backgroundColor: "rgba(0, 0, 0, 0.25)" }
                    }
                }}
            >
                <Box>
                    <Box className="upload-box">
                        <Button
                            variant="text"
                            onClick={handleCloseModal}
                            sx={{
                                position: "absolute",
                                right: "2%",
                                padding: 0, // Remove any padding
                                minWidth: "auto", // Allow the button to shrink to fit its content
                                width: "auto", // Ensure the button width is auto
                                height: "auto", // Ensure the button height is auto
                                display: "flex", // Ensure the button content is centered
                                alignItems: "center", // Center the content vertically
                                justifyContent: "center" // Center the content horizontally
                            }}
                        >
                            <Dismiss24Regular />
                        </Button>
                        {isTranslating && (
                            <Backdrop open={isTranslating} style={{ zIndex: 1200 }}>
                                <CircularProgress color="inherit" />
                            </Backdrop>
                        )}
                        {/* ............................. */}
                        <Box sx={{ flexGrow: 1, bgcolor: "background.paper", display: "flex" }}>
                            <Tabs
                                orientation="vertical"
                                // variant="scrollable"
                                value={value}
                                onChange={handleChange}
                                aria-label="Vertical tabs"
                                sx={{ borderRight: 1, borderColor: "divider", width: "max-content" }}
                            >
                                <Tooltip title="File Upload" placement="right">
                                    <Tab
                                        label={
                                            <img
                                                src={fileupload}
                                                alt="File upload Logo"
                                                style={{ width: "2rem", height: "2rem", marginRight: "1px", borderRadius: "4px" }}
                                            />
                                        }
                                        sx={{ minHeight: "72px" }}
                                        //disabled={disableFUIcon}
                                        disabled={disableFUIconn || sharepointloaded}
                                        {...a11yProps(0)}
                                    />
                                </Tooltip>
                                <Tooltip title="Image Upload" placement="right">
                                    <Tab
                                        label={
                                            <img
                                                src={imageupicon}
                                                alt="Image upload Logo"
                                                style={{ width: "1.5rem", height: "1.5rem", marginRight: "1px", borderRadius: "4px" }}
                                            />
                                        }
                                        // disabled={disableIUIcon}
                                        sx={{ minHeight: "72px" }}
                                        disabled={disableFUIcon || disableIUIcon || sharepointloaded}
                                        {...a11yProps(1)}
                                    />
                                </Tooltip>
                                <Tooltip title="Excel/CSV Upload" placement="right">
                                    <Tab
                                        label={
                                            <img
                                                src={excelupload}
                                                alt="Image upload Logo"
                                                style={{ width: "2rem", height: "2rem", marginRight: "1px", borderRadius: "4px" }}
                                            />
                                        }
                                        //disabled={disableExcelIcon}
                                        sx={{ minHeight: "72px" }}
                                        disabled={disableExcelIcon || sharepointloaded}
                                        {...a11yProps(3)}
                                    />
                                </Tooltip>
                                <Tooltip title="Sharepoint Upload" placement="right">
                                    <Tab
                                        label={
                                            <img
                                                src={SharePointLogo}
                                                alt="SharePoint Logo"
                                                style={{ width: "4rem", height: "3rem", marginRight: "1px", borderRadius: "4px" }}
                                            />
                                        }
                                        sx={{ minHeight: "72px" }}
                                        // disabled = {selectedLabel === "file" || selectedLabel === "image" || selectedLabel === "excel"}
                                        disabled={disableSharePointIcon}
                                        {...a11yProps(2)}
                                    />
                                </Tooltip>
                            </Tabs>
                            {/* FILE UPLOAD */}
                            <TabPanel value={value} index={0}>
                                <Box
                                    sx={{
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        width: "100%" // Ensure the Box takes the full width of its container
                                    }}
                                >
                                    {/* <Typography id="modal-modal-title" variant="h4" sx={{ fontWeight: "600" }}>
                                        Upload Your Documents
                                    </Typography> */}
                                    <Typography
                                        id="modal-modal-title"
                                        variant="h4"
                                        sx={
                                            isSmallScreen
                                                ? {
                                                      textAlign: "center",
                                                      display: "inline",
                                                      fontWeight: "bold",
                                                      mx: "auto",
                                                      fontSize: 19
                                                  }
                                                : { fontWeight: 600 }
                                        }
                                    >
                                        Upload Your Documents
                                    </Typography>
                                </Box>

                                {/* <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                        Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
                    </Typography> */}
                                {isTranslating && (
                                    <Backdrop open={isTranslating} style={{ zIndex: 1200 }}>
                                        <CircularProgress color="inherit" />
                                    </Backdrop>
                                )}
                                <form onSubmit={handleSubmitFile}>
                                    <Box sx={{ px: 2, m: 2, height: "80%" }}>
                                        <Dropzone
                                            onDrop={acceptedFiles => {
                                                if (embeddingsLoaded) {
                                                    setnewFileuploaded(true);
                                                    // console.log(newFileuploaded, "New file uploaded variable");
                                                }
                                                // console.log(embeddingsLoaded, fileNames, newFileuploaded, "Emb and files uploaded");
                                                const totalSize = acceptedFiles.reduce((acc, file) => acc + file.size, 0);
                                                const maxSize = 200 * 1024 * 1024; // 200 MB in bytes
                                                const supportedFormats = [
                                                    "application/pdf",
                                                    "text/plain",
                                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                                    "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                                                ];
                                                const validFiles = acceptedFiles.filter(file => supportedFormats.includes(file.type));
                                                const invalidFiles = acceptedFiles.filter(file => !supportedFormats.includes(file.type));

                                                if (invalidFiles.length > 0) {
                                                    setSnackbarMessage(
                                                        "Some selected file(s) are unsupported. Only valid files (PDF, PPT, DOCX, TXT) will be processed."
                                                    );
                                                    setSnackbarSeverity("warning");
                                                    setSnackbarOpen(true);
                                                }

                                                if (totalSize > maxSize) {
                                                    setSnackbarMessage("Total file size of valid files exceeds 200 MB. Please upload smaller files.");
                                                    setSnackbarSeverity("error");
                                                    setSnackbarOpen(true);
                                                } else if (validFiles.length > 0) {
                                                    handleFileUpload(validFiles); // Process only valid files
                                                    // setSnackbarMessage("Files uploaded successfully.");
                                                    // setSnackbarSeverity("success");
                                                    // setSnackbarOpen(true); // Process only valid files
                                                }
                                            }}
                                        >
                                            {({ getRootProps, getInputProps }) => (
                                                <Box
                                                    {...getRootProps()}
                                                    className="center-column"
                                                    sx={{
                                                        height: 360,
                                                        width: "100%",
                                                        p: 2
                                                    }}
                                                >
                                                    <input {...getInputProps()} />
                                                    <Box>
                                                        {fileNames.length > 0 ? (
                                                            <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                                <Typography sx={{ m: "auto" }}>Selected file(s):</Typography>
                                                                <ul style={{ height: "auto", maxHeight: 350 }}>
                                                                    {fileNames.map((name, index) => (
                                                                        <li key={index}>{name}</li>
                                                                    ))}
                                                                </ul>
                                                            </Box>
                                                        ) : (
                                                            <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                                <Typography
                                                                    variant="body2"
                                                                    // sx={{
                                                                    //     color: "#9E9D9D",
                                                                    //     textAlign: "center",
                                                                    //     paddingBottom: "16px",
                                                                    //     margin: "auto",
                                                                    //     width: "80%",
                                                                    //     fontSize: "14px"
                                                                    // }}
                                                                    sx={
                                                                        isSmallScreen
                                                                            ? {
                                                                                  textAlign: "center",
                                                                                  display: "inline",
                                                                                  fontWeight: "bold",
                                                                                  mx: "auto",
                                                                                  fontSize: 10.5
                                                                              }
                                                                            : {
                                                                                  color: "#9E9D9D",
                                                                                  textAlign: "center",
                                                                                  paddingBottom: "16px",
                                                                                  margin: "auto",
                                                                                  width: "80%",
                                                                                  fontSize: "14px"
                                                                              }
                                                                    }
                                                                >
                                                                    {/* <span style={{ fontWeight: "bold" }}>Disclaimer:</span> The information provided on this
                                                                    platform is for general informational purposes only. All content is provided in good faith;
                                                                    however, we make no representation or warranty of any kind regarding the accuracy, adequacy,
                                                                    validity, reliability, or completeness of any information on the site. */}
                                                                    <br /> Please ensure the total file size is less than{" "}
                                                                    <span style={{ fontWeight: "bold" }}>200 MB</span> for successful upload.
                                                                </Typography>
                                                                <Box
                                                                    component="img"
                                                                    src={drop}
                                                                    alt="Dropzone upload"
                                                                    sx={{
                                                                        width: "auto",
                                                                        height: 180
                                                                    }}
                                                                />
                                                                <Typography
                                                                    sx={
                                                                        isSmallScreen
                                                                            ? {
                                                                                  display: "inline",
                                                                                  fontWeight: "bold",
                                                                                  mx: "auto",
                                                                                  fontSize: 10.5,
                                                                                  textAlign: "center"
                                                                              }
                                                                            : {
                                                                                  m: " 1rem auto ",
                                                                                  textAlign: "center",
                                                                                  wordWrap: "break-word",
                                                                                  width: "100%",
                                                                                  fontSize: "20px"
                                                                              }
                                                                    }
                                                                >
                                                                    Drag and drop your file(s)/folder(s) here for{" "}
                                                                    <span style={{ textDecoration: "underline", fontWeight: "600" }}>File Upload</span>
                                                                    <br />
                                                                    Supported File Formats: (PDF, TXT, DOCX, PPTX)
                                                                </Typography>
                                                            </Box>
                                                        )}
                                                    </Box>
                                                </Box>
                                            )}
                                        </Dropzone>
                                        {embeddingsLoaded && (
                                            <Box sx={{ marginTop: -4, marginLeft: 1 }}>
                                                <CheckmarkCircle24Filled color="green" />
                                            </Box>
                                        )}
                                    </Box>
                                    {/* <FileSizeExceededPopup deleteEmbeddings={deleteEmbeddings} /> */}
                                    {/* {isUploadClicked && isImageAlertProcessed && ( */}

                                    {isUploadClicked && (
                                        <FileSizeExceededPopup
                                            fileUploadValidity={() => console.log("File upload validity checked")}
                                            openFESnackbar={openFESnackbar}
                                            FEsnackbarMessage={FEsnackbarMessage}
                                            handleSubmitFile={handleSubmitFile}
                                            handleAlertClose={handleAlertClose}
                                            imageAlert={imageAlert}
                                            setIsCancelled={setIsCancelled}
                                            isCancelled={isCancelled}
                                            setIsImageAlertProcessed={setIsImageAlertProcessed}
                                            setIsUploadEnabled={setIsUploadEnabled}
                                            isUploadEnabled={isUploadEnabled}
                                            setIsUploadClicked={setIsUploadClicked}
                                            setnewFileuploaded={setnewFileuploaded}
                                            setIsProceedClicked={setIsProceedClicked}
                                            isProceedClicked={isProceedClicked}
                                            setIsProceedClickedImages={setIsProceedClickedImages}
                                            isProceedClickedImages={isProceedClickedImages}
                                            isSPProceedClicked={isSPProceedClicked}
                                            setIsSPProceedClicked={setIsSPProceedClicked}
                                            setIsSPProceedClickedImages={setIsSPProceedClickedImages}
                                            activePopUp={activePopUp}
                                            setActivePopUp={setActivePopUp}
                                            spFilesSize={spFilesSize}
                                        />
                                    )}
                                    <Box sx={{ py: 2, mt: 6 }}>
                                        <Typography variant="h6"></Typography>
                                        <Divider />
                                    </Box>
                                </form>

                                <div className="center-column-translate">
                                    {
                                        <>
                                            <button
                                                className={
                                                    !isImageAlertProcessed || files.length === 0 || (embeddingsLoaded && !newFileuploaded)
                                                        ? "buttonSubmitDisabled"
                                                        : "buttonSubmitEnabled"
                                                }
                                                onClick={isUploadClicked ? handleClickUpload2 : handleClickUpload}
                                                type="submit"
                                                title="Submit"
                                            >
                                                {files.length > 0 && !isImageAlertProcessed && !(embeddingsLoaded && !newFileuploaded)
                                                    ? "Loading..."
                                                    : "Upload"}
                                            </button>
                                            <div style={{ width: "100%" }}></div>
                                        </>
                                    }
                                    <Tooltip title="Delete File" placement="right">
                                        <Button
                                            sx={{ width: "200px", opacity: files.length === 0 ? 0.4 : 1 }}
                                            className={files.length === 0 ? "deleteDisabled" : ""}
                                        >
                                            <DeleteDismiss24Filled color="red" onClick={deleteEmbeddings} />
                                        </Button>
                                    </Tooltip>
                                    {/* </Box> */}
                                </div>
                            </TabPanel>

                            {/* IMAGE UPLOAD */}
                            <TabPanel value={value} index={1}>
                                <Box
                                    sx={{
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        width: "100%" // Ensure the Box takes the full width of its container
                                    }}
                                >
                                    <Typography
                                        id="modal-modal-title"
                                        variant="h4"
                                        sx={
                                            isSmallScreen
                                                ? {
                                                      display: "inline",
                                                      fontWeight: "bold",
                                                      mx: "auto",
                                                      fontSize: 19
                                                  }
                                                : { fontWeight: 600 }
                                        }
                                    >
                                        Upload Your Images
                                    </Typography>
                                </Box>

                                {isTranslating && (
                                    <Backdrop open={isTranslating} style={{ zIndex: 1200 }}>
                                        <CircularProgress color="inherit" />
                                    </Backdrop>
                                )}
                                <form onSubmit={handleSubmitFileforCSV_Excel_and_Images}>
                                    <Box sx={{ px: 2, m: 2, height: "80%" }}>
                                        <Dropzone
                                            // onDrop={handleFileUpload}
                                            onDrop={acceptedFiles => {
                                                const maxSize = 10 * 1024 * 1024; // 10 MB in bytes
                                                // const supportedFormats = [
                                                //     "image/jpeg",
                                                //     "image/png",
                                                //     "image/bmp",
                                                //     "image/webp",
                                                //     "image/tiff",
                                                //     "image/gif",
                                                //     "image/jpg",
                                                // ];

                                                const supportedExtensions = ["jpeg", "png", "bmp", "webp", "tif","tiff", "gif", "jpg"];

                                                if (embeddingsLoaded) {
                                                    setnewFileuploaded(true);
                                                }

                                                const validFiles = acceptedFiles.filter(file => {
                                                    // Use optional chaining and nullish coalescing to avoid undefined or null errors
                                                    const fileExtension = file?.name?.split(".").pop()?.toLowerCase() ?? "";
                                                    return fileExtension && supportedExtensions.includes(fileExtension);
                                                });

                                                const invalidFiles = acceptedFiles.filter(file => {
                                                    // Use optional chaining and nullish coalescing to avoid undefined or null errors
                                                    const fileExtension = file?.name?.split(".").pop()?.toLowerCase() ?? "";
                                                    return !fileExtension || !supportedExtensions.includes(fileExtension);
                                                });

                                                console.log("invalid files", invalidFiles);
                                                console.log("valid files", validFiles);

                                                const totalSize = validFiles.reduce((acc, file) => acc + file.size, 0);

                                                // Notify about unsupported files
                                                if (invalidFiles.length > 0) {
                                                    setSnackbarMessage("Some selected file(s) are unsupported. Only valid files will be processed.");
                                                    setSnackbarSeverity("warning");
                                                    setSnackbarOpen(true);
                                                }

                                                //     const maxSize = 10 * 1024 * 1024; // 10 MB in bytes
                                                //     const supportedFormats = [
                                                //         "image/jpeg",
                                                //         "image/png",
                                                //         "image/bmp",
                                                //         "image/webp",
                                                //         "image/tiff",
                                                //         "image/gif",
                                                //         "image/jpg",

                                                //     ];
                                                //     if (embeddingsLoaded) {
                                                //         setnewFileuploaded(true);
                                                //     }

                                                //     const validFiles = acceptedFiles.filter(file => supportedFormats.includes(file.type));
                                                //     const invalidFiles = acceptedFiles.filter(file => !supportedFormats.includes(file.type));
                                                //     const totalSize = validFiles.reduce((acc, file) => acc + file.size, 0);

                                                //     // Notify about unsupported files
                                                //     if (invalidFiles.length > 0) {
                                                //         setSnackbarMessage("Some selected file(s) are unsupported. Only valid files will be processed.");
                                                //         setSnackbarSeverity("warning");
                                                //         setSnackbarOpen(true);
                                                //     }

                                                // Validate total size of valid files
                                                if (totalSize > maxSize) {
                                                    setSnackbarMessage("Total file size of valid files exceeds 10 MB. Please upload smaller files.");
                                                    setSnackbarSeverity("error");
                                                    setSnackbarOpen(true);
                                                } else if (validFiles.length > 0) {
                                                    handleFileUpload(validFiles); // Process only valid files
                                                    // setSnackbarMessage("Files uploaded successfully.");
                                                    // setSnackbarSeverity("success");
                                                    // setSnackbarOpen(true); // Process only valid files
                                                }
                                            }}
                                        >
                                            {({ getRootProps, getInputProps }) => (
                                                <Box
                                                    {...getRootProps()}
                                                    className="center-column"
                                                    sx={{
                                                        height: 360,
                                                        width: "100%",
                                                        p: 2
                                                        // border: "1px dashed grey",
                                                        // borderTop: "4px solid #0197f6",
                                                        // borderRadius: "16px"
                                                    }}
                                                >
                                                    <input {...getInputProps()} />
                                                    <Box>
                                                        {fileNames.length > 0 ? (
                                                            <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                                {/* <AiOutlineFile style={{ fontSize: 30, margin: "auto", marginTop: 30, marginBottom: 10 }} /> */}
                                                                <Typography sx={{ m: "auto" }}>Selected image:</Typography>
                                                                <ul style={{ height: "auto", maxHeight: 350 }}>
                                                                    {fileNames.map((name, index) => (
                                                                        <li key={index}>{name}</li>
                                                                    ))}
                                                                </ul>
                                                            </Box>
                                                        ) : (
                                                            <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                                <Typography
                                                                    variant="body2"
                                                                    sx={
                                                                        isSmallScreen
                                                                            ? {
                                                                                  display: "inline",
                                                                                  fontWeight: "bold",
                                                                                  mx: "auto",
                                                                                  fontSize: 10.5,
                                                                                  textAlign: "center"
                                                                              }
                                                                            : {
                                                                                  color: "#9E9D9D",
                                                                                  textAlign: "center",
                                                                                  paddingBottom: "4px",
                                                                                  margin: "auto",
                                                                                  width: "80%",
                                                                                  fontSize: "14px"
                                                                              }
                                                                    }
                                                                >
                                                                    <br /> Please ensure the total file size is less than{" "}
                                                                    <span style={{ fontWeight: "bold" }}>10 MB</span> for successful upload.
                                                                </Typography>
                                                                <Box
                                                                    component="img"
                                                                    src={imageUpload}
                                                                    alt="Dropzone upload"
                                                                    sx={{
                                                                        width: "auto",
                                                                        height: 180
                                                                        // borderRadius: "8px",
                                                                        // boxShadow: 3
                                                                    }}
                                                                />
                                                                <Typography
                                                                    sx={
                                                                        isSmallScreen
                                                                            ? {
                                                                                  display: "inline",
                                                                                  fontWeight: "bold",
                                                                                  mx: "auto",
                                                                                  fontSize: 10.5,
                                                                                  textAlign: "center"
                                                                              }
                                                                            : {
                                                                                  m: " 1rem auto ",
                                                                                  textAlign: "center",
                                                                                  wordWrap: "break-word",
                                                                                  width: "100%",
                                                                                  fontSize: "20px"
                                                                              }
                                                                    }
                                                                >
                                                                    Drag and drop your file(s)/folder(s) here for{" "}
                                                                    <span style={{ textDecoration: "underline", fontWeight: "600" }}>Image Upload</span>
                                                                    <br />
                                                                    Supported File Formats: (JPG, PNG, JPEG, BMP, WEBP, TIFF, TIF, GIF)
                                                                </Typography>
                                                            </Box>
                                                        )}
                                                    </Box>
                                                </Box>
                                            )}
                                        </Dropzone>
                                        {embeddingsLoaded && (
                                            <Box sx={{ marginTop: -4, marginLeft: 1 }}>
                                                <CheckmarkCircle24Filled color="green" />
                                            </Box>
                                        )}
                                    </Box>
                                    <Box sx={{ py: 4 }}>
                                        <Typography variant="h6"></Typography>
                                        <Divider />
                                    </Box>
                                </form>
                                <div className="center-column-translate">
                                    <button
                                        className={
                                            files.length === 0 || (embeddingsLoaded && !newFileuploaded) ? "buttonSubmitDisabled" : "buttonSubmitEnabled"
                                        }
                                        onClick={handleImageuploadClick}
                                        type="submit"
                                        title="Submit"
                                    >
                                        Upload
                                    </button>
                                    <div style={{ width: "100%" }}></div>
                                    <Tooltip title="Delete File" placement="right">
                                        <Button
                                            sx={{ width: "200px", opacity: files.length === 0 ? 0.4 : 1 }}
                                            className={files.length === 0 ? "deleteDisabled" : ""}
                                        >
                                            <DeleteDismiss24Filled color="red" onClick={deleteEmbeddings} />
                                        </Button>
                                    </Tooltip>
                                </div>
                            </TabPanel>
                            {/* 
                                Sharepoint Upload
                                Disabled for now and idex value changed.
                            */}
                            <TabPanel value={value} index={3}>
                                {sharePointData && sharePointData.length > 0 ? (
                                    <Box sx={{ mt: 4, width: "100%" }}>
                                        <Typography variant="h6" component="h3" sx={{ mb: 2 }}>
                                            SharePoint Folder and File List
                                        </Typography>
                                        <Typography variant="body1" sx={{ mb: 2 }}>
                                            Folder Path : {folderPath.split("/").length >= 4 ? folderPath.split("/").slice(-3).join("/ ") : folderPath}
                                        </Typography>
                                        <Box sx={{ overflowX: "auto", maxHeight: "400px", overflowY: "auto" }}>
                                            <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
                                                <thead>
                                                    <tr style={{ borderBottom: "2px solid #ddd", position: "sticky", top: 0, backgroundColor: "#fff" }}>
                                                        <th style={{ padding: "10px" }}>
                                                            <input
                                                                type="checkbox"
                                                                onChange={e => handleSelectAll(e.target.checked)}
                                                                checked={sharePointData.every(item => item.checked === "True")}
                                                            />
                                                        </th>
                                                        <th style={{ padding: "10px" }}>Name</th>
                                                        <th style={{ padding: "10px", textAlign: "right" }}>Count/Size</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {sharePointData.map((item, index) => (
                                                        <tr
                                                            key={index}
                                                            style={{
                                                                borderBottom: "1px solid #ddd",
                                                                backgroundColor: item.checked === "True" ? "#e8f4ff" : "transparent"
                                                            }}
                                                        >
                                                            <td style={{ padding: "10px" }}>
                                                                <input
                                                                    type="checkbox"
                                                                    checked={selectedItems.some(i => i.name === item.name)}
                                                                    onChange={e => handleSelectionChange(e, item)}
                                                                />
                                                            </td>

                                                            <td style={{ padding: "10px" }}>
                                                                {item.type === "folder" ? (
                                                                    <>📁 {item.name}</>
                                                                ) : (
                                                                    <>
                                                                        {" "}
                                                                        <div style={{ display: "flex" }}>
                                                                            {getFileIcon(item.name)} {item.name}
                                                                        </div>
                                                                    </>
                                                                )}
                                                            </td>
                                                            <td style={{ padding: "10px", textAlign: "right" }}>
                                                                {item.type === "folder" ? `${item.count || 0} items` : item.size_kb}
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </Box>
                                        <div style={{ display: "flex", flexDirection: "row" }}>
                                            <Tooltip title={sharepointFilesLoaded ? "Please clear the files before going back" : "Going Back will clear the URL and folder contents"} placement="right">
                                                <button
                                                    className={sharepointFilesLoaded ? "buttonSubmitDisabled" : "buttonSubmitEnabled"}
                                                    onClick={handleGoBackButton}
                                                    type="button"
                                                    title="Process"
                                                    style={{ marginTop: "16px", width: "20%" }}
                                                >
                                                    Back
                                                </button>
                                            </Tooltip>
                                            {selectedItems.length > 0 && (
                                                <button
                                                    className="buttonSubmitEnabled"
                                                    onClick={handleProcessSharePointFiles}
                                                    type="button"
                                                    title="Process"
                                                    style={{ marginTop: "16px", width: "40%", marginLeft: "auto" }}
                                                >
                                                    PROCESS SELECTED FILES
                                                </button>
                                            )}
                                        </div>
                                        <div style={{ display: sharepointFilesLoaded ? "flex" : "none" }}>
                                        <Typography
                                            sx={
                                                isSmallScreen
                                                    ? {
                                                          display: "inline",
                                                          fontWeight: "bold",
                                                          mx: "auto",
                                                          fontSize: 10.5,
                                                          textAlign: "center"
                                                      }
                                                    : {
                                                          m: " 1rem auto ",
                                                          mt:"3rem",
                                                          textAlign: "center",
                                                          wordWrap: "break-word",
                                                          width: "90%",
                                                          fontSize: "14px"
                                                      }
                                            }
                                        >
                                            *Please clear the files before going back using Clear Documents Button on chat window.
                                        </Typography>
                                        </div>
                                        
                                        <Backdrop open={loading} style={{ zIndex: 1200 }}>
                                            <CircularProgress color="inherit" />
                                        </Backdrop>
                                        
                                    </Box>
                                ) : (
                                    <Box
                                        sx={
                                          
                                            
                                                isSmallScreen
                                                    ? {
                                                        display: "flex", flexDirection: "column"
                                                         // Ensure the Box takes the full width of its container
                                                      }
                                                    : {
                                                        display: "flex",
                                                        flexDirection: "column",
                                                        justifyContent: "center",
                                                        alignItems: "center",
                                                        width: "100%"
                                                      }
                                            }
                                        
                                    >
                                        <Typography id="modal-modal-title" variant="h4" sx={{ fontWeight: "600"}}>
                                            Sharepoint Upload
                                        </Typography>

                                        <Typography
                                            variant="body2"
                                            sx={
                                                isSmallScreen
                                                    ? {
                                                          textAlign: "center",
                                                          display: "inline",
                                                          fontWeight: "bold",
                                                          mx: "auto",
                                                          fontSize: 10.5
                                                      }
                                                    : {
                                                          color: "#9E9D9D",
                                                          textAlign: "center",
                                                          paddingBottom: "7px",
                                                          margin: "0px",
                                                          width: "80%",
                                                          fontSize: "14px"
                                                      }
                                            }
                                        >
                                            <br /> Please ensure the total file size is less than <span style={{ fontWeight: "bold" }}>200 MB</span> for
                                            successful upload.
                                        </Typography>
                                        <Box
                                            component="img"
                                            src={spuploadbanner}
                                            alt="Dropzone upload"
                                            sx={{
                                                width: "auto",
                                                height: 180,
                                                display: "flex",
                                                // borderRadius: "8px",
                                                // boxShadow: 
                                                
                                            }}
                                        />
                                        <Typography
                                            sx={
                                                isSmallScreen
                                                    ? {
                                                          display: "inline",
                                                          fontWeight: "bold",
                                                          mx: "auto",
                                                          fontSize: 10.5,
                                                          textAlign: "center"
                                                      }
                                                    : {
                                                          m: " 1rem auto ",
                                                          textAlign: "center",
                                                          wordWrap: "break-word",
                                                          width: "94%",
                                                          fontSize: "17.5px"
                                                      }
                                            }
                                        >
                                            Enter the URL of a SharePoint site or specific folder within a site to extract files. You can select individual files (PDF, TXT, DOCX, PPTX only) or entire folders. Unsupported file types won’t be available for selection and sub-folder content won't be processed. To select sub-folder content, enter its direct URL.
                                        </Typography>
                                        <Box sx={{ width: "100%"}}>
                                            <TextField
                                                id="sharepoint-url-input"
                                                label="SharePoint URL"
                                                fullWidth
                                                value={sharePointUrl}
                                                onChange={e => {
                                                    const value = e.target.value;
                                                    setSharePointUrl(value);
                                                    setinputhsharepointurl(value.trim() !== "");
                                                }}
                                                sx={{ mb: 0, mt: 0 }}
                                                InputProps={{
                                                    endAdornment: (
                                                        <IconButton
                                                            sx={{ p: 0 }} // To remove padding for the icon button
                                                            onClick={() => { // Clear input field on click
                                                                setinputhsharepointurl(false);
                                                                setSharePointData([]);
                                                                setSelectedItems([]);
                                                                setSharePointUrl("");
                                                                setSharepointloaded(false);
                                                            }
                                                            }
                                                             // setinputhsharepointurl(false);
                                                            disabled={sharePointUrl.trim() === ''}
                                                        >
                                                        <FaLinkSlash title="Clear URL" />                                                        
                                                        </IconButton>
                                                    ),
                                                }}
                                            />
                                        </Box>
                                        
                                        <Box
                                            sx={{
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center",
                                                width: "100%",
                                                mt: 1.5,
                                                
                                            }}
                                        >
                                            {/* <div className="center-column-translate"> */}
                                            {/* { */}
                                            {/* <> */}
                                            <button
                                                className={sharePointUrl ? "buttonSubmitEnabled" : "buttonSubmitDisabled"}
                                                onClick={handleSubmitSharePointUrl}
                                                type="button"
                                                title="Submit"
                                                style={{ width: "30%" }}
                                                // style={{ maxWidth: "30%", marginLeft: "auto" }}
                                            >
                                                {loading ? "Loading..." : "SUBMIT"}
                                            </button>
                                            <Box sx={{ flex: 1 }} />
                                            {/* <div style={{ width: "100%" }}></div> */}
                                            {/* </> */}
                                            {/* } */}
                                            <Tooltip title="Clear uploaded files" placement="right">
                                                <span style={{ display: "flex", justifyContent: "flex-end" }}>
                                                    <Button
                                                        sx={{ width: "100px", opacity: sharepointFilesLoaded ? 1 : 0.4 }}
                                                        className={!sharepointFilesLoaded ? "deleteDisabled" : ""}
                                                        onClick={sharepointFilesLoaded ? deleteEmbeddingsforcitaions : undefined}
                                                        disabled={!sharepointFilesLoaded}
                                                    >
                                                        <DeleteDismiss24Filled color="red" />
                                                    </Button>
                                                </span>
                                            </Tooltip>
                                        </Box>

                                        <Typography
                                            sx={
                                                isSmallScreen
                                                    ? {
                                                          display: "inline",
                                                          fontWeight: "bold",
                                                          mx: "auto",
                                                          fontSize: 10.5,
                                                          textAlign: "center"
                                                      }
                                                    : {
                                                          m: " 1rem auto ",
                                                          textAlign: "center",
                                                          wordWrap: "break-word",
                                                          width: "100%",
                                                          fontSize: "18px"
                                                      }
                                            }
                                        >
                                            <br />
                                            {/* <span style={{ fontSize: "1rem" }}>
                                                Only Supported File Formats: (PDF, TXT, DOCX, PPTX) will be processed. <br />
                                            </span> */}
                                        </Typography>
                                    </Box>
                                )}
                            </TabPanel>
                            {/* EXCEL UPLOAD */}
                            <TabPanel value={value} index={2}>
                                <Box
                                    sx={{
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        width: "100%" // Ensure the Box takes the full width of its container
                                    }}
                                >
                                    <Typography
                                        id="modal-modal-title"
                                        variant="h4"
                                        sx={
                                            isSmallScreen
                                                ? {
                                                      textAlign: "center",
                                                      display: "inline",
                                                      fontWeight: "bold",
                                                      mx: "auto",
                                                      fontSize: 19
                                                  }
                                                : { fontWeight: 600 }
                                        }
                                    >
                                        Upload Your Structured Documents (Excel)
                                    </Typography>
                                </Box>

                                {/* <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                        Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
                    </Typography> */}
                                {isTranslating && (
                                    <Backdrop open={isTranslating} style={{ zIndex: 1200 }}>
                                        <CircularProgress color="inherit" />
                                    </Backdrop>
                                )}
                                <form onSubmit={handleSubmitFileforCSV_Excel_and_Images}>
                                    <Box sx={{ px: 2, m: 2, height: "80%" }}>
                                        {/* <Dropzone onDrop={handleFileUpload}> */}
                                        <Dropzone
                                            onDrop={acceptedFiles => {
                                                if (embeddingsLoaded) {
                                                    setSnackbarMessage("Please remove the Uploaded File. Only 1 XLSX, CSV file is allowed.");
                                                    setSnackbarSeverity("error");
                                                    setSnackbarOpen(true);
                                                } else {
                                                    const maxSize = 1; // 10 MB in bytes
                                                    const supportedFormats = [
                                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // XLSX
                                                        "text/csv",
                                                        "application/vnd.ms-excel" // CSV
                                                    ];

                                                    // Separate valid and invalid files
                                                    const validFiles = acceptedFiles.filter(file => supportedFormats.includes(file.type));
                                                    const invalidFiles = acceptedFiles.filter(file => !supportedFormats.includes(file.type));
                                                    const totalSize = validFiles.reduce((acc, file) => acc + file.size, 0);
                                                    const totalFiles = validFiles.length;

                                                    // Notify user about unsupported files
                                                    if (invalidFiles.length > 0) {
                                                        setSnackbarMessage(
                                                            "Some selected file(s) are unsupported. Only valid files (CSV, XLSX) will be processed."
                                                        );
                                                        setSnackbarSeverity("warning");
                                                        setSnackbarOpen(true);
                                                    }

                                                    // Check size of valid files
                                                    // if (totalSize > maxSize) {
                                                    //     setSnackbarMessage("Total file size of valid files exceeds 10 MB. Please upload smaller files.");
                                                    //     setSnackbarSeverity("error");
                                                    //     setSnackbarOpen(true);
                                                    if (totalFiles > 1) {
                                                        setSnackbarMessage("Upload only 1 XLSX, CSV file.");
                                                        setSnackbarSeverity("error");
                                                        setSnackbarOpen(true);
                                                    } else if (validFiles.length > 0) {
                                                        handleFileUpload(validFiles); // Process only valid files
                                                        // setSnackbarMessage("Files uploaded successfully.");
                                                        // setSnackbarSeverity("success");
                                                        // setSnackbarOpen(true); // Process only valid files
                                                    }
                                                }
                                            }}
                                        >
                                            {({ getRootProps, getInputProps }) => (
                                                <Box
                                                    {...getRootProps()}
                                                    className="center-column"
                                                    sx={{
                                                        height: 360,
                                                        width: "100%",
                                                        p: 2
                                                        // border: "1px dashed grey",
                                                        // borderTop: "4px solid #0197f6",
                                                        // borderRadius: "16px"
                                                    }}
                                                >
                                                    <input {...getInputProps()} />
                                                    <Box>
                                                        {fileNames.length > 0 ? (
                                                            <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                                {/* <AiOutlineFile style={{ fontSize: 30, margin: "auto", marginTop: 30, marginBottom: 10 }} /> */}
                                                                <Typography sx={{ m: "auto" }}>Selected file(s) :</Typography>
                                                                <ul style={{ height: "auto", maxHeight: 350 }}>
                                                                    {fileNames.map((name, index) => (
                                                                        <li key={index}>{name}</li>
                                                                    ))}
                                                                </ul>
                                                            </Box>
                                                        ) : (
                                                            <Box sx={{ display: "flex", flexDirection: "column" }}>
                                                                {/* <FileUploadIcon style={{ fontSize: 30 }} /> */}
                                                                {/* <ArrowUpload24Regular style={{ fontSize: 30, margin: "auto", marginTop: 30, marginBottom: 10 }} /> */}
                                                                {/* <ArrowUpload24Regular
                                                                    style={{ fontSize: 30, margin: "auto", marginTop: 30, marginBottom: 10 }}
                                                                /> */}
                                                                <Typography
                                                                    variant="body2"
                                                                    sx={{
                                                                        color: "#9E9D9D",
                                                                        textAlign: "center",
                                                                        paddingBottom: "16px",
                                                                        margin: "auto",
                                                                        width: "80%",
                                                                        fontSize: "14px"
                                                                    }}
                                                                >
                                                                    {" "}
                                                                    <div style={{ height: "40px" }}></div>
                                                                    {/* <span style={{ fontWeight: "bold" }}>Disclaimer:</span> The information provided on this
                                                                    platform is for general informational purposes only. All content is provided in good faith;
                                                                    however, we make no representation or warranty of any kind regarding the accuracy, adequacy,
                                                                    validity, reliability, or completeness of any information on the site */}
                                                                </Typography>
                                                                <Box
                                                                    component="img"
                                                                    src={drop}
                                                                    alt="Dropzone upload"
                                                                    sx={{
                                                                        width: "auto",
                                                                        height: 180
                                                                        // borderRadius: "8px",
                                                                        // boxShadow: 3
                                                                    }}
                                                                />
                                                                <Typography
                                                                    sx={
                                                                        isSmallScreen
                                                                            ? {
                                                                                  display: "inline",
                                                                                  fontWeight: "bold",
                                                                                  mx: "auto",
                                                                                  fontSize: 10.5,
                                                                                  textAlign: "center"
                                                                              }
                                                                            : {
                                                                                  m: " 1rem auto ",
                                                                                  textAlign: "center",
                                                                                  wordWrap: "break-word",
                                                                                  width: "100%",
                                                                                  fontSize: "20px"
                                                                              }
                                                                    }
                                                                >
                                                                    Drag and drop your file here for{" "}
                                                                    <span style={{ textDecoration: "underline", fontWeight: "600" }}>File Upload</span>
                                                                    <br />
                                                                    Supported File Formats: (XLSX, CSV)
                                                                </Typography>
                                                                {/* <Typography sx={{ m: "auto" }}>{"[Total File Size Limit: 10MB]"}</Typography> */}
                                                            </Box>
                                                        )}
                                                    </Box>
                                                </Box>
                                            )}
                                        </Dropzone>
                                        {embeddingsLoaded && (
                                            <Box sx={{ marginTop: -4, marginLeft: 1 }}>
                                                <CheckmarkCircle24Filled color="green" />
                                            </Box>
                                        )}
                                    </Box>
                                    <Box sx={{ py: 2, mt: 6 }}>
                                        <Typography variant="h6"></Typography>
                                        <Divider />
                                    </Box>
                                </form>
                                <div className="center-column-translate">
                                    {
                                        <>
                                            <button
                                                className={files.length === 0 || embeddingsLoaded ? "buttonSubmitDisabled" : "buttonSubmitEnabled"}
                                                onClick={handleSubmitFileforCSV_Excel_and_Images}
                                                type="submit"
                                                title="Submit"
                                            >
                                                Upload
                                            </button>
                                            <div style={{ width: "100%" }}></div>
                                        </>
                                    }
                                    <Tooltip title="Delete File" placement="right">
                                        <Button
                                            sx={{ width: "200px", opacity: files.length === 0 ? 0.4 : 1 }}
                                            className={files.length === 0 ? "deleteDisabled" : ""}
                                        >
                                            <DeleteDismiss24Filled color="red" onClick={deleteEmbeddings} />
                                        </Button>
                                    </Tooltip>

                                    {/* </Box> */}
                                </div>
                            </TabPanel>
                        </Box>
                        {/* //////////////////////////// */}

                        {/* <Backdrop sx={{ color: "#fff", zIndex: theme => theme.zIndex.drawer + 4 }} open={isFileProcessed}> */}
                        <Backdrop sx={{ color: "#fff", zIndex: theme => theme.zIndex.drawer + 4 }} open={isEmbeddingsLoading}>
                            <CircularProgress color="inherit" />
                        </Backdrop>
                    </Box>
                    <Box
                        sx={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            marginRight: "10%",
                            Top: "10%"
                        }}
                    >
                        <Snackbar open={translateOpenAlert} autoHideDuration={null} onClose={handleAlertClose}>
                            {/* <Alert onClose={handleAlertClose} severity="success" sx={{ width: "100%" }}> */}
                            <Alert severity="success" sx={{ width: "100%" }}>
                                File Translated Successfully!
                            </Alert>
                        </Snackbar>
                        <Snackbar
                            open={snackbarOpen}
                            autoHideDuration={6000}
                            onClose={handleSnackbarClose}
                            anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        >
                            <Alert onClose={handleSnackbarClose} severity={snackbarSeverity}>
                                {snackbarMessage}
                            </Alert>
                        </Snackbar>
                    </Box>
                    {/* </Box> */}
                </Box>
            </Modal>

            <Snackbar open={openDocClearAlert} autoHideDuration={12000} onClose={handleAlertClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                    The responses are not being fetched from the document.
                </Alert>
            </Snackbar>
            <Snackbar open={infoAlert} autoHideDuration={6000} onClose={handleAlertClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                    File with size above 5MB takes more time to process, Please be patient !
                </Alert>
            </Snackbar>
            <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleSnackbarClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                <Alert onClose={handleSnackbarClose} severity={snackbarSeverity}>
                    {snackbarMessage}
                </Alert>
            </Snackbar>
        </div>
    );
}