import { IoMdAttach } from "react-icons/io";
import { FaRegFileImage } from "react-icons/fa";

import styles from "./UploadDocumentButton.module.css";

interface Props {
    className?: string;
    onClick: () => void;
    disabled?: boolean;
    size?: number;
}

export const UploadDocumentButton = ({ className, disabled, onClick, size }: Props) => {
    return (
        <div
            className={`${styles.container} ${className ?? ""} ${disabled ? styles.disabled : ""}`}
            onClick={disabled ? undefined : onClick}
            style={{ cursor: disabled ? 'not-allowed' : 'pointer', fontSize: size }}
        >
            <IoMdAttach />
        </div>
    );
};
