import { useState, useEffect, useRef } from "react";
import { Stack, TextField, ITextField } from "@fluentui/react";
import { Send28Filled, MicOff28Filled, Mic28Filled, Mic28Regular, MicPulse28Regular, MoreCircle28Regular } from "@fluentui/react-icons";
import { ClearChatButton } from "../ClearChatButton/ClearChatButton";
import styles from "./QuestionInput.module.css";
import { useRecoilState } from "recoil";
import { selectedMessageAtom } from "../UserChatMessage/Atom";
import Tooltip from "@mui/material/Tooltip";
import * as sdk from "microsoft-cognitiveservices-speech-sdk";
import { isSpeakingAtom } from "../Answer/atoms";
import logo from "/src/assets/Daiichi_Sankyo_junior.png";

interface Props {
    onSend: (question: string) => void;
    disabled: boolean;
    placeholder?: string;
    clearOnSend?: boolean;
    clearchat: () => void;
    isLoading: boolean;
    lastQuestionRef: any;
    fileuploadelement: any;
    // imageuploadelement: any;
    translatefileuploadelement: any;
    value: string;
    isContent: boolean;
    showTooltip: boolean;
}
export const QuestionInput = ({
    onSend,
    disabled,
    placeholder,
    clearOnSend,
    lastQuestionRef,
    clearchat,
    fileuploadelement,
    // imageuploadelement,
    translatefileuploadelement,
    showTooltip
}: Props) => {
    const [question, setQuestion] = useState<string>("");
    // const [isListening, setIsListening] = useState<boolean>(false);
    const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
    const inputRef = useRef<ITextField>(null);
    const [selectedMessage, setSelectedMessage] = useRecoilState(selectedMessageAtom);
    const [searchQuery, setSearchQuery] = useState("");
    const [isListening, setIsListening] = useState(false);
    const recognizerRef = useRef<sdk.SpeechRecognizer | null>(null); // SpeechRecognizer or null
    const silenceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const SILENCE_DURATION = 60000;
    useEffect(() => {
        if (selectedMessage) {
            setQuestion(selectedMessage);
        }
    }, [selectedMessage]);

    useEffect(() => {
        if (inputRef.current) {
            inputRef.current.focus();
        }
    }, [question, disabled]);
    const [isSpeaking, setIsSpeaking] = useRecoilState(isSpeakingAtom);

    const sendQuestion = () => {
        if (isSpeaking) {
            window.speechSynthesis.cancel();
            setIsSpeaking(false); // Set isSpeaking to false
        }
        if (disabled || !question.trim()) {
            return;
        }
        onSend(question);
        if (clearOnSend) {
            stopVoiceRecognition();
            setQuestion("");
            setSelectedMessage("");
        }
    };

    const resetFunction = () => {
        if (!disabled) {
            if (isSpeaking) {
                window.speechSynthesis.cancel();
                setIsSpeaking(false); // Set isSpeaking to false
            }
            clearchat();
        }
    };

    const onEnterPress = (ev: React.KeyboardEvent<Element>) => {
        if (ev.key === "Enter" && !ev.shiftKey) {
            ev.preventDefault();
            sendQuestion();
        }
    };

    const onQuestionChange = (_ev: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
        if (!newValue) {
            setQuestion("");
        } else {
            setQuestion(newValue);
        }
    };
    const startVoiceRecognition = () => {
        // Replace with your Azure Speech subscription key and region
        const subscriptionKey = "9fd3c452d25d4848a54f9d466f5dcefc";
        const region = "eastus";

        const speechConfig = sdk.SpeechConfig.fromSubscription(subscriptionKey, region);
        // speechConfig.speechRecognitionLanguage = "en-IN";
        const autoDetectSourceLanguages = ["en-IN", "hi-IN", "ja-JP"];
        const autoDetectSourceLanguageConfig = sdk.AutoDetectSourceLanguageConfig.fromLanguages(autoDetectSourceLanguages); // Set preferred language

        const audioConfig = sdk.AudioConfig.fromDefaultMicrophoneInput();
        // const recognizer = new sdk.SpeechRecognizer(speechConfig, audioConfig);
        const recognizer = sdk.SpeechRecognizer.FromConfig(speechConfig, autoDetectSourceLanguageConfig, audioConfig);

        // Store recognizer in useRef to access it for stopping later
        recognizerRef.current = recognizer;

        setIsListening(true);

        // Clear any previous silence timeout
        resetSilenceTimeout();

        recognizer.recognizing = (s, e) => {
            resetSilenceTimeout(); // Reset silence timer each time speech is detected
        };

        recognizer.recognized = (s, e) => {
            if (e.result.reason === sdk.ResultReason.RecognizedSpeech) {
                setSearchQuery(e.result.text);

                setQuestion(prevText => (prevText ? prevText : "") + " " + e.result.text);

            }
            resetSilenceTimeout(); 
        };

        recognizer.startContinuousRecognitionAsync(
            () => {},
            err => {
                console.error("Error starting speech recognition: ", err);
                setIsListening(false);
            }
        );

        // Set the initial silence timeout
        setSilenceTimeout();
    };

    const stopVoiceRecognition = () => {
        const recognizer = recognizerRef.current;

        if (recognizer) {
            recognizer.stopContinuousRecognitionAsync(
                () => {
                    setIsListening(false);
                    resetSilenceTimeout(); // Clear any remaining silence timeouts
                },
                err => {
                    console.error("Error stopping speech recognition: ", err);
                }
            );
        }
    };

    const setSilenceTimeout = () => {
        // Set timeout for silence detection (5 seconds)
        silenceTimeoutRef.current = setTimeout(() => {
            stopVoiceRecognition();
        }, SILENCE_DURATION);
    };

    const resetSilenceTimeout = () => {
        // Clear the previous silence timeout
        if (silenceTimeoutRef.current) {
            clearTimeout(silenceTimeoutRef.current);
        }
        // Set a new timeout for silence
        setSilenceTimeout();
    };

    useEffect(() => {
        // Cleanup on component unmount (clear the timeout)
        return () => {
            if (silenceTimeoutRef.current) {
                clearTimeout(silenceTimeoutRef.current);
            }
        };
    }, []);
    const handleVoiceSearch = () => {
        if (!isListening) {
            // Start voice recognition
            startVoiceRecognition();
        } else {
            // Stop voice recognition
            stopVoiceRecognition();
        }
    };

    const sendQuestionDisabled = disabled || !question.trim();
    const resetDisabled = !lastQuestionRef.current || disabled;

    return (
        <Stack horizontal className={styles.questionInputContainer}>
            {!disabled ? (
                <>
                    <Tooltip title="File Upload" placement="left">
                        {fileuploadelement}
                    </Tooltip>
                    <Tooltip title="Translate" placement="bottom">
                        {translatefileuploadelement}
                    </Tooltip>
                </>
            ) : (
                <>
                    <Tooltip title="File Upload" placement="left">
                        {fileuploadelement}
                    </Tooltip>
                    <Tooltip title="Translate" placement="bottom">
                        {translatefileuploadelement}
                    </Tooltip>
                </>
            )}
            <TextField
                className={styles.questionInputTextArea}
                placeholder={placeholder}
                multiline
                resizable={false}
                borderless
                value={question}
                onChange={onQuestionChange}
                onKeyDown={onEnterPress}
                disabled={disabled}
                style={{ height: "50px", fontSize: "11px" }}
                autoFocus
                componentRef={inputRef}
            />
            
            <Stack horizontal className={styles.questionInputButtonsContainer}>
                <div aria-label="Voice search button" onClick={handleVoiceSearch} className={styles.micButtonContainer}>
                    <div className={`${styles.micCircle} ${isListening ? styles.micCircleActive : ""}`} />
                    <div className={styles.micButton}>
                        <Tooltip title={isListening ? "Stop Listening" : "Use Microphone"} placement="top" style={{ marginRight: "5px" }}>
                            {isListening ? <Mic28Filled primaryFill="rgba(0,0,0)" /> : <Mic28Regular primaryFill="rgba(0, 0, 0)" />}
                        </Tooltip>
                    </div>
                </div>
            </Stack>

            <div className={styles.questionInputButtonsContainer}>
                <div aria-label="Ask question button" onClick={sendQuestion}>
                    <Tooltip title="Submit" placement="left">
                        <Send28Filled
                            primaryFill="rgba(0, 180, 237, 0.6)"
                            className={`${sendQuestionDisabled ? styles.questionInputSendButtonDisabled : ""}`}
                        />
                    </Tooltip>
                </div>
            </div>
            <div className={styles.questionInputButtonsContainer}>
                <ClearChatButton
                    className={`${resetDisabled ? styles.questionInputSendButtonDisabled : styles.resetIcon}`}
                    onClick={resetFunction}
                    disabled={resetDisabled}
                />
            </div>
        </Stack>
    );
};
