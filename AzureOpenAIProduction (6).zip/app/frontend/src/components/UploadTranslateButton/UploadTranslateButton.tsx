import { BsTranslate } from "react-icons/bs";



import styles from "./UploadDocumentButton.module.css";

interface Props {
    className?: string;
    onClick: () => void;
    disabled?: boolean;
}

export const UploadTranslateButton = ({ className, disabled, onClick }: Props) => {
    return (
        <div
            className={`${styles.container} ${className ?? ""} ${disabled ? styles.disabled : ""}`}
            onClick={disabled ? undefined : onClick}
            style={{ cursor: disabled ? 'not-allowed' : 'pointer', fontSize: "26px" }}
        >
            <BsTranslate />
        </div>
    );
};
