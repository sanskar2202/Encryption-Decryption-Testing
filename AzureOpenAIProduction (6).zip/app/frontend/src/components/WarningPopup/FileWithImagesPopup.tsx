import React, { useEffect } from "react";
import { useRecoilState } from "recoil";
import { fileSizeExceededAtom } from "../Answer/atoms";
import { Typography, Dialog, DialogTitle, DialogActions, Button, Alert, Snackbar } from "@mui/material";
import { useSetRecoilState } from "recoil";
import { useRecoilValue } from "recoil";
import CustomAlert from "./CustomAlert";



const sizeToTimeEstimates = [
    { maxSize: 0.1 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 0.3 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 0.6 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 1 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 2 * 1024 * 1024, time: "10 seconds" },
    { maxSize: 5 * 1024 * 1024, time: "30 seconds" },
    { maxSize: 10 * 1024 * 1024, time: "1.5 minute" },
    { maxSize: 20 * 1024 * 1024, time: "2 minutes" },
    { maxSize: 50 * 1024 * 1024, time: "4 minutes" },
    { maxSize: 100 * 1024 * 1024, time: "7 minutes" },
    { maxSize: 200 * 1024 * 1024, time: "15 minutes" },
    { maxSize: 500 * 1024 * 1024, time: "35 minutes" },
    { maxSize: Infinity, time: "Over 40 minutes" }
];

const getTimeEstimate = (fileSize: number): string => {
    for (const estimate of sizeToTimeEstimates) {
        if (fileSize <= estimate.maxSize) {
            return estimate.time;
        }
    }
    return "Unknown";
};

interface Props {
    // deleteEmbeddings: () => void;
    handleSubmitFile: (event: React.FormEvent) => void;
    fileUploadValidity: () => void;
    // setSnackbarMessage: (value: string) => void;
    // setOpenSnackbar: (value: boolean) => void;
    handleAlertClose: () => void;
    openFESnackbar: boolean;
    FEsnackbarMessage: string;
    imageAlert: {isActive: boolean; imageCount: number};
}

const FileWithImagesPopup = ({ handleSubmitFile, fileUploadValidity, FEsnackbarMessage, openFESnackbar, handleAlertClose,imageAlert }: Props) => {
    const { fileSizeExceeded, totalSize } = useRecoilValue(fileSizeExceededAtom);
    const setFileSizeExceeded = useSetRecoilState(fileSizeExceededAtom);
    const totalSizeMB = totalSize / (1024 * 1024); // Convert to MB
    const estimatedTime = getTimeEstimate(totalSize);

    const handleClose = () => {
        setFileSizeExceeded({ fileSizeExceeded: false, totalSize: 0 }); // Reset state
    };
    const handleContinue = () => {
        setFileSizeExceeded({ fileSizeExceeded: false, totalSize: 0 }); // Reset state
        // deleteEmbeddings();
        const syntheticEvent = new Event("submit") as unknown as React.FormEvent;
        handleSubmitFile(syntheticEvent);
        // handleSubmitFile(event);
    };
    
    return (
        <Dialog open={fileSizeExceeded} onClose={handleClose}>
            <DialogTitle>Processing Time Confirmation</DialogTitle>
            <Typography sx={{ p: 2 }}>
                The total file size is <strong>{totalSizeMB.toFixed(2)} MB</strong>. Processing this file(s) is estimated to take approximately{" "}
                <strong>{estimatedTime}</strong>.
            </Typography>
            <DialogActions>
                <Button onClick={handleContinue} color="primary">
                    Continue
                </Button>
                <Button onClick={handleClose} color="warning">
                    Cancel
                </Button>
                <Snackbar
                    open={openFESnackbar} // State controlling whether the Snackbar is open
                    autoHideDuration={6000}
                    onClose={handleAlertClose} // Function to handle closing the Snackbar
                    anchorOrigin={{ vertical: "top", horizontal: "center" }}
                >
                    {/* <Alert onClose={handleAlertClose} severity="error" sx={{ width: "100%" }}> */}
                    <Alert severity="error" onClose={handleAlertClose} variant="filled" sx={{ width: "100%" }}>
                        {FEsnackbarMessage}
                    </Alert>
                </Snackbar>
            </DialogActions>
        </Dialog>
    );
};

export default FileWithImagesPopup;
