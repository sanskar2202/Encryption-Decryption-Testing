import React, { useEffect, useState } from "react";
import { useRecoilState } from "recoil";
import { fileSizeExceededAtom } from "../Answer/atoms";
import { Typography, Dialog, DialogTitle, DialogActions, Button, Alert, Snackbar } from "@mui/material";
import { useSetRecoilState } from "recoil";
import { useRecoilValue } from "recoil";
import CustomAlert from "./CustomAlert";
import { useRef } from "react";

const sizeToTimeEstimates = [
    { maxSize: 0.01 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 0.3 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 0.6 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 1 * 1024 * 1024, time: "5 seconds" },
    { maxSize: 2 * 1024 * 1024, time: "10 seconds" },
    { maxSize: 5 * 1024 * 1024, time: "30 seconds" },
    { maxSize: 10 * 1024 * 1024, time: "1.5 minute" },
    { maxSize: 20 * 1024 * 1024, time: "2 minutes" },
    { maxSize: 50 * 1024 * 1024, time: "4 minutes" },
    { maxSize: 100 * 1024 * 1024, time: "7 minutes" },
    { maxSize: 200 * 1024 * 1024, time: "15 minutes" },
    { maxSize: 500 * 1024 * 1024, time: "35 minutes" },
    { maxSize: Infinity, time: "Over 40 minutes" }
];

const getTimeEstimate = (fileSize: number): string => {
    for (const estimate of sizeToTimeEstimates) {
        if (fileSize <= estimate.maxSize) {
            return estimate.time;
        }
    }
    return "Unknown";
};

interface Props {
    handleSubmitFile: (event: React.FormEvent, uploadType?: boolean) => void;
    fileUploadValidity: () => void;
    handleAlertClose: () => void;
    openFESnackbar: boolean;
    FEsnackbarMessage: string;
    imageAlert: { isActive: boolean; imageCount: number };
    setIsCancelled: (value: boolean) => void;
    isCancelled: boolean;
    setIsUploadClicked: (value: boolean) => void;
    setnewFileuploaded: (value: boolean) => void;
    isProceedClicked: boolean;
    setIsProceedClicked: (value: boolean) => void;
    isProceedClickedImages: boolean;
    setIsProceedClickedImages: (value: boolean) => void;
    isSPProceedClicked: boolean;
    setIsSPProceedClicked: (value: boolean) => void;
    setIsSPProceedClickedImages: (value: boolean) => void;
    activePopUp: string | null;
    setActivePopUp: (value: string | null) => void;
    isUploadEnabled: boolean;
    setIsUploadEnabled: (value: boolean) => void;
    setIsImageAlertProcessed: (value: boolean) => void;
    spFilesSize: number;
}

const FileSizeExceededPopup = ({
    handleSubmitFile,
    fileUploadValidity,
    FEsnackbarMessage,
    openFESnackbar,
    handleAlertClose,
    imageAlert,
    setIsCancelled,
    isCancelled,
    setIsUploadClicked,
    setnewFileuploaded,
    setIsProceedClicked,
    isProceedClicked,
    setIsProceedClickedImages,
    isSPProceedClicked,
    setIsSPProceedClicked,
    setIsSPProceedClickedImages,
    activePopUp,
    setActivePopUp,
    isUploadEnabled,
    setIsUploadEnabled,
    setIsImageAlertProcessed,
    spFilesSize
}: Props) => {
    const { fileSizeExceeded, totalSize } = useRecoilValue(fileSizeExceededAtom);
    const setFileSizeExceeded = useSetRecoilState(fileSizeExceededAtom);
    const totalSizeMB = totalSize / (1024 * 1024); // Convert to MB
    const estimatedTime = getTimeEstimate(totalSize);

    const estimatedTimeRef = useRef(estimatedTime);
    const totalSizeMBRef = useRef(totalSizeMB.toFixed(2));

    const totalSizeSp = spFilesSize * 1024 * 1024; // Convert to B
    const estimatedTimeSp = getTimeEstimate(totalSizeSp);
    const totalSizeMBSP = totalSize / (1024 * 1024); // Convert to MB

    const estimatedTimeRefSp = useRef(estimatedTimeSp);
    const totalSizeSpMBRef = useRef(spFilesSize.toFixed(2));

       // Update refs when `spFilesSize` changes
    useEffect(() => {
        estimatedTimeRefSp.current = estimatedTime;
        totalSizeSpMBRef.current = spFilesSize.toFixed(2);
    }, [spFilesSize, estimatedTimeSp]);

    // Update refs when `totalSize` changes
    useEffect(() => {
        estimatedTimeRef.current = estimatedTime;
        totalSizeMBRef.current = totalSizeMB.toFixed(2);
    }, [totalSize, estimatedTime]);

    // Do not render if fileSizeExceeded is false or imageAlert is not active
    if (!fileSizeExceeded && !imageAlert.isActive) {
        return null;
    }

    const handleClose = () => {
        setIsUploadClicked(false);
        setActivePopUp(null);
    };

    const handleContinue = () => {
        setIsSPProceedClicked(true);
        setFileSizeExceeded({ fileSizeExceeded: false, totalSize: 0 }); // Reset state
        // For regular files, use the existing flow
        if (activePopUp !== "sharepoint") {
            setIsProceedClicked(true);
            const syntheticEvent = new Event("submit") as unknown as React.FormEvent;
            handleSubmitFile(syntheticEvent);
        }
        
        // Close the popup
        setnewFileuploaded(false);
        setIsUploadClicked(false);
        setIsImageAlertProcessed(false);
        setIsUploadClicked(false);
        setIsUploadEnabled(false);
    };

    const handleContinueImages = () => {
        setIsSPProceedClickedImages(true);     
        setFileSizeExceeded({ fileSizeExceeded: false, totalSize: 0 }); // Reset state
        if (activePopUp !== "sharepoint") {
            setIsProceedClickedImages(true);
            const syntheticEvent = new Event("submit") as unknown as React.FormEvent;
            handleSubmitFile(syntheticEvent, true);
        }
        
        setnewFileuploaded(false);
        setIsUploadClicked(false);
        setIsImageAlertProcessed(false);
        setIsUploadClicked(false);
        setIsUploadEnabled(false);
    };

    return (
        <Dialog open={fileSizeExceeded} onClose={handleClose}>
            <DialogTitle>Processing Time Confirmation</DialogTitle>
            {activePopUp === "sharepoint" ? (
                <Typography sx={{ p: 2 }}>
                    The total size of your file(s) is <strong>{totalSizeMBSP.toFixed(2)} MB</strong>. Selected file(s) may contain 
                    images or other attributes that could increase the processing time, potentially leading to a system timeout. 
                    Continuing WITHOUT the images will reduce processing time. Please select your preference below.
                </Typography>
            ) : imageAlert.isActive ? (
                <Typography sx={{ p: 2 }}>
                    The total size of your file(s) is <strong>{totalSizeMBSP.toFixed(2)} MB</strong>. Selected file(s) may contain 
                    images or other attributes that could increase the processing time, potentially leading to a system timeout. 
                    Continuing WITHOUT the images will reduce processing time. Please select your preference below.
                </Typography>
            ) : (
                <Typography sx={{ p: 2 }}>
                    The total size of your file(s) is <strong>{totalSizeMB.toFixed(2)} MB</strong>. Processing this file(s) is estimated to take approximately{" "}
                    <strong>{estimatedTime}</strong>.
                </Typography>
            )}
            <DialogActions>
                {activePopUp === "sharepoint" ? (
                <>
                    <Button onClick={handleContinueImages} color="primary" variant="contained">
                        Continue
                    </Button>
                    <Button onClick={handleContinue} color="primary" variant="contained">
                        Continue without Images
                    </Button>
                </>
                ) : imageAlert.isActive ? (
                    <>
                        <Button onClick={handleContinueImages} color="primary" variant="contained">
                            Continue
                        </Button>
                        <Button onClick={handleContinue} color="primary" variant="contained">
                            Continue without Images
                        </Button>
                    </>
                ) : (
                    <Button onClick={handleContinue} color="primary" variant="contained">
                        Continue
                    </Button>
                )}

                <Button onClick={handleClose} color="warning" variant="contained">
                    Cancel
                </Button>

                <Snackbar open={openFESnackbar} autoHideDuration={6000} onClose={handleAlertClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                    <Alert severity="error" onClose={handleAlertClose} variant="filled" sx={{ width: "100%" }}>
                        {FEsnackbarMessage}
                    </Alert>
                </Snackbar>
            </DialogActions>
        </Dialog>
    );
};

export default FileSizeExceededPopup;