import { Alert, Snackbar } from "@mui/material";
import React, { useState } from "react";

interface Props {
    openSnackbar: boolean;
    handleAlertClose: () => void;
    snackbarMessage: string;
}

export default function CustomAlert({ openSnackbar,
     handleAlertClose,
     snackbarMessage }: Props) {
        
    return (
        <Snackbar
            open={openSnackbar} // State controlling whether the Snackbar is open
            autoHideDuration={6000}
            onClose={handleAlertClose} // Function to handle closing the Snackbar
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
            {/* <Alert onClose={handleAlertClose} severity="error" sx={{ width: "100%" }}> */}
            <Alert severity="error" onClose={handleAlertClose} variant="filled" sx={{ width: "100%" }}>
                {snackbarMessage}
            </Alert>
        </Snackbar>
    );
}
