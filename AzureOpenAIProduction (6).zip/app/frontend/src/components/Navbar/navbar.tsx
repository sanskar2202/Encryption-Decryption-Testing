import React, { useEffect, useRef, useState } from "react";
import * as IoIcons from "react-icons/io";
import { Link } from "react-router-dom";
import { SidebarData } from "./sidebar";
import "./navbar.css";
import { IconContext } from "react-icons";
import { useBoolean } from "@fluentui/react-hooks";
import GeneralHelp from "../../components/GeneralHelp/GeneralHelp";
import { logoutApi } from "../../api";
import { TextField, Dialog, DialogType, PrimaryButton, DialogFooter } from "@fluentui/react";
import { createHashRouter } from "react-router-dom";
import { useTheme } from "../../ThemeContext";
import Switch from "../../components/Switch/Switch";
import { Snackbar, Alert, AlertTitle } from "@mui/material";
import * as microsoftTeams from "@microsoft/teams-js";

const getStyles = () => ({
    main: [
        {
            selectors: {
                ["@media (min-width: 720px)"]: {
                    maxHeight: "90%",
                    minWidth: "800px",
                    maxWidth: "900px"
                }
            }
        }
    ]
});
const getStyles1 = () => ({
    main: [
        {
            borderRadius: "15px",
            selectors: {
                ["@media (min-width: 720px)"]: {
                    maxHeight: "80%",
                    minWidth: "500px",
                    maxWidth: "800px"
                }
            }
        }
    ]
});

interface NavbarProps {
    toggleNavbar: () => void;
    onParameters: () => void;
    setIsSidebarOpen: (isSidebarOpen: boolean) => void; // to pass the boolean value back to heirarchy
    isSidebarOpen: boolean;
    promptTemplate: string;
    setPromptTemplate: (promptTemplate: string) => void;
    isInTeams:boolean;
}

const Navbar = ({ onParameters, isSidebarOpen, setIsSidebarOpen, promptTemplate, setPromptTemplate,isInTeams }: NavbarProps) => {
    const [isOpen, { setTrue: openHelpWindow, setFalse: dismissHelpWindow }] = useBoolean(false);
    const [sidebar, setSidebar] = useState<boolean>(false);
    const [isConfigPanelOpen, setIsConfigPanelOpen] = useState(false);
    const promptHasChanged = useRef<boolean>(false);
    const [userName, setUserName] = useState<string>("user.name");
    const { isDarkTheme, toggleTheme } = useTheme();
    const navbarRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        microsoftTeams.app
            .initialize()
            .then(() => {
                console.log("Teams app initialized");
                
            })
            .catch(error => {
                console.error("Error initializing Teams app:", error);
            });
    }, []);
    
    const fetchUserName = async () => {
        try {
            
            
            const context = await microsoftTeams.app.getContext();
            console.log("context:", context.user?.userPrincipalName)
            
            const userPrincipalName = context.user?.userPrincipalName ?? "Unknown User"; // Extract username
            const formatUserName = (email: string) => {
                if (!email.includes("@")) return email; // Return as is if not a valid email
                
                const nameParts = email.split("@")[0].split("."); // Extract and split the name part
                
                if (nameParts.length < 2) return nameParts[0]; // If no last name, return first name as is
                
                // Capitalize the first letter of each part
                const formattedName = `${nameParts[1][0].toUpperCase() + nameParts[1].slice(1)}, ${nameParts[0][0].toUpperCase() + nameParts[0].slice(1)}`;
                
                return formattedName;
            };
            
            const user_name = formatUserName(userPrincipalName);

            setUserName(user_name); // Set the username in state
            console.log("Username set:", user_name);
        } catch (error) {
            console.error("Error fetching username:", error);
        }
    };

    useEffect(() => {
        fetchUserName(); // Call function to fetch username when Navbar loads
    }, []);

    const handleClickOutside = (event: MouseEvent) => {
        if (navbarRef.current && !navbarRef.current.contains(event.target as Node)) {
            setIsSidebarOpen(false);
        }
    };
    const [snackbarOpen, setSnackbarOpen] = React.useState(false);
    const [snackbarMessage, setSnackbarMessage] = React.useState(""); // Optional if you want dynamic messages
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error" | "info" | "warning">("info");
    const handleSnackbarClose = () => {
        setSnackbarOpen(false);
    };

    useEffect(() => {
        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [navbarRef]);

    function getCookie(name: string) {
        const cookies = document.cookie.split(";");
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith(name + "=")) {
                return cookie.substring(name.length + 1);
            }
        }
        return "user.name";
    }

    useEffect(() => {
        const name = getCookie("username");
        const decodedName = decodeURIComponent(name.replace(/^"(.*)"$/, "$1").replace(/\\054/g, ","));

        setUserName(decodedName);
    }, []);

    const closeConfigPanel = () => {
        setIsConfigPanelOpen(false);
        if (promptHasChanged.current == true) {
            clearChat();
            promptHasChanged.current = false;
        }
    };

    const clearChat = () => {};

    const clearPrompt = () => {
        setPromptTemplate("");
        clearChat();
    };

    const onPromptTemplateChange = (_ev?: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
        setPromptTemplate(newValue || "");
        promptHasChanged.current = true;
    };

    const [isDraggable, { toggle: toggleIsDraggable }] = useBoolean(false);
    const modalPropsStyles = { type: DialogType.normal, main: { maxWidth: 2000 } };
    const modalProps = React.useMemo(
        () => ({
            isBlocking: true,
            // title: "Customize ChatDSI",
            styles: modalPropsStyles
            //  dragOptions: isDraggable ? dragOptions : undefined
        }),

        [isDraggable]
    );

    const showSidebar = (): void => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const handleHelpClick = (e: React.MouseEvent) => {
        e.preventDefault();
        openHelpWindow();
    };

    // Define the router configuration
    const router = createHashRouter([
        {
            path: "/",
            lazy: () => import("../../pages/NoPage")
        }
    ]);

    const handleLogout = async () => {
        try {
            const response = await logoutApi();
            const data = await response.json();
            if (!response.ok) {
                const errorText = await response.text();

                console.error("Failed to logout:", errorText);
                setSnackbarSeverity("warning");
                setSnackbarOpen(true);
                setSnackbarMessage("Failed to logout: " + errorText);
                // return;
            }

            //

            // , "response text");
            // , "response json");

            if (response.ok) {
                // Assuming the backend will return a success message or status

                setSnackbarSeverity("warning");
                setSnackbarOpen(true);
                setSnackbarMessage(
                    decodeURIComponent(
                        getCookie("username")
                            .replace(/^"(.*)"$/, "$1")
                            .replace(/\\054/g, ",")
                    ) + " logged out successfully"
                );

                window.location.replace(data.auth_url);
            } else {
                console.error("Failed to logout");
            }
        } catch (error) {
            console.error("An error occurred during logout", error);
            setSnackbarSeverity("warning");
            setSnackbarOpen(true);
            setSnackbarMessage("An error occurred during logout");
        }
    };

    const dragOptions = {
        moveMenuItemText: "Move",
        closeMenuItemText: "Close"
    };

    const handleFeedbackClick = () => {
        window.open(
            "https://forms.office.com/Pages/ResponsePage.aspx?id=4238N9Cd1EWRxiBMuaS6xoxYQ9DMVdBMt2PkAmCHfaRUQlFHSFNMUDlVUzVYWlBCQ0NVWkUwTEYySi4u",
            "_blank"
        );
    };

    const sidebarItems = SidebarData(isDarkTheme,isInTeams);

    return (
        <div ref={navbarRef}>
            <IconContext.Provider value={{ color: "#fff" }}>
                <div className={`navbar ${isDarkTheme ? "dark-theme" : "bright-theme"}`}>
                    <button className="menu-bars no-border" onClick={showSidebar}>
                        <IoIcons.IoMdMenu style={{ color: isDarkTheme ? "white" : "black" }} />
                    </button>
                </div>
                <nav className={`nav-menu ${isSidebarOpen ? "active" : ""} ${isDarkTheme ? "dark-theme" : "bright-theme"}`}>
                    <ul className={"nav-menu-items"}>
                        {sidebarItems.map((item, index) => (
                            <li key={index} className={item.cName}>
                                {item.path ? (
                                    <Link to={item.path}>
                                        <div>
                                            <div className="navbar-icons">{item.icon}</div>
                                            <span className="navtextSpan">{item.title}</span>
                                        </div>
                                        <span>{">"}</span>
                                    </Link>
                                ) : item.title === "Help" ? (
                                    <div onClick={handleHelpClick} className="nav-text-clickable">
                                        <div className="navbar-icons">{item.icon}</div>
                                        <span className="navtextSpan">{item.title}</span>
                                    </div>
                                ) : item.title === "Feedback" ? (
                                    <div onClick={handleFeedbackClick} className="nav-text-clickable ">
                                        <div className="navbar-icons">{item.icon}</div>
                                        <span className="navtextSpan">{item.title}</span>
                                    </div>
                                ) : item.title === "Customize" ? (
                                    <div onClick={() => setIsConfigPanelOpen(!isConfigPanelOpen)} className="nav-text-clickable ">
                                        <div className="navbar-icons">{item.icon}</div>
                                        <span className="navtextSpan">{item.title}</span>
                                    </div>
                                ) : item.title === "Logout" ? (
                                    <div onClick={handleLogout}>
                                        <div className="navbar-icons">{item.icon}</div>
                                        <span className="navtextSpan"> {item.title}</span>
                                    </div>
                                ) : item.title === "username" ? (
                                    <div>
                                        <div className="navbar-icons">{item.icon}</div>
                                        <span className="navtextSpan">{userName}</span>
                                    </div>
                                ) : item.isSwitch ? (
                                    <div>
                                        <Switch checked={isDarkTheme} onChange={toggleTheme} />
                                        <span className="theme-text navtextSpan">{isDarkTheme ? "Dark Mode" : "Light Mode"}</span>
                                    </div>
                                ) : (
                                    <>
                                        {/* {getCookie("username")} */}
                                        <div className="navbar-icons">{item.icon}</div>
                                        <span className="navtextSpan">{item.title}</span>
                                    </>
                                )}
                            </li>
                        ))}
                    </ul>
                </nav>
                <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleSnackbarClose} anchorOrigin={{ vertical: "top", horizontal: "center" }}>
                    <Alert onClose={handleSnackbarClose} severity={snackbarSeverity}>
                        <AlertTitle>ChatDSI Says:</AlertTitle>
                        {snackbarMessage}
                    </Alert>
                </Snackbar>
                <Dialog
                    hidden={!isOpen}
                    onDismiss={dismissHelpWindow}
                    modalProps={modalProps}
                    dialogContentProps={{
                        title: "ChatDSI Helper",
                        closeButtonAriaLabel: "Close"
                    }}
                    styles={getStyles}
                >
                    <GeneralHelp />
                </Dialog>
                <div className="customizeChatDSI">
                    <Dialog
                        dialogContentProps={{
                            title: "Customize ChatDSI's Behavior",
                            closeButtonAriaLabel: "Save"
                        }}
                        modalProps={modalProps}
                        hidden={!isConfigPanelOpen}
                        // isBlocking={false}
                        onDismiss={() => setIsConfigPanelOpen(false)}
                        styles={getStyles1}
                    >
                        <DialogFooter>
                            <PrimaryButton className="saveConfigPanel" onClick={closeConfigPanel} text="Save" />
                        </DialogFooter>
                        <hr style={{ margin: "0px 0", color: "red" }} />
                        <div className="parameterstext1">
                            Customize your chat experience by telling ChatDSI to take on specific roles that meet your exact needs (e.g., an IT expert, a
                            Regulatory Affairs Specialist, a Business Coach). When you do this, ChatDSI will provide responses from the perspective and
                            knowledge of the role requested and written in the tone or style expected of that role.
                            <br />
                            <br />
                            The advantage of using role-prompting is that it enables ChatDSI to generate responses that are more tailored, detailed, and aligned
                            with the expertise of the requested assignment. It’s like you’re having a conversation with someone in that role!
                            <br />
                            <br />
                            Just enter your instructions in the Custom Prompt field below, and be specific as possible, including any instructions on how you
                            want it to provide the responses too. See examples in the prompt window below.
                        </div>
                        <TextField
                            defaultValue={promptTemplate}
                            label="Custom Prompt"
                            multiline
                            rows={5}
                            autoAdjustHeight
                            onChange={onPromptTemplateChange}
                            className="chatPromptTemplate"
                            placeholder={`Examples:\n\n“Act as an English to Japanese translator.”\n\n“You are a clinical trial specialist. Answer questions with references to trial phases, regulatory approaches and study data.”\n\n“You are a medical researcher. Use academic tone and cite studies.”\n\n“Take on the role of a Python coding assistant to provide guidance and support in Python programming tasks.”`}
                        />

                        <div className="parametertext1" style={{ fontSize: "11px" }}>
                            <br />
                            When you hit save, this will override ChatDSI's usual behavior, and it will only function as instructed until the prompt is cleared
                            via the "Clear Prompt" link that will appear above the prompt bar. More on this feature can be found in the user manual.
                        </div>

                        {/* <div className="parameterstext2">
                            By leveraging role prompting in these ways, employees can gain valuable insights and structured guidance tailored to their specific
                            roles and responsibilities within the pharmaceutical company. In the above examples, if you didn't ask the AI to take on the
                            specific role but still asked the questions that follow, would you get different answers from the tool?
                            <br />
                            <br />
                            Yes, if you didn't explicitly ask the AI to take on a specific role but still asked the same questions, the answers might differ in
                            tone, depth, and focus. Here’s how:
                            <br />
                            <br />
                            <b>1. Regulatory Affairs Specialist:</b>
                            <br />
                            <br />- <b>With Role Prompting:</b> "You are a Regulatory Affairs Specialist. Provide a detailed summary of the key regulatory
                            requirements for submitting a new drug application (NDA) to the FDA, including necessary documentation, timelines, and common
                            pitfalls to avoid."
                            <br />
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;- <b>Response:</b> The AI would likely provide a detailed, structured summary focusing on regulatory
                            guidelines, specific documentation needed, timelines, and common pitfalls, reflecting the expertise of a regulatory affairs
                            specialist.
                            <br />
                            <br />- <b>Without Role Prompting:</b> "Provide a summary of the key regulatory requirements for submitting a new drug application
                            (NDA) to the FDA."
                            <br />
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;- <b>Response:</b> The AI might give a more general overview of the regulatory requirements, possibly
                            lacking the depth and specific insights that a regulatory affairs specialist would provide.
                            <br />
                            <br />
                            <b>2. Clinical Trial Coordinator:</b>
                            <br />
                            <br />- <b>With Role Prompting:</b> "You are a Clinical Trial Coordinator. Outline a comprehensive plan for managing a Phase III
                            clinical trial for a new oncology drug, including patient recruitment strategies, data collection methods, and ensuring adherence to
                            ethical standards."
                            <br />
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;- <b>Response:</b> The AI would likely offer a detailed plan that includes specific strategies for patient
                            recruitment, data collection methods, and ethical considerations, reflecting the responsibilities and expertise of a clinical trial
                            coordinator.
                            <br />
                            <br />- <b>Without Role Prompting:</b> "Outline a plan for managing a Phase III clinical trial for a new oncology drug."
                            <br />
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;- <b>Response:</b> The AI might provide a general plan without the specific focus on patient recruitment
                            strategies, data collection methods, and ethical standards that a clinical trial coordinator would emphasize.
                            <br />
                            <br />
                            <b>3. Pharmaceutical Marketing Strategist:</b>
                            <br />
                            <br />- <b>With Role Prompting:</b> "You are a Pharmaceutical Marketing Strategist. Create a marketing campaign for the launch of a
                            new cholesterol-lowering medication, highlighting the key benefits, target audience, and multi-channel marketing strategies to
                            maximize reach and engagement."
                            <br />
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;- <b>Response:</b> The AI would likely produce a detailed marketing campaign that includes specific
                            strategies for highlighting benefits, identifying target audiences, and utilizing various marketing channels, reflecting the
                            expertise and strategic thinking of a marketing strategist.
                            <br />
                            <br />- <b>Without Role Prompting:</b> "Create a marketing campaign for the launch of a new cholesterol-lowering medication."
                            <br />
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;- <b>Response:</b> The AI might provide a more general marketing plan that lacks the strategic depth and
                            specific focus on target audiences and multi-channel strategies that a marketing strategist would include.
                            <br />
                            <br />
                            In summary, role prompting helps the AI generate responses that are more tailored, detailed, and aligned with the expertise and
                            perspective of the specified role. Without role prompting, the responses may be more general and less focused on the specific
                            nuances and insights relevant to the role.
                        </div> */}
                    </Dialog>
                </div>
            </IconContext.Provider>
        </div>
    );
};

export default Navbar;
