import { Modal, Box, Button, Typography } from '@mui/material';

interface DocumentPreviewModalProps {
  open: boolean;
  onClose: () => void;
  documentUrl: string;
 
}

export function DocumentPreviewModal({ open, onClose, documentUrl }: DocumentPreviewModalProps) {
  
  return (
    <Modal open={open} onClose={onClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '80%',
          height: '80%',
          bgcolor: 'background.paper',
          boxShadow: 24,
          p: 4,
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <Typography variant="h6" component="h2" gutterBottom>
          Citations Preview:
        </Typography>
        <iframe
          src={documentUrl}
          title="Citations Preview"
          style={{ flexGrow: 1, width: '100%', height: '100%', border: 'none' }}
        />
        <Box mt={2}>
          <Button variant="contained" color="primary" onClick={onClose}>
            Close
          </Button>
        </Box>
      </Box>
    </Modal>
  );
}
