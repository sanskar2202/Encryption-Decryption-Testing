interface OpenLinkProps {
    documentUrl: string;
}

const OpenLink = ({ documentUrl }: OpenLinkProps) => {
    const openInNewTab = () => {
        const tempURL =
            "https://sankyopharma.sharepoint.com/sites/DSTeam_CoE_AIML/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FDSTeam%5FCoE%5FAIML%2FShared%20Documents%2FGeneral%2FOpen%20AI%20Enablement%2F001%20Landing%20Page%20Content%2FReference%20Materials%2FUsage%20Guidelines%2FChatDSI%20Usage%20Guidelines%5FProduction%20Version%2Epdf&parent=%2Fsites%2FDSTeam%5FCoE%5FAIML%2FShared%20Documents%2FGeneral%2FOpen%20AI%20Enablement%2F001%20Landing%20Page%20Content%2FReference%20Materials%2FUsage%20Guidelines&p=true&ga=1";
        window.open(documentUrl, "_blank", "noopener,noreferrer");
    };

    return <button onClick={openInNewTab}>Citation Preview</button>;
};

export default OpenLink;
