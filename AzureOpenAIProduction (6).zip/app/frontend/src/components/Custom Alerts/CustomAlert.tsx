import { Snackbar, Alert, AlertColor } from "@mui/material";
import { SyntheticEvent } from "react";

export type SnackbarPosition =
  | "top-left"
  | "top-center"
  | "top-right"
  | "bottom-left"
  | "bottom-center"
  | "bottom-right";

type CustomAlertConfig = {
  open: boolean;
  message: string;
  severity?: AlertColor;
  autoHideDuration?: number;
  anchorOrigin?: SnackbarPosition;
  onClose: (event?: SyntheticEvent | Event, reason?: string) => void;
};

type CustomAlertProps = {
  config: CustomAlertConfig;
};

export default function CustomAlert({ config }: CustomAlertProps) {
  const {
    open,
    message,
    severity = "info",
    autoHideDuration = 6000,
    anchorOrigin = "top-center",
    onClose,
  } = config;

  const [vertical, horizontal] = anchorOrigin.split("-") as [
    "top" | "bottom",
    "left" | "center" | "right"
  ];

  return (
    <Snackbar
      open={open}
      autoHideDuration={autoHideDuration}
      onClose={onClose}
      anchorOrigin={{ vertical, horizontal }}
      sx={{ zIndex: 5000301 }} // Snackbar z-index should be higher than the modal's
    >
      <Alert severity={severity} onClose={onClose} sx={{ width: "100%" }}>
        {message}
      </Alert>
    </Snackbar>
  );
}

// export default CustomAlert;
