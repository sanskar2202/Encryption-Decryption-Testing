import { Snackbar, Alert, AlertColor } from "@mui/material";
import { createContext, useContext, useState, ReactNode, SyntheticEvent } from "react";

// Types for position and config
export type SnackbarPosition =
  | "top-left"
  | "top-center"
  | "top-right"
  | "bottom-left"
  | "bottom-center"
  | "bottom-right";

// Updated SnackbarConfig with mandatory 'open' property
export type SnackbarConfig = {
  open: boolean; // Make 'open' mandatory
  message: string;
  severity?: AlertColor;
  autoHideDuration?: number | null;
  anchorOrigin?: SnackbarPosition;
  onClose?: (event?: SyntheticEvent | Event, reason?: string) => void;
  action?: ReactNode;
  sx?: object;
  variant?: "filled" | "outlined" | "standard";
};

// Context type
type SnackbarContextType = {
  setAlertConfig: (config: SnackbarConfig) => void;
  hideAlert: () => void;
  resetAlert: () => void;
};

// Context creation
const SnackbarContext = createContext<SnackbarContextType | null>(null);

// Hook to use Snackbar context
export const useGlobalAlerts = () => {
  const ctx = useContext(SnackbarContext);
  if (!ctx) throw new Error("useGlobalAlerts must be used inside GlobalAlertsProvider");
  return ctx;
};

// Helper to parse position string into MUI format
function parseAnchor(anchor: SnackbarPosition) {
  const [vertical, horizontal] = anchor.split("-") as [
    "top" | "bottom",
    "left" | "center" | "right"
  ];
  return { vertical, horizontal };
}

// Provider component
function GlobalAlertsProvider({ children }: { children?: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [config, setConfig] = useState<SnackbarConfig>({
    open: false,  // Default to false, to be updated when triggered
    message: "",
    severity: "info",
    autoHideDuration: 6000,
    anchorOrigin: "top-center",
  });

  const setAlertConfig = (incomingConfig: SnackbarConfig) => {
    if (incomingConfig.open) {
      setConfig({
        ...incomingConfig,
        severity: incomingConfig.severity || "info",
        autoHideDuration: incomingConfig.autoHideDuration ?? 6000,
        anchorOrigin: incomingConfig.anchorOrigin || "top-center",
      });
      setOpen(true); // Trigger the alert
    }
  };

  const hideAlert = () => {
    setOpen(false);
  };

  const resetAlert = () => {
    setOpen(false);
    setConfig({
      open: false,
      message: "",
      severity: "info",
      autoHideDuration: 6000,
      anchorOrigin: "top-center",
    });
  };

  const internalClose = (event?: SyntheticEvent | Event, reason?: string) => {
    setOpen(false);
    config.onClose?.(event, reason);
  };

  const { vertical, horizontal } = parseAnchor(config.anchorOrigin || "top-center");

  return (
    <SnackbarContext.Provider value={{ setAlertConfig, hideAlert, resetAlert }}>
      {children}
      <Snackbar
        open={open}
        autoHideDuration={config.autoHideDuration}
        onClose={internalClose}
        anchorOrigin={{ vertical, horizontal }}
        sx={{ zIndex: 9999 }}
      >
        <Alert
          onClose={internalClose}
          severity={config.severity}
          variant={config.variant || "standard"}
          sx={config.sx}
          action={config.action}
        >
          {config.message}
        </Alert>
      </Snackbar>
    </SnackbarContext.Provider>
  );
}

export default GlobalAlertsProvider;
