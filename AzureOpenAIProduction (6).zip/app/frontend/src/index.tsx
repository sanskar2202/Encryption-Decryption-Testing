import React, { useState,useEffect } from "react";
import ReactDOM from "react-dom/client";
import { createHashRouter, RouterProvider } from "react-router-dom";
import { initializeIcons } from "@fluentui/react";

import "./index.css";

import Layout from "./pages/layout/Layout";
import Chat from "./pages/AIchat/Chat";
import { ThemeProvider } from "./ThemeContext";
import * as microsoftTeams from "@microsoft/teams-js";
import { sendTokenToBackend} from "./api";
import GlobalAlertsProvider from "./components/Custom Alerts/GlobalAlertsProvider";


initializeIcons();
function App() {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    
    const [promptTemplate, setPromptTemplate] = useState<string>("");
    const [isInTeams, setIsInTeams] =  useState<boolean>(false);
    




    useEffect(() => {
        const isIframe = window.self !== window.top;
    
        if (isIframe) {
            setIsInTeams(true);
    
            const fetchToken = async () => {
                try {
                    await microsoftTeams.app.initialize();
                    console.log("Teams app initialized");
    
                    microsoftTeams.authentication.getAuthToken({
                        successCallback: async (token) => {
                            console.log("Token acquired:", token);
    
                            const context = await microsoftTeams.app.getContext();
                            console.log("Context acquired:", context);
                            const userName = context?.user?.loginHint || "Unknown User";
                            console.log("UserName acquired:", userName);
    
                            await sendTokenToBackend(token, userName);
                        },
                        failureCallback: (error) => {
                            console.error("Failed to acquire token:", error);
                        }
                    });
                } catch (error) {
                    console.error("Failed to initialize Teams app:", error);
                }
            };
    
            fetchToken();
        } else {
            setIsInTeams(false);
        }
    }, []);
    

    
        
        


    
        



    
    const router = createHashRouter([
        {
            path: "/",
            element: (
                <Layout
                    isInTeams = {isInTeams}
                    
                    isSidebarOpen={isSidebarOpen}
                    setIsSidebarOpen={setIsSidebarOpen}
                    promptTemplate={promptTemplate}
                    setPromptTemplate={setPromptTemplate}
                />
            ),
            children: [
                {
                    index: true,
                    element: <Chat isSideBarOpen={isSidebarOpen} promptTemplate={promptTemplate} setPromptTemplate={setPromptTemplate} isInTeams = {isInTeams} />
                    
                },
                {
                    path: "*",
                    lazy: () => import("./pages/NoPage")
                }
            ]
        }
    ]);

    // Render the router
    return (
        <React.StrictMode>
            <ThemeProvider>
            <GlobalAlertsProvider>
                <RouterProvider router={router} />
            </GlobalAlertsProvider>
            </ThemeProvider>
        </React.StrictMode>
    );
}

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(<App />);
