import { useRef, useState, useEffect } from "react";
import { useBoolean } from "@fluentui/react-hooks";
import { DefaultButton, Text } from "@fluentui/react";
import readNDJSONStream from "ndjson-readablestream";
import styles from "./Chat.module.css";
import { chatApi, Approaches, AskResponse, ChatRequest, ChatTurn } from "../../api";
import { Answer, AnswerError, AnswerLoading } from "../../components/Answer";
import { QuestionInput } from "../../components/QuestionInput";
import { UserChatMessage } from "../../components/UserChatMessage";
import { AnalysisPanelTabs } from "../../components/AnalysisPanel";
import { IDropdownOption } from "@fluentui/react/lib/Dropdown";
import { Access } from "../../api";
import { accessApi } from "../../api";
import { UploadDocumentButton } from "../../components/UploadDocumentButton/UploadDocument";
import { UploadImageButton } from "../../components/UploadImageButton/UploadImage";
import { UploadTranslateButton } from "../../components/UploadTranslateButton/UploadTranslateButton";
import FileUploadModal from "../../components/FileUpload/FileUpload";
import FileTranslateModal from "../../components/FileUpload/FileTranslate";
import { FileUpload, uploadApi, doctranslateApi, translateApi } from "../../api";
import { Snackbar, Alert, AlertTitle, Button } from "@mui/material";
import "../../components/Navbar/navbar.css";
import { useRecoilState } from "recoil";
import { selectedMessageAtom } from "../../components/UserChatMessage/Atom";
import { FaLess, FaStop } from "react-icons/fa6";
import { useTheme } from "../../ThemeContext";
// import { BsTranslate } from "react-icons/bs";
// import { Stack, ActionButton, PrimaryButton, Dialog, DialogType, DialogFooter, Dropdown } from "@fluentui/react";
// import { IconButton } from "@fluentui/react/lib/Button";
import * as sdk from "microsoft-cognitiveservices-speech-sdk";
import { franc } from "franc";
import { fileSizeExceededAtom } from "../../components/Answer/atoms";
import { useSetRecoilState } from "recoil";
import fileImageDetection from "../../components/FileUpload/fileImageDetection";
// import { GlobalWorkerOptions } from "pdfjs-dist";
import config from "../../../config.json"
// Set the workerSrc to a CDN-hosted worker file
// GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.9.155/pdf.worker.min.js`;

interface ChatProps {
    isSideBarOpen: boolean;
    promptTemplate: string;
    setPromptTemplate: (promptTemplate: string) => void;
    isInTeams: boolean;
    
}

const Chat = ({ isSideBarOpen, promptTemplate, setPromptTemplate,isInTeams }: ChatProps) => {
    //
    const [isConfigPanelOpen, setIsConfigPanelOpen] = useState(false);
    const [prevfileselctor, setPrevFileSelector] = useState<string>("file");
    // const [promptTemplate, setPromptTemplate] = useState<string>("");
    const [shouldStream, setShouldStream] = useState<boolean>(true);
    const [isScreenSmall, setIsScreenSmall] = useState<boolean>(window.innerWidth < 769);
    const [useSuggestFollowupQuestions, setUseSuggestFollowupQuestions] = useState<boolean>(false);
    const lastQuestionRef = useRef<string>("");
    const chatMessageStreamEnd = useRef<HTMLDivElement | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isAnswerCompleted, setAnswerCompletion] = useState<boolean>(false);
    const [error, setError] = useState<unknown>();
    const [isOpen, { setTrue: openHelpWindow, setFalse: dismissHelpWindow }] = useBoolean(false);
    const [activeCitation, setActiveCitation] = useState<string>();
    const [activeAnalysisPanelTab, setActiveAnalysisPanelTab] = useState<AnalysisPanelTabs | undefined>(undefined);
    const modelApproach = useRef<string>("GPT3.5");
    const [modelApproachState, setModelApproachState] = useState<string>("GPT3.5");

    const [selectedAnswer, setSelectedAnswer] = useState<number>(0);
    const [answers, setAnswers] = useState<[user: string, response: AskResponse][]>([]);
    const [sliderValue, setSliderValue] = useState(5);
    const promptHasChanged = useRef<boolean>(false);
    const sliderAriaValueText = (value: number) => `${value / 10}`;
    const sliderValueFormat = (value: number) => `${value / 10}`;
    const [fileUploadPanelOpen, setFileUploadPanelOpen] = useState(false);
    const [fileTranslatePanelOpen, setFileTranslatePanelOpen] = useState(false);

    const [showTooltip, setShowTooltip] = useState(true);
    const [fileNames, setFileNames] = useState<string[]>([]);
    const [files, setFiles] = useState<File[]>([]);
    const [uploadType, setUploadType] = useState<boolean>(false);
    const [isEmbeddingsLoading, setIsEmbeddingsLoading] = useState(false);
    const [embeddingsLoaded, setEmbeddingsLoaded] = useState(false);
    const [readAloudCalled, setReadAloudCalled] = useState(false);
    const [openAlert, setOpenAlert] = useState(false);
    const [translateOpenAlert, setTranslateOpenAlert] = useState(false);
    const [selectedModel, setSelectedModel] = useState<IDropdownOption | undefined>({ key: "GPT3.5", text: "GPT 3.5" });
    const [openDocClearAlertForTranslate, setOpenDocClearAlertForTranslate] = useState(false);
    const [openDocClearAlert, setOpenDocClearAlert] = useState(false);
    const [openDocClearAlertforchat, setOpenDocClearAlertforchat] = useState(false);
    const [openWarning, setWarning] = useState(false);
    const [stopGenerating, setStopGenerating] = useState(false);
    const { isDarkTheme, toggleTheme } = useTheme();
    const [uploaded_files, setuploaded_files] = useState<string[]>([]);
    const [openGuidlinesAlert, setOpenGuidlinesAlert] = useState(false);
    const [translatedURL, setTranslatedURL] = useState<{ [key: string]: string }>({});
    const [targetBlobClient, setTargetBlobClient] = useState<string>("");
    const [connString, setConnectionString] = useState<string>("");
    const [targetContainer, setTargetContainerName] = useState<string>("");
    const [translatedFolder, setTranslatedFolderName] = useState<string>("");
    const [translatedFileName, setTranslatedFileName] = useState<string>("");
    const [isTranslating, setTranslating] = useState<boolean>(false);
    const [disableFUIcon, setDisableFUIcon] = useState<boolean>(false);
    const [disableFUIconn, setDisableFUIconn] = useState<boolean>(false);
    const [disableIUIcon, setDisableIUIcon] = useState<boolean>(false);
    const [disableTUIcon, setDisableTUIcon] = useState<boolean>(false);
    const [disableExcelIcon, setDisableExcelIcon] = useState<boolean>(false);
    const [pageUrls, setPageUrls] = useState<string[]>([]);
    const setFileSizeExceeded = useSetRecoilState(fileSizeExceededAtom);
    const [disableSharePointIcon, setDisableSharePointIcon] = useState<boolean>(false);
    // const showTranslateDialog = () => setIsTranslateDialogVisible(true);
    const [translateEnabled, setTranslateEnabled] = useState(false);
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error" | "info" | "warning">("info");
    //snackbar for error message
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [openFSnackbar, setOpenFSnackbar] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");
    const [snackbarFMessage, setSnackbarFMessage] = useState("");
    const onChangeModel = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption | undefined): void => {
        setSelectedModel(item);
    };

    const sliderOnChange = (value: number) => setSliderValue(value);

    const [chatHistoryForRequest, setChatHistoryForRequest] = useState<[user: string, response: AskResponse][]>([]);
    const [genHistoryForRequest, setGenHistoryForRequest] = useState<[user: string, response: AskResponse][]>([]);
    const [spHistoryForRequest, setSpHistoryForRequest] = useState<[user: string, response: AskResponse][]>([]);
    const [sharepointFilesLoaded, setSharepointFilesLoaded] = useState(false);

    
    const getStyles = () => ({
        main: [
            {
                selectors: {
                    ["@media (min-width: 720px)"]: {
                        maxHeight: "90%",
                        minWidth: "800px",
                        maxWidth: "900px"
                    }
                }
            }
        ]
    });

    const openFileUploadPanel = () => {
        if (!isAnswerCompleted) setFileUploadPanelOpen(true);
    };
    const openTranlateUploadPanel = () => {
        if (!isAnswerCompleted) setFileTranslatePanelOpen(true);
    };
    // const [preFileSelector, setPreFileSelector] = useState<string[]>([]);
    const closeFileUploadPanel = () => {
        setFileUploadPanelOpen(false);
        setFileTranslatePanelOpen(false);
        handleAlertClose();
        // if (fileSelector == "translate"){
        //     setFileSelector("file");

        // }
        if (fileSelector == "translate") {
            setFileSelector(prevfileselctor);
        }

        
        // if (Object.keys(translatedURL).length > 0) {
        //     deleteEmbeddings();
        // }
    };

    const openTooltip = () => {
        if (fileUploadPanelOpen) {
            setShowTooltip(false);
        }
    };

    const handleTranslateRequest = async (event: React.FormEvent, languages: string[]) => {
        event.preventDefault();

        if (files.length === 0 || languages.length === 0) {
            console.error("Files or languages are missing.");
            return;
        }
        setTranslating(true);
        try {
            // Send selected languages
            const langResponse = await translateApi(languages);
            const langResult = await langResponse.json();

            if (!langResponse.ok) {
                console.error("Error sending languages:", langResult);
                setTranslating(false);
                return;
            }
            // try{
            if (files.length > 0) {
                const request: FileUpload = {
                    files: files
                };
                const response = await doctranslateApi(request);

                const data = await response.json();

                if (response.status === 200) {
                    setTranslateOpenAlert(true);
                    // setEmbeddingsLoaded(true);
                    setFileNames([]);
                    // Assuming files is an array of File objects
                    const uploadedFileNames = files.map(file => file.name);

                    // Append the uploaded file names to the fileNames state
                    setuploaded_files(prevFileNames => [...prevFileNames, ...uploadedFileNames]);
                    setTranslatedURL(data.translated_file_uri);
                    setTargetBlobClient(data.target_blob_client);
                    setConnectionString(data.connection_string);
                    setTargetContainerName(data.target_container_name);
                    setTranslatedFolderName(data.translated_folder_name);
                    setTranslatedFileName(data.translated_file_name);
                }
            }
        } catch (error) {
            console.error("Error:", error);
            if (error instanceof Error) {
                if (error.message === "translate_error") {
                    console.error("if translate_error");
                    setSnackbarSeverity("warning");
                    setSnackbarOpen(true);
                    setSnackbarMessage(
                        "There was an error while opening the file. It could be due to various technical issues. Please try saving the file under different name and try. If the problem persists, please contact DLUS-appsupport_genai@daiichisankyo.com "
                    );
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableIUIcon(false);
                    setDisableExcelIcon(false);
                    setDisableSharePointIcon(false);
                    setDisableFUIconn(false);
                }
            }
        } finally {
            setTranslating(false);
        }
    };
    const [isFileProcessed, setIsFileProcessed] = useState<boolean>(false);
    const [isUploading, setIsUploading] = useState<boolean>(false);
    const [openSuccessAlert, setOpenSuccessAlert] = useState(false);
    const [result, setResult] = useState(null);
    const [isUploadClicked, setIsUploadClicked] = useState<boolean>(false);
    const [isCancelled, setIsCancelled] = useState<boolean>(false);
    const [isProceedClicked, setIsProceedClicked] = useState<boolean>(false);
    const [isProceedClickedImages, setIsProceedClickedImages] = useState<boolean>(false);
    const [isSPProceedClicked, setIsSPProceedClicked] = useState<boolean>(false);
    const [isSPProceedClickedImages, setIsSPProceedClickedImages] = useState<boolean>(false);
    const [isUnstructured, setIsUnstructured] = useState<boolean>(false);
    const [isUploadEnabled, setIsUploadEnabled] = useState<boolean>(false);

    const handleFileSelection = async (files: File[]) => {
        console.log("inside handleFileSelection");
        if (!files || files.length === 0) return;
    
        let firstFile = files[0];
    
        // Find the largest file
        files.forEach(file => {
            if (file.size > firstFile.size) {
                firstFile = file;
            }
        });
        const allowedFileExtensions = /(\.pdf|\.PDF|\.txt|\.TXT|\.pptx|\.PPTX|\.docx|\.DOCX)$/i;
        const allowedExcelExtensions = /(\.csv|\.CSV|\.xlsx|\.XLSX)$/i;
        const allowedImgExtensions = /(\.jpg|\.JPG|\.png|\.PNG|\.jpeg|\.JPEG|\.bmp|\.BMP|\.webp|\.WEBP|\.tiff|\.TIFF|\.tif|\.TIF|\.gif|\.GIF)$/i;
        const TranslateallowedExtensions = /(\.pdf|\.txt|\.pptx|\.docx|\.csv|\.CSV|\.xlsx|\.XLSX)$/i;
    
        if (allowedFileExtensions.exec(firstFile.name) && fileSelector === "file") {
            setDisableIUIcon(true);
            setDisableFUIcon(false);
            setDisableTUIcon(true);
            setDisableExcelIcon(true);
            setDisableSharePointIcon(true);
            await detectImageInFile(firstFile);
            return;
        }
    
        if (TranslateallowedExtensions.exec(firstFile.name) && fileSelector === "translate") {
            setDisableIUIcon(true);
            setDisableFUIcon(true);
            setDisableExcelIcon(true);
            setDisableTUIcon(false);
            setDisableSharePointIcon(true);
            await detectImageInFile(firstFile);
            return;
        }
    
        if (allowedImgExtensions.exec(firstFile.name)) {
            setDisableIUIcon(false);
            setDisableFUIcon(false);
            setDisableTUIcon(true);
            setDisableExcelIcon(true);
            setDisableSharePointIcon(true);
            setDisableFUIconn(true);
            return;
        }
    
        if (allowedExcelExtensions.exec(firstFile.name)) {
            setDisableIUIcon(true);
            setDisableFUIcon(false);
            setDisableTUIcon(true);
            setDisableExcelIcon(false);
            setDisableSharePointIcon(true);
            setDisableFUIconn(true);
            return;
        }
    
        if (sharepointloaded) {
            setDisableIUIcon(true);
            setDisableFUIcon(true);
            setDisableTUIcon(true);
            setDisableExcelIcon(true);
            setDisableSharePointIcon(false);
            return;
        }
    
        console.log("disableIUIcon", disableIUIcon);
        console.log("disableFUIcon", disableFUIcon);
        console.log("disableTUIcon", disableTUIcon);
        console.log("disableExcelIcon", disableExcelIcon);
        console.log("disableSharePointIcon", disableSharePointIcon);
    };

    const handleSubmitFileforCSV_Excel_and_Images = async (event: React.FormEvent, uploadType?: boolean) => {
        event.preventDefault();
        
        setIsEmbeddingsLoading(true);
        
        try {
            if (files.length > 0) {
                handleFileSelection(files);                
                const request: FileUpload = {
                    files: files,
                    ...(uploadType !== undefined && { uploadType })
                };

                const response = await uploadApi(request);

                if (response.status === "success") {
                    setOpenAlert(true);
                    setEmbeddingsLoaded(true);
                    setFileNames([]);
                    // Assuming files is an array of File objects
                    const uploadedFileNames = files.map(file => file.name);

                    // Append the uploaded file names to the fileNames state
                    setuploaded_files(prevFileNames => [...prevFileNames, ...uploadedFileNames]);
                    closeFileUploadPanel();
                    setOpenSuccessAlert(true);
                    //// console.log(openSuccessAlert);
                }
            }
        } catch (error: unknown) {
            console.error("Error uploading files:", error);
            setFileNames([]);

            // Set state to show Snackbar with error message
            if (error instanceof Error) {
                if (error.message === "try_after_some_time") {
                    console.error("if try_after_some_time");
                    setSnackbarFMessage("Please Try after some time");
                    setOpenFSnackbar(true);
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableIUIcon(false);
                    setDisableExcelIcon(false);
                    setDisableSharePointIcon(false);
                    clearEmbeddings();
                } else if (error.message === "file_size_error") {
                    console.error("if file_size_error");
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    // setSnackbarFMessage(
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);
                    clearEmbeddings();
                } else if (error.message === "csv_excel_error") {
                    console.error("if csv_excel:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Upload Single Excel or CSV File, Cannot be uploaded with multiple files.");
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);
                } else if (error.message === "csv_excel_already_present_error") {
                    console.error("if csv_excel_already_present:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("CSV/Excel already uploaded, Clear it and try uploading");
                } else if (error.message === "unstructured_data_already_uploaded") {
                    console.error("if unstructured_data_already_uploaded:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Delete the previously uploaded files before uploading CSV/Excel, and try uploading");
                } else if (error.message === "unstructured_data_already_uploaded_image") {
                    console.error("if unstructured_data_already_uploaded:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Delete the previously uploaded files before uploading Images, and try uploading");
                } else if (error.message === "images_unstructured_error") {
                    console.error("images with unstructured_data not supported", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Images cannot be clubbed with unstructured files");
                    // setSnackbarMessage("Images cannot be clubbed with unstructured files");
                    // setOpenSnackbar(true);
                } else if (error.message === "images_structured_error") {
                    console.error("images with structured_data not supported", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Images cannot be clubbed with structured files");
                    // setSnackbarMessage("Images cannot be clubbed with structured files");
                    // setOpenSnackbar(true);
                } else if (error.message === "structured_unstructured_error") {
                    console.error("structured data with unstructured_data not supported", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("structured data cannot be clubbed with unstructured files");
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);

                    // setSnackbarMessage("structured data cannot be clubbed with unstructured files");
                    // setOpenSnackbar(true);
                } else if (error.message === "images_already_uploaded") {
                    console.error("images_already_uploaded", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Delete previously uploaded image files");
                    // setSnackbarMessage("Delete previously uploaded image files");
                    // setOpenSnackbar(true);
                } else {
                    console.error("else:", error);
                    setOpenFSnackbar(true);
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);
                    setSnackbarFMessage("Error uploading files.");
                    // setFileNames(prevFileNamesCopy);
                }
            }

            //
        } finally {
            setIsEmbeddingsLoading(false);
        }
    };

    const handleSubmitFile = async (event: React.FormEvent, uploadType?: boolean) => {
        event.preventDefault();
        console.log("inside handleSubmitFile");
        console.log("inside handleSubmitFile uploadType:", uploadType);
        console.log("inside handleSubmitFile isUploadClicked:", isUploadClicked);
        if (isUnstructured) {
            // console.log("is PROCEED CLICKED", isProceedClicked);
            // console.log("is PROCEED CLICKED", isProceedClickedImages);
            if (!isProceedClicked && !isProceedClickedImages) {
                console.log("User did not proceed, file processing will not start.");
                return; // Exit early if the user didn't click Continue
            }
        }

        // setShowProgressBar(true);
        setIsEmbeddingsLoading(true);
        setIsFileProcessed(true);

        try {
            if (files.length > 0) {
                const request: FileUpload = {
                    files: files,
                    // count: files.length,
                    uploadType: uploadType !== undefined ? uploadType : false
                };

                const response = await uploadApi(request);

                if (response.status === "success") {
                    setIsUploading(true);
                    setOpenAlert(true);
                    setEmbeddingsLoaded(true);
                    setFileNames([]);
                    setIsProceedClicked(false);
                    setIsProceedClickedImages(false);
                    // Assuming files is an array of File objects
                    const uploadedFileNames = files.map(file => file.name);

                    // Append the uploaded file names to the fileNames state
                    setuploaded_files(prevFileNames => [...prevFileNames, ...uploadedFileNames]);
                    closeFileUploadPanel();
                    setOpenSuccessAlert(true);
                }
            }
        } catch (error: unknown) {
            console.error("Error uploading files:", error);
            setFileNames([]);
            setIsProceedClicked(false);
            setIsProceedClickedImages(false);

            // Set state to show Snackbar with error message
            if (error instanceof Error) {
                if (error.message === "try_after_some_time") {
                    console.error("if try_after_some_time");
                    setSnackbarFMessage("Please Try after some time");
                    setOpenFSnackbar(true);
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableIUIcon(false);
                    setDisableExcelIcon(false);
                    setDisableSharePointIcon(false);
                    clearEmbeddings();
                } else if (error.message === "file_size_error") {
                    console.error("if file_size_error");
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    // setSnackbarFMessage(
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);
                    clearEmbeddings();
                } else if (error.message === "csv_excel_error") {
                    console.error("if csv_excel:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Upload Single Excel or CSV File, Cannot be uploaded with multiple files.");
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);
                } else if (error.message === "csv_excel_already_present_error") {
                    console.error("if csv_excel_already_present:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("CSV/Excel already uploaded, Clear it and try uploading");
                } else if (error.message === "unstructured_data_already_uploaded") {
                    console.error("if unstructured_data_already_uploaded:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Delete the previously uploaded files before uploading CSV/Excel, and try uploading");
                } else if (error.message === "unstructured_data_already_uploaded_image") {
                    console.error("if unstructured_data_already_uploaded:", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Delete the previously uploaded files before uploading Images, and try uploading");
                } else if (error.message === "images_unstructured_error") {
                    console.error("images with unstructured_data not supported", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Images cannot be clubbed with unstructured files");
                    // setSnackbarMessage("Images cannot be clubbed with unstructured files");
                    // setOpenSnackbar(true);
                } else if (error.message === "images_structured_error") {
                    console.error("images with structured_data not supported", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Images cannot be clubbed with structured files");
                    // setSnackbarMessage("Images cannot be clubbed with structured files");
                    // setOpenSnackbar(true);
                } else if (error.message === "structured_unstructured_error") {
                    console.error("structured data with unstructured_data not supported", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("structured data cannot be clubbed with unstructured files");
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);

                    // setSnackbarMessage("structured data cannot be clubbed with unstructured files");
                    // setOpenSnackbar(true);
                } else if (error.message === "images_already_uploaded") {
                    console.error("images_already_uploaded", error);
                    setSnackbarSeverity("warning");
                    setOpenFSnackbar(true);
                    setSnackbarFMessage("Delete previously uploaded image files");
                    // setSnackbarMessage("Delete previously uploaded image files");
                    // setOpenSnackbar(true);
                } else {
                    console.error("else:", error);
                    setOpenFSnackbar(true);
                    setDisableTUIcon(false);
                    setDisableFUIcon(false);
                    setDisableFUIconn(false);
                    setDisableExcelIcon(false);
                    setDisableIUIcon(false);
                    setDisableSharePointIcon(false);
                    setSnackbarFMessage("Error uploading files.");
                    // setFileNames(prevFileNamesCopy);
                }
            }

            //
        } finally {
            setIsEmbeddingsLoading(false);
        }
    };
    useEffect(() => {
        if (isProceedClicked) {
            console.log("Proceed clicked, processing files now.");
            const syntheticEvent = new Event("submit") as unknown as React.FormEvent;
            handleSubmitFile(syntheticEvent, false);
        }
    }, [isProceedClicked]);
    useEffect(() => {
        if (isProceedClickedImages) {
            console.log("Proceed clicked, processing files now.");
            const syntheticEvent = new Event("submit") as unknown as React.FormEvent;
            handleSubmitFile(syntheticEvent, true);
        }
    }, [isProceedClickedImages]);
    useEffect(() => {
        if (isSPProceedClicked) {
            console.log("isSPProceedClicked clicked, processing files now.");         
        }
    }, [isSPProceedClicked]);
    
    useEffect(() => {
        if (isSPProceedClickedImages) {
            console.log("isSPProceedClickedImages clicked, processing files with images now.");         
        }
    }, [isSPProceedClickedImages]);
    const handleUploadStart = () => {
        setIsCancelled(false); // Reset cancellation flag
        setIsProceedClicked(false); // Reset flag to show the popup again
    };

    const [sharepointloaded, setSharepointloaded] = useState(false);
    const [inputhsharepointurl,setinputsharepointurl] = useState(false);
    const [infoAlert, setInfoAlert] = useState(false);

    const handleAlertClose = () => {
        setOpenAlert(false);
        setWarning(false);
        setInfoAlert(false);
        setOpenDocClearAlert(false);
        setOpenDocClearAlertforchat(false);
        setOpenDocClearAlertForTranslate(false);
        setOpenGuidlinesAlert(false);
        setTranslateOpenAlert(false);
        setOpenSnackbar(false);
        setOpenSuccessAlert(false);
        setOpenFESnackbar(false);
        setSnackbarOpen(false);
        // handleSnackbarClose();
    };

    const [fileSelector, setFileSelector] = useState<string>("file");
    const [selectedTab, setSelectedTab] = useState<string>("");
    const handleTabChange = (label: string) => {
        setSelectedTab(label);
        setFileSelector(label);
    };

    const ifTranslate = () => {
        setPrevFileSelector(fileSelector);
        setFileSelector("translate"); // Set state to indicate translate upload
        openTranlateUploadPanel(); // Call function to open the translate upload panel
        
    };

    //Fileupload
    const fileuploadelement = () => {
        return (
            <div className={styles.upload} style={{ fontSize: "30px", marginLeft: "4px" }}>
                <UploadDocumentButton
                    className={!isAnswerCompleted && !disableFUIcon ? styles.commandButton : styles.commandButtonDisabled}
                    //className={!isAnswerCompleted ? styles.commandButton : styles.commandButtonDisabled}
                    onClick={openFileUploadPanel}
                />
                <FileUploadModal
                    open={fileUploadPanelOpen}
                    embeddingsLoaded={embeddingsLoaded}
                    isEmbeddingsLoading={isEmbeddingsLoading}
                    isFileProcessed={isFileProcessed}
                    isUploading={isUploading}
                    isUploadClicked={isUploadClicked}
                    setIsUploadClicked={setIsUploadClicked}
                    setIsCancelled={setIsCancelled}
                    isCancelled={isCancelled}
                    setIsUploadEnabled={setIsUploadEnabled}
                    isUploadEnabled={isUploadEnabled}
                    isProceedClicked={isProceedClicked}
                    setIsProceedClicked={setIsProceedClicked}
                    setIsProceedClickedImages={setIsProceedClickedImages}
                    isProceedClickedImages={isProceedClickedImages}
                    isSPProceedClicked={isSPProceedClicked}
                    setIsSPProceedClicked={setIsSPProceedClicked}
                    isSPProceedClickedImages={isSPProceedClickedImages}
                    setIsSPProceedClickedImages={setIsSPProceedClickedImages}
                    handleUploadStart={handleUploadStart}
                    setIsImageAlertProcessed={setIsImageAlertProcessed}
                    activePopUp={activePopUp}
                    setActivePopUp={setActivePopUp}
                    fileNames={fileNames}
                    openAlert={openAlert}
                    translateOpenAlert={translateOpenAlert}
                    openWarning={openWarning}
                    infoAlert={infoAlert}
                    openDocClearAlert={openDocClearAlert}
                    handleCloseModal={closeFileUploadPanel}
                    handleFileUpload={handleFileUpload}
                    handleSubmitFile={handleSubmitFile}
                    handleSubmitFileforCSV_Excel_and_Images={handleSubmitFileforCSV_Excel_and_Images}
                    handleAlertClose={handleAlertClose}
                    deleteEmbeddings={deleteEmbeddings}
                    openSnackbar={openSnackbar}
                    openFSnackbar={openFSnackbar}
                    snackbarMessage={snackbarMessage}
                    snackbarFMessage={snackbarFMessage}
                    setOpenFSnackbar={setOpenFSnackbar}
                    setSnackbarMessage={setSnackbarMessage}
                    setOpenSnackbar={setOpenSnackbar}
                    handleSnackbarClose={handleSnackbarClose}
                    translateEnabled={translateEnabled}
                    files={files}
                    handleTranslateRequest={handleTranslateRequest}
                    // translatedURL={translatedURL}
                    targetBlobClient={targetBlobClient}
                    connString={connString}
                    targetContainer={targetContainer}
                    // translatedFolder={translatedFolder}
                    isTranslating={isTranslating}
                    // translatedFileName={translatedFileName}
                    fileSelector={fileSelector}
                    onTabChange={handleTabChange}
                    disableFUIcon={disableFUIcon}
                    disableFUIconn={disableFUIconn}
                    disableIUIcon={disableIUIcon}
                    disableExcelIcon={disableExcelIcon}
                    disableSharePointIcon={disableSharePointIcon}
                    imageAlert={imageAlert}
                    sharepointloaded={sharepointloaded}
                    setSharepointloaded={setSharepointloaded}
                    inputhsharepointurl={inputhsharepointurl}
                    setinputhsharepointurl={setinputsharepointurl}
                    deleteEmbeddingsforcitaions={deleteEmbeddingsforcitaions}
                    fileUploadValidity={fileUploadValidity}
                    openFESnackbar={openFESnackbar}
                    FEsnackbarMessage={FESnackbarMessage}
                    isImageAlertProcessed={isImageAlertProcessed}
                    // setIsImageAlertProcessed={setIsImageAlertProcessed}
                    sharepointFilesLoaded={sharepointFilesLoaded}
                    setSharepointFilesLoaded={setSharepointFilesLoaded}
                />
            </div>
        );
    };

    //Translate Fileupload
    const translatefileuploadelement = () => {
        return (
            <div className={styles.upload} style={{ fontSize: "30px", marginLeft: "4px" }}>
                <UploadTranslateButton
                    className={!isAnswerCompleted && !disableTUIcon ? styles.commandButton : styles.commandButtonDisabled}
                    onClick={ifTranslate}
                />
                <FileTranslateModal
                    open={fileTranslatePanelOpen}
                    embeddingsLoaded={embeddingsLoaded}
                    isEmbeddingsLoading={isEmbeddingsLoading}
                    fileNames={fileNames}
                    openAlert={openAlert}
                    translateOpenAlert={translateOpenAlert}
                    openWarning={openWarning}
                    infoAlert={infoAlert}
                    openDocClearAlert={openDocClearAlert}
                    openDocClearAlertForTranslate={openDocClearAlertForTranslate}
                    handleCloseModal={closeFileUploadPanel}
                    handleFileUpload={handleFileUpload}
                    handleSubmitFile={handleSubmitFile}
                    handleAlertClose={handleAlertClose}
                    deleteEmbeddings={deleteEmbeddings}
                    deleteTranslate={deleteTranslate}
                    openSnackbar={openSnackbar}
                    // openFSnackbar={openFSnackbar}
                    snackbarMessage={snackbarMessage}
                    // snackbarFMessage={snackbarFMessage}
                    handleSnackbarClose={handleSnackbarClose}
                    translateEnabled={translateEnabled}
                    files={files}
                    handleTranslateRequest={handleTranslateRequest}
                    translatedURL={translatedURL}
                    targetBlobClient={targetBlobClient}
                    connString={connString}
                    targetContainer={targetContainer}
                    translatedFolder={translatedFolder}
                    isTranslating={isTranslating}
                    translatedFileName={translatedFileName}
                    fileSelector={fileSelector}
                    setOpenSnackbar={setOpenSnackbar}
                    setSnackbarMessage={setSnackbarMessage}
                    clearEmbeddings={clearEmbeddings}
                />
            </div>
        );
    };

    const fileUploadValidity = () => {
        setOpenFESnackbar(true); // Show Snackbar when fileUploadValidity is true
        setFESnackbarMessage(
            "You have selected some file(s) that are not supported for this feature. On continue, only valid files will be processed.Supported File Formats: (PDF, TXT, DOCX, PPTX)"
        );
    };
    const [openFESnackbar, setOpenFESnackbar] = useState<boolean>(false);
    const [FESnackbarMessage, setFESnackbarMessage] = useState<string>("");
    const [fileTotalSize, setFileTotalSize] = useState<number>(0);
    const handleFileUpload = (uploadedFiles: File[]) => {
        //initialize
        setFiles([]);
        setFileNames([]);
        let validFiles: File[] = [];
        let validFileNames: string[] = [];
        const allowedFileExtensions = /(\.pdf|\.PDF|\.txt|\.TXT|\.pptx|\.PPTX|\.docx|\.DOCX)$/i;
        const allowedExcelExtensions = /(\.csv|\.CSV|\.xlsx|\.XLSX)$/i;
        const allowedImgExtensions = /(\.jpg|\.JPG|\.png|\.PNG|\.jpeg|\.JPEG|\.bmp|\.BMP|\.webp|\.WEBP|\.tiff|\.TIFF|\.tif|\.TIF|\.gif|\.GIF)$/i;
        let totalSize = 0;
        const TranslateallowedExtensions = /(\.pdf|\.txt|\.pptx|\.docx|\.csv|\.CSV|\.xlsx|\.XLSX)$/i;

        uploadedFiles.forEach(file => {
            // Validate file type based on the fileSelector
            let isValid = false;
            if (fileSelector === "file" && allowedFileExtensions.exec(file.name)) {
                isValid = true;
                setIsUnstructured(true);
            } else if (fileSelector === "translate" && TranslateallowedExtensions.exec(file.name)) {
                isValid = true;
            } else if (fileSelector === "excel" && allowedExcelExtensions.exec(file.name)) {
                isValid = true;
            } else if (fileSelector === "image" && allowedImgExtensions.exec(file.name)) {
                isValid = true;
            }

            if (!isValid) {
                fileUploadValidity();
                validFiles = [];
                validFileNames = [];
                return;
            }

            // Add valid file to the arrays
            validFiles.push(file);
            validFileNames.push(file.name);

            // Update the total size for valid files
            totalSize += file.size;

            // Update state
            setFiles(prevFiles => [...prevFiles, file]);
            setFileNames(prevFileNames => [...prevFileNames, file.name]);
        });
        setFileTotalSize(totalSize);
        const fileSizeExceeded = totalSize > 0.000001 * 1024 * 1024;

        setFileSizeExceeded({
            fileSizeExceeded,

            totalSize
        });

        if (uploadedFiles.length === 1) {
            if (TranslateallowedExtensions.exec(uploadedFiles[0].name) && fileSelector === "translate") {
                setTranslateEnabled(true);
            } else if (fileSelector === "file" || fileSelector === "excel" || fileSelector === "image") {
                setTranslateEnabled(false);
            }
        }

        if (validFiles.length > 0) {
            // const firstFile = validFiles[1];
            let firstFile = validFiles[0];

            // Iterate through the valid files to find the largest
            validFiles.forEach(file => {
                if (file.size > firstFile.size) {
                    firstFile = file;
                }
            });

            if (allowedFileExtensions.exec(firstFile.name) && fileSelector === "file") {
                setDisableIUIcon(true);
                setDisableFUIcon(false);
                setDisableTUIcon(true);
                setDisableExcelIcon(true);
                setDisableSharePointIcon(true);
                detectImageInFile(firstFile);
                // setTranslateEnabled(false);
                return;
            }
            if (TranslateallowedExtensions.exec(firstFile.name) && fileSelector === "translate") {
                setDisableIUIcon(true);
                // console.log("Line 801 Chat.tsx");
                setDisableFUIcon(true);
                setDisableExcelIcon(true);
                setDisableTUIcon(false);
                setDisableSharePointIcon(true);
                detectImageInFile(firstFile);
                return;
            }
            if (allowedImgExtensions.exec(firstFile.name)) {
                setDisableIUIcon(false);
                setDisableFUIcon(false);
                setDisableTUIcon(true);
                setDisableExcelIcon(true);
                setDisableSharePointIcon(true);
                setDisableFUIconn(true);
                // setTranslateEnabled(false);
                return;
            }
            if (allowedExcelExtensions.exec(firstFile.name)) {
                setDisableIUIcon(true);
                setDisableFUIcon(false);
                setDisableTUIcon(true);
                setDisableExcelIcon(false);
                setDisableSharePointIcon(true);
                setDisableFUIconn(true);
                // setTranslateEnabled(false);
                return;
            }
        }
        if (sharepointloaded) {
            setDisableIUIcon(true);
            setDisableFUIcon(true);
            setDisableTUIcon(true);
            setDisableExcelIcon(true);
            setDisableSharePointIcon(false);
            // setTranslateEnabled(false);
            return;
        }
        console.log("disableIUIcon", disableIUIcon);
        console.log("disableFUIcon", disableFUIcon);
        console.log("disableTUIcon", disableTUIcon);
        console.log("disableExcelIcon", disableExcelIcon);
        console.log("disableSharePointIcon", disableSharePointIcon);
    };
    const [imageAlert, setImageAlert] = useState<{ isActive: boolean; imageCount: number }>({
        isActive: false,
        imageCount: 0
    });
    const [activePopUp, setActivePopUp] = useState<string | null>("");
    const [isImageAlertProcessed, setIsImageAlertProcessed] = useState<boolean>(false);
    const detectImageInFile = (file: File) => {
        const fileReader = new FileReader();

        fileReader.onload = async () => {
            try {
                const result = await fileImageDetection(file);

                if (result.images.length <= 0) {
                    // console.log("No images found in the file.");
                    setImageAlert({ isActive: false, imageCount: 0 });
                    setActivePopUp("noImages");
                } else {
                    // // console.log(`Found ${result.images.length} images in the file!`);
                    setImageAlert({ isActive: true, imageCount: result.images.length });
                    setActivePopUp("images");
                }
            } catch (error) {
                console.error("Error detecting images:", error);
                setImageAlert({ isActive: false, imageCount: 0 }); // Handle error gracefully
            } finally {
                // Set the isImageAlertProcessed flag to true after processing is complete
                setIsImageAlertProcessed(true);
            }
        };

        fileReader.readAsArrayBuffer(file);
    };
    useEffect(() => {}, [imageAlert]);

    //Prompt
    const closeConfigPanel = () => {
        setIsConfigPanelOpen(false);
        if (promptHasChanged.current == true) {
            clearChat();
            promptHasChanged.current = false;
        }
    };

    const clearPrompt = () => {
        setPromptTemplate("");
        clearChat();
    };
    const deleteTranslate = () => {
        setOpenDocClearAlertForTranslate(true);
        setTranslatedURL({});
        setActivePopUp(null);
        embeddingInit();
        // setOpenDocClearAlert(true);
        // clearEmbeddings();
        setTranslatedFolderName("");
        setTranslateEnabled(false);
        setuploaded_files([]);
        // setFileSelector("label");
        handleTabChange;
        setSelectedLanguage("");
        setDisableIUIcon(false);
        setDisableTUIcon(false);
        setDisableFUIcon(false);
        setDisableFUIconn(false);
        // setTranslatedURL({});
        // setIsCitationPresent(false);
        setDisableExcelIcon(false);
        setDisableSharePointIcon(false);
        setImageAlert({ isActive: false, imageCount: 0 });
        setIsImageAlertProcessed(false);
        setIsUploadClicked(false);
    };
    const deleteEmbeddings = () => {
        setActivePopUp(null);
        embeddingInit();
        setOpenDocClearAlert(true);
        clearEmbeddings();
        setTranslatedFolderName("");
        setTranslateEnabled(false);
        setSelectedLanguage("");
        setDisableIUIcon(false);
        setDisableTUIcon(false);
        setDisableFUIcon(false);
        setDisableFUIconn(false);
        // setTranslatedURL({});
        // setIsCitationPresent(false);
        setDisableExcelIcon(false);
        setDisableSharePointIcon(false);
        setImageAlert({ isActive: false, imageCount: 0 });
        setIsImageAlertProcessed(false);
        setIsUploadClicked(false);
    };
    const deleteEmbeddingsforchat = () => {
        embeddingInit();
        setOpenDocClearAlertforchat(true);
        clearEmbeddings();
        setOpenGuidlinesAlert(false);
        setDisableTUIcon(false);
        setDisableIUIcon(false);
        setDisableFUIcon(false);
        setTranslatedFolderName("");
        setTranslateEnabled(false);
        setSelectedLanguage("");
        setDisableIUIcon(false);
        setDisableTUIcon(false);
        setDisableFUIcon(false);
        setDisableFUIconn(false);
        setTranslatedURL({});
        // setIsCitationPresent(false);
        setDisableExcelIcon(false);
        setSharepointloaded(false);
        setSharepointFilesLoaded(false);
        setDisableSharePointIcon(false);
    };
    const deleteEmbeddingsforcitaions = () => {
        setActivePopUp(null);
        setIsUploadClicked(false);
        embeddingInit();
        setOpenDocClearAlertforchat(true);
        clearEmbeddings1();
        clearEmbeddings();
        setOpenGuidlinesAlert(false);
        setDisableTUIcon(false);
        setDisableIUIcon(false);
        setDisableFUIcon(false);
        setDisableFUIconn(false);
        setTranslatedFolderName("");
        setTranslateEnabled(false);
        setSelectedLanguage("");
        setTranslatedURL({});
        // setIsCitationPresent(false);
        setDisableExcelIcon(false);
        setDisableSharePointIcon(false);
        setImageAlert({ isActive: false, imageCount: 0 });
        setIsImageAlertProcessed(false);
        setIsUploadClicked(false);
        setinputsharepointurl(false);
        setSharepointloaded(false);
        setSharepointFilesLoaded(false); // Reset the state when SharePoint is not loaded
    };

    const embeddingInit = () => {
        setFiles([]);
        setFileNames([]);
        setEmbeddingsLoaded(false);
        setSharepointloaded(false);
        setSharepointFilesLoaded(false);

    };
    const clearEmbeddings1 = () => {
        // Call the API to delete the folder on the backend
        setuploaded_files([]);
        fetch("/delete-embeddings", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
                // Include any other headers your backend requires, such as authentication tokens
            }
            // If you need to send data along with the delete request, include it here.
            // body: JSON.stringify({ folderName: 'folder_to_delete' }),
        })
            .then(response => {
                // Check if the response status code is not in the range 200-299
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text || "Server responded with an error!");
                    });
                }
                return response.json();
            })
            .then(data => {
                //
                // Clear state only after the folder has been successfully deleted
            })
            .catch(error => {
                // console.error("Error deleting the folder:", error.message);
                // Handle the error state here if needed
            });

        // Open the alert to notify the user
    };

    const clearEmbeddings = () => {
        // Call the API to delete the folder on the backend
        setuploaded_files([]);
        fetch("/delete-folder", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
                // Include any other headers your backend requires, such as authentication tokens
            }
            // If you need to send data along with the delete request, include it here.
            // body: JSON.stringify({ folderName: 'folder_to_delete' }),
        })
            .then(response => {
                // Check if the response status code is not in the range 200-299
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text || "Server responded with an error!");
                    });
                }
                return response.json();
            })
            .then(data => {
                //
                // Clear state only after the folder has been successfully deleted
            })
            .catch(error => {
                // console.error("Error deleting the folder:", error.message);
                // Handle the error state here if needed
            });

        // Open the alert to notify the user
    };

    async function stopGeneratingAnswer() {
        setStopGenerating(true);
    }

    let stop = false;
    const [prevEmbeddingsLoaded, setPrevembeddingsLoaded] = useState(false);
    const [historyDoc, setHistoryDoc] = useState<ChatTurn[]>([]); // History for document-based chat
    const [historyGen, setHistoryGen] = useState<ChatTurn[]>([]); // History for generic chat
    const [prevSPLoaded, setPrevSPLoaded] = useState(false);
    //API CALL
    const makeApiRequest = async (question: string, language?: string) => {
        lastQuestionRef.current = question;
        error && setError(undefined);
        setIsLoading(true);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
    
        try {
            let history: ChatTurn[];
            if (embeddingsLoaded) {
                history = chatHistoryForRequest.map(a => ({ user: a[0], bot: a[1].answer }));
            } else if (sharepointFilesLoaded) {
                history = spHistoryForRequest.map(a => ({ user: a[0], bot: a[1].answer }));
            } else {
                history = genHistoryForRequest.map(a => ({ user: a[0], bot: a[1].answer }));
            }

            if (prevEmbeddingsLoaded !== embeddingsLoaded) {
                console.log("Mode change detected. Resetting chat histories.");
                console.log("Previous embeddingsLoaded:", prevEmbeddingsLoaded);
                console.log("Current embeddingsLoaded:", embeddingsLoaded);
                setPrevembeddingsLoaded(embeddingsLoaded);
                // setAnswers([]);
                setChatHistoryForRequest([]);
                setGenHistoryForRequest([]);
                history = [];
            } else if (prevSPLoaded !== sharepointFilesLoaded) {
                console.log("Mode change detected for SP. Resetting chat histories.");
                console.log("Previous prevSPLoaded:", prevSPLoaded);
                console.log("Current sharepointloaded:", sharepointFilesLoaded);
                setPrevSPLoaded(sharepointFilesLoaded);
                // setAnswers([]);
                setSpHistoryForRequest([]);
                setGenHistoryForRequest([]);
                history = [];
    
            }
            else {
                console.log("inside else ,No mode change.");
                console.log("PrevembeddingsLoaded:", prevEmbeddingsLoaded);
                console.log("embeddingsLoaded:", embeddingsLoaded);
                setPrevembeddingsLoaded(embeddingsLoaded);
                setPrevSPLoaded(sharepointFilesLoaded);
                console.log("Previous prevSPLoaded:", prevSPLoaded);
                console.log("Current sharepointloaded:", sharepointloaded);
            }

            
            const request: ChatRequest = {
                history: [...history, { user: question, bot: undefined }],
                approach: readAloudCalled
                    ? Approaches.ReadAloud
                    : language
                    ? Approaches.Translate
                    : embeddingsLoaded
                    ? Approaches.DocumentQNA
                    : sharepointFilesLoaded
                    ? Approaches.DocumentQNA
                    : Approaches.General,
                shouldStream: shouldStream,
                language: language,
                overrides: {
                    modelType: modelApproach.current,
                    promptTemplate: promptTemplate.length === 0 ? undefined : promptTemplate,
                    suggestFollowupQuestions: useSuggestFollowupQuestions,
                    temperature: sliderValue / 10
                }
            };
            setReadAloudCalled(false);
            setAnswerCompletion(true);
    
            // --- Timeout logic: create a race between the API call and a 10-second timeout ---
            const chatApiPromise = chatApi(request, language);
            const timeoutPromise = new Promise<Response>((_resolve, reject) => {
                setTimeout(() => {
                    reject(new Error("Process timedOut"));
                }, config.timeout); // 180 seconds
            });
            // The first promise to resolve/reject will win.
            const response = await Promise.race([chatApiPromise, timeoutPromise]);
    
            if (!response.body) {
                throw Error("No response body");
            }
    
            let answer: string = "";
            let askResponse: AskResponse = {} as AskResponse;
            let pagelinks: string[] = []; // To store page URLs
    
            if (shouldStream) {
                // Streaming response handling
                for await (const event of readNDJSONStream(response.body)) {
                    // If user stops generation mid-way
                    if (document.getElementById("stop")?.title == "Continue") {
                        setStopGenerating(false);
                        break;
                    }
    
                    if (event["data_points"]) {
                        askResponse = event;
                    } else if (event["choices"] && event["choices"][0]["delta"]["content"]) {
                        answer += event["choices"][0]["delta"]["content"];
                        let latestResponse: AskResponse = { ...askResponse, answer: answer, page_urls_list: pagelinks };
                        setIsLoading(false);
                        setAnswers([...answers, [question, latestResponse]]);
                        if (embeddingsLoaded) {
                            setChatHistoryForRequest([...chatHistoryForRequest, [question, latestResponse]]);
                        } else if(sharepointFilesLoaded){
                            setSpHistoryForRequest([...spHistoryForRequest, [question, latestResponse]]);
                        }
                        else {
                            setGenHistoryForRequest([...genHistoryForRequest, [question, latestResponse]]);
                        }
                    } else if (event["error"]) {
                        setSnackbarSeverity("warning");
                        setSnackbarOpen(true);
                        setSnackbarMessage(event["error"]);
                    }
                    if (event["page_urls_list"]) {
                        pagelinks = event["page_urls_list"]; // Store page URLs
                        setPageUrls(pagelinks);
                    }
                }
    
                setAnswerCompletion(false);
                setContentValue("");
                setContent(false);
            } else {
                // Non-streaming response handling
                const parsedResponse: AskResponse = await response.json();
    
                if (response.status > 299 || !response.ok) {
                    throw Error(parsedResponse.error || "Unknown error");
                }
                if (response.status === 500) {
                    setSnackbarMessage("Please refresh the page");
                }
                // Include page URLs in the parsed response
                const parsedResponseWithPageUrls = { ...parsedResponse, page_urls_list: pageUrls };
    
                setAnswers([...answers, [question, parsedResponseWithPageUrls]]);
            }
        } catch (e: any) {
            // Check if error is due to timeout
            if (e.message === "Process timedOut") {
                // Create a response object with the timeout message formatted like a normal response
                const timeoutResponse: AskResponse = {
                    session_id: "",         // Default or placeholder value
                    status: "timeout",      // Custom status indicating the timeout condition
                    thoughts: "",           // Provide any default thoughts if needed
                    data_points: [],        // Adjust type accordingly: could be an empty object, array or other default structure
                    answer: "<b>System Error:</b> The system did not respond in time. Please try again shortly or contact support if the issue persists",
                    page_urls_list: []
                };
                setAnswerCompletion(false)
                setStopGenerating(true);
                setAnswers([...answers, [question, timeoutResponse]]);
                setIsLoading(false);
            } else {
                setError(e);
                setSnackbarMessage("Couldn't answer. Please refresh the page");
            }
        } finally {
            setIsLoading(false);
            
        }
    };
    

    //Clear Chat
    const clearChat = () => {
        lastQuestionRef.current = "";
        error && setError(undefined);
        setActiveCitation(undefined);
        setActiveAnalysisPanelTab(undefined);
        setAnswers([]);
        setChatHistoryForRequest([]);
        setGenHistoryForRequest([]);
        setSpHistoryForRequest([]);
        // setDisableFUIcon(false);
        // setDisableFUIcon(false); //FUIcon stands for File Upload Icon
        // setDisableFUIconn(false);
        // setDisableFUIconn(embeddingsLoaded && isUnstructured && disableExcelIcon && disableIUIcon ? false : true); //FUIconn stands for File Upload option within file upload modal
        // setDisableIUIcon(false);
        // setDisableIUIcon(embeddingsLoaded ? true : false); //IUIcon stands for Image Upload Icon within file upload modal
        setDisableTUIcon(embeddingsLoaded || sharepointloaded ? true : false); //TUIcon stands for Translate Icon
        // setDisableTUIcon(false);
        // setDisableExcelIcon(false);
        // console.log(embeddingsLoaded, "embeddingsLoaded", disableFUIcon, "disableFUIcon");
        // setDisableExcelIcon((embeddingsLoaded && !disableFUIconn) || !disableIUIcon ? true : false);
        // setDisableSharePointIcon(embeddingsLoaded ? true : false);
        // setDisableSharePointIcon(false);
        setIsImageAlertProcessed(false);
        setImageAlert({ isActive: false, imageCount: 0 });
    };

    useEffect(() => {
        // console.log("Mode change detected. Resetting chat histories.");
        // setAnswers([]);
        setChatHistoryForRequest([]);
        setSpHistoryForRequest([]);
    }, [embeddingsLoaded, sharepointFilesLoaded]);

    // useEffect(()=>{

    //     if(inputhsharepointurl)
    //     {setDisableFUIconn(true);
    //         setDisableIUIcon(true);
    //         setDisableExcelIcon(true);
    //     }
    //     else if (!inputhsharepointurl)
    //     {
    //         setDisableFUIconn(false);
    //         setDisableIUIcon(false);
    //         setDisableExcelIcon(false);
    //     }

        
        
    // })

    useEffect(() => { 
        if (sharepointloaded) {
            setDisableIUIcon(true);
            setDisableFUIconn(true);
            setDisableTUIcon(true);
            setDisableExcelIcon(true);
            setDisableSharePointIcon(false);
    }
    else {
        setDisableIUIcon(false);
        setDisableFUIconn(false);
        setDisableTUIcon(false);
        setDisableExcelIcon(false);
        setDisableSharePointIcon(false);
    }
    }, [sharepointloaded]);

    useEffect(() => chatMessageStreamEnd.current?.scrollIntoView({ behavior: "smooth" }), [isLoading]);

    const onUseSuggestFollowupQuestionsChange = (_ev?: React.FormEvent<HTMLElement | HTMLInputElement>, checked?: boolean) => {
        setUseSuggestFollowupQuestions(!!checked);
    };

    const onToggleTab = (tab: AnalysisPanelTabs, index: number) => {
        if (activeAnalysisPanelTab === tab && selectedAnswer === index) {
            setActiveAnalysisPanelTab(undefined);
        } else {
            setActiveAnalysisPanelTab(tab);
        }

        setSelectedAnswer(index);
    };

    const handleSnackbarClose = (event?: React.SyntheticEvent, reason?: string) => {
        if (reason === "clickaway") {
            return;
        }
        setWarning(false);
        setOpenSnackbar(false);
        setDisableFUIcon(false);
        setDisableFUIconn(false);
        setDisableIUIcon(false);
        setDisableTUIcon(false);
        setDisableExcelIcon(false);
        setDisableSharePointIcon(false);
        setSnackbarOpen(false);
    };
    //check for permitted users, Access :
    const [hasAccess, setHasAccess] = useState<Access>({ hasModAccess: false });

    const makeAccessApiRequest = async () => {
        try {
            const response = await accessApi();
            //
            setHasAccess(response);
        } catch (e) {}
    };

    useEffect(() => {
        // This function will be called only once during the initial render

        try {
            embeddingInit();
            clearEmbeddings();
        } catch (e) {}
        makeAccessApiRequest();

        // Cleanup function (optional)
        return () => {};
    }, []);

    const handleModelApproachChange = (_ev?: React.MouseEvent<HTMLElement>, newAlignment?: string) => {
        setModelApproachState(newAlignment || "GPT3.5");
        modelApproach.current = newAlignment || "GPT3.5";

        clearChat();
    };

    const handleClick = () => {
        // Open another link
        window.open(
            // "https://sankyopharma.sharepoint.com/sites/DSTeam_CoE_AIML/Shared%20Documents/Forms/AllItems.aspx?isAscending=true&OR=Teams%2DHL&CT=1710835373668&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yNDAyMDExOTMwNyIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D&sortField=LinkFilename&id=%2Fsites%2FDSTeam%5FCoE%5FAIML%2FShared%20Documents%2FGeneral%2FOpen%20AI%20Enablement%2F00%20Documents%20Approved%20by%20Legal%2C%20Compliance%2C%20Comms%2FChatDSI%20Usage%20Guidelines%5F3%2D26%2D24%2Epdf&viewid=b54b96d0%2Dd392%2D4730%2Db9a0%2D5ead22297885&parent=%2Fsites%2FDSTeam%5FCoE%5FAIML%2FShared%20Documents%2FGeneral%2FOpen%20AI%20Enablement%2F00%20Documents%20Approved%20by%20Legal%2C%20Compliance%2C%20Comms",
            // "_blank"
            "https://dsg2ic.sharepoint.com/teams/DSTeam_CoE_AIML/Shared%20Documents/Forms/AllItems.aspx?id=%2Fteams%2FDSTeam%5FCoE%5FAIML%2FShared%20Documents%2FGeneral%2FOpen%20AI%20Enablement%2F001%20Landing%20Page%20Content%2FReference%20Materials%2FUsage%20Guidelines%2FChatDSI%20Usage%20Guidelines%5FProduction%20Version%2Epdf&parent=%2Fteams%2FDSTeam%5FCoE%5FAIML%2FShared%20Documents%2FGeneral%2FOpen%20AI%20Enablement%2F001%20Landing%20Page%20Content%2FReference%20Materials%2FUsage%20Guidelines&p=true&ga=1",
            "_blank"
        );
    };

    // Creativity button
    const [selectedButton, setSelectedButton] = useState("More Balanced");
    const handleTranslate = async (question: string, language: string) => {
        try {
            await makeApiRequest(question, language);
            // Pass language to `makeApiRequest`
        } catch (error) {
            console.error("Translation or API call failed:", error);
            throw new Error("Translation or API call failed");
        }
    };

    const languageToVoiceMap: { [key: string]: string } = {
        eng: "en-US-AvaMultilingualNeural",
        cmn: "wuu-CN-XiaotongNeural",
        ces: "cs-CZ-VlastaNeural",
        dan: "da-DK-ChristelNeural",
        nld: "nl-NL-FennaNeural",
        fra: "fr-FR-DeniseNeural",
        deu: "de-DE-KatjaNeural",
        mag: "hi-IN-SwaraNeural",
        ita: "it-IT-ElsaNeural",
        jpn: "ja-JP-NanamiNeural",
        kor: "ko-KR-SunHiNeural",
        rus: "ru-RU-SvetlanaNeural",
        spa: "es-ES-ElviraNeural"
        // spa: "es-ES-ElviraNeural",
        // fra: "fr-FR-DeniseNeural",
        // deu: "de-DE-KatjaNeural"

        // Add more language mappings as needed
    };

    const speechConfig = sdk.SpeechConfig.fromSubscription("9fd3c452d25d4848a54f9d466f5dcefc", "eastus");
    // const audioConfig = sdk.AudioConfig.fromDefaultMicrophoneInput();
    const audioConfig = sdk.AudioConfig.fromDefaultSpeakerOutput();

    const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);

    const handleReadAloud = async (question: string) => {
        lastQuestionRef.current = "Yes sir, how can I help you? I'm a test use case for reading aloud."; //English
        lastQuestionRef.current = "是的，先生，我能为您做点什么吗？我是一个大声朗读的测试用例。"; // Chinese
        lastQuestionRef.current = "Ano, pane, jak vám mohu pomoci? Jsem testovací případ použití pro čtení nahlas."; //Czech
        lastQuestionRef.current = "Ja sir, hvordan kan jeg hjælpe dig? Jeg er en testbrug til højtlæsning."; //Danish
        lastQuestionRef.current = "Ja meneer, hoe kan ik u helpen? Ik ben een testgebruiksvoorbeeld voor voorlezen."; // Dutch
        lastQuestionRef.current = "Oui monsieur, comment puis-je vous aider ? Je suis un cas d'utilisation de test pour la lecture à haute voix."; //French
        // lastQuestionRef.current = "Ja, Sir, wie kann ich Ihnen helfen? Ich bin ein Testanwendungsfall für das Vorlesen."; //German
        // lastQuestionRef.current = "हाँ सर, मैं आपकी कैसे मदद कर सकता हूँ? मैं ज़ोर से पढ़ने के लिए एक परीक्षण उपयोग मामला हूँ।"; //Hindi
        // lastQuestionRef.current = "Sì signore, come posso aiutarla? Sono un caso d'uso di prova per la lettura ad alta voce."; //Italian
        // lastQuestionRef.current = "はい、先生、どうしたらお手伝いできますか?私は音読のテストユースケースです。"; //Japanese
        // lastQuestionRef.current = "네, 무엇을 도와드릴까요? 나는 소리내어 읽기에 대한 테스트 사용 사례입니다."; //Korean
        // lastQuestionRef.current = "Да, сэр, чем я могу вам помочь? Я тестирую вариант использования чтения вслух."; //Russian
        // lastQuestionRef.current = "Si señor, ¿en qué puedo ayudarle? Soy un caso de uso de prueba para leer en voz alta."; //Spanish
        setReadAloudCalled(true);
    };
    useEffect(() => {
        if (readAloudCalled) {
            // makeApiRequest(lastQuestionRef.current);
            const detectedLang = franc(lastQuestionRef.current, { minLength: 3 });

            const voice = languageToVoiceMap[detectedLang] || "en-US-AriaNeural";
            speechConfig.speechSynthesisVoiceName = voice;

            synthesizer.speakTextAsync(
                lastQuestionRef.current,
                result => {},
                error => {}
            );
            setReadAloudCalled(false); // Reset after the call
        }
    }, [readAloudCalled]);

    const [selectedLanguage, setSelectedLanguage] = useState<string>("en"); // Initialize with a default language

    const handleLanguageSelect = (language: string) => {
        setSelectedLanguage(language); // Update the state with the selected language
    };

    const handleButtonClick = (buttonName: string) => {
        setSelectedButton(buttonName);
        // Set slider value based on button clicked
        switch (buttonName) {
            case "More Creative":
                setSliderValue(10);
                break;
            case "More Balanced":
                setSliderValue(5);
                break;
            case "More Precise":
                setSliderValue(1);
                break;
            default:
                break;
        }
    };

    // const [isNavbarExpanded, setIsNavbarExpanded] = useState(false);
    const [, setSelectedMessage] = useRecoilState(selectedMessageAtom);
    const [contentValue, setContentValue] = useState<string>("");
    const [isContent, setContent] = useState<boolean>(false);

    // // console.log(uploaded_files);
    const fileUploadedNames = (uploaded_files: string[], handleViewUploadedFiles: () => void): JSX.Element => {
        if (!uploaded_files || uploaded_files.length === 0) {
            return <span>No files uploaded.</span>;
        } else if (uploaded_files.length <= 3) {
            return <span>{uploaded_files.join(", ")}</span>; // If 3 or fewer files, join them into a readable string
        } else {
            // For more than 3 files, show first 3 and mention how many more files
            const previewFiles = uploaded_files.slice(0, 3).join(", ");
            return (
                <span>
                    {previewFiles}
                    <span onClick={handleViewUploadedFiles} className={styles.guidelines}>
                        {` and ${uploaded_files.length - 3} more files.`}
                    </span>
                </span>
            );
        }
    };
    const [responseMessage, setResponseMessage] = useState("");
    const handleViewUploadedFiles = () => {
        setResponseMessage(uploaded_files.join("\n"));
        setOpenSnackbar(true);
    };
    useEffect(() => {
        const handleResize = () => {
            setIsScreenSmall(window.innerWidth < 769);
        };
        window.addEventListener("resize", handleResize);
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    if (isSideBarOpen && isScreenSmall) {
        return null; // or you can return <div></div> or any placeholder content
    }

    return (
        <div className={` ${isSideBarOpen ? styles.shrunk : styles.container}`}>
            {" "}
            <div className={styles.chatRoot}>
                <div className={styles.chatContainer}>
                    {!lastQuestionRef.current ? (
                        <div className={styles.chatEmptyState}>
                            <p className={styles.disclaimerText} style={{ filter: isDarkTheme ? "brightness(20)" : "brightness(1)" }}>
                                ChatDSI is designed to engage in natural language conversations, answer questions, and assist with various tasks but currently
                                cannot access DSI repositories to obtain internally stored information nor can it access, retrieve, or utilize in its response
                                generation any information that became available after October 2023 due to the model's knowledge cutoff date (which may change
                                with subsequent upgrades). Since it is an AI-powered assistant, output should always be validated by a human prior to use.
                                Please follow the{" "}
                                <span onClick={handleClick} style={{ textDecoration: "underline", cursor: "pointer" }}>
                                    ChatDSI Usage Guidelines
                                </span>{" "}
                                at all times.
                            </p>
                            {/* <Query /> */}
                            <div className={styles.boxesContainerquerySuggestion}>
                                <div
                                    className={styles.boxquerySuggestion}
                                    onClick={() => setSelectedMessage("Show me an example of R code to run a Kaplan-Meier plot using a survival package.")}
                                >
                                    <p className={styles.querytitle}>Coding</p>
                                    “Show me an example of R code to run a Kaplan-Meier plot using a survival package.”
                                </div>
                                <div
                                    className={styles.hideboxquerySuggestion}
                                    onClick={() =>
                                        setSelectedMessage("Provide an easy-to-read summary of the following article that is no more than 750 words: ")
                                    }
                                >
                                    <p className={styles.querytitle}>Summarization</p>
                                    “Provide an easy-to-read summary of the following article that is no more than 750 words: ”
                                </div>
                                <div
                                    className={styles.boxquerySuggestion}
                                    onClick={() =>
                                        setSelectedMessage(
                                            "Please refine the conclusion of my research paper on the impact of artificial intelligence in drug discovery to make it clearer and emphasize the following findings:"
                                        )
                                    }
                                >
                                    <p className={styles.querytitle}>Writing Assistance</p>
                                    “Please refine the conclusion of my research paper on the impact of artificial intelligence in drug discovery to make it
                                    clearer and emphasize the following findings: ”
                                </div>
                                <div
                                    className={styles.boxquerySuggestion}
                                    onClick={() =>
                                        setSelectedMessage(
                                            "Explore the possibility of predicting individual health outcomes based on various factors (genetics, lifestyle, medical history). Develop a predictive model that tailors recommendations for personalized healthcare interventions."
                                        )
                                    }
                                >
                                    <p className={styles.querytitle}>Predictive Analysis</p>
                                    “Explore the possibility of predicting individual health outcomes based on various factors (genetics, lifestyle, medical
                                    history). Develop a predictive model that tailors recommendations for personalized healthcare interventions.”
                                </div>
                                <div
                                    className={styles.hideboxquerySuggestion}
                                    onClick={() => setSelectedMessage("In Excel (Office 365), how do I remove duplicate entries from a column of data? ")}
                                >
                                    <p className={styles.querytitle}>Tutoring</p>
                                    “In Excel (Office 365), how do I remove duplicate entries from a column of data?”
                                </div>
                                <div
                                    className={styles.hideboxquerySuggestion}
                                    onClick={() => setSelectedMessage("Create a job description for a Data Analyst to work in [open role] at Daiichi Sankyo.")}
                                >
                                    <p className={styles.querytitle}>Creation</p>
                                    "Create a job description for a Data Analyst to work in [open role] at Daiichi Sankyo.”
                                </div>
                            </div>
                            {/* <br />
                            <br />{" "}
                            <p className={styles.noticeText} style={{ marginTop: "15px", fontWeight: "bold" }}>
                                Please use your Daiichi Sankyo email ID
                                <span style={{ color: "red" }}> from Monday (2/17) </span>
                                onwards to login to ChatDSI.
                            </p> */}
                            <div className={styles.cylindricalBar}>
                                <div className={styles.responseStyle}>Select Response Style</div>
                                <div className={styles.buttonContainer}>
                                    <DefaultButton
                                        className={`${styles.temperatureButton} ${selectedButton === "More Creative" ? styles.clicked : ""}`}
                                        onClick={() => handleButtonClick("More Creative")}
                                    >
                                        More Creative
                                    </DefaultButton>
                                    <DefaultButton
                                        className={`${styles.temperatureButton} ${selectedButton === "More Balanced" ? styles.clicked : ""}`}
                                        onClick={() => handleButtonClick("More Balanced")}
                                    >
                                        More Balanced
                                    </DefaultButton>
                                    <DefaultButton
                                        className={`${styles.temperatureButton} ${selectedButton === "More Precise" ? styles.clicked : ""}`}
                                        onClick={() => handleButtonClick("More Precise")}
                                    >
                                        More Precise
                                    </DefaultButton>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className={styles.chatMessageStream}>
                            {answers.map((answer, index) => (
                                <div key={index}>
                                    <UserChatMessage message={answer[0]} />
                                    {/* {answers.length} and {index + 1} and {answer[0]} and {lastQuestionRef.current} */}
                                    <div className={styles.chatMessageGpt}>
                                        <Answer
                                            key={index}
                                            answer={answer[1]}
                                            onFollowupQuestionClicked={q => makeApiRequest(q)}
                                            showFollowupQuestions={useSuggestFollowupQuestions && answers.length - 1 === index}
                                            isAnswerCompleted={isAnswerCompleted && answers.length === index + 1 && answer[0] === lastQuestionRef.current}
                                            regenerateResponse={answers.length === index + 1 && answer[0] === lastQuestionRef.current}
                                            regenerateQuestion={answer[0]}
                                            // languageselected={language}
                                            onTranslate={handleTranslate}
                                            readAloudCalled={readAloudCalled}
                                            onRead={handleReadAloud}
                                            languageselected={""}
                                            onLanguageSelect={function (language: string): void {
                                                throw new Error("Function not implemented.");
                                            }}
                                            // isCitationPresent={isCitationPresent}
                                            // fileNames={uploaded_files[0]}
                                            pageUrls={answer[1].page_urls_list || []}
                                        />
                                    </div>
                                </div>
                            ))}

                            {isLoading && (
                                <>
                                    <UserChatMessage message={lastQuestionRef.current} />
                                    <div className={styles.chatMessageGptMinWidth}>
                                        <AnswerLoading />
                                    </div>
                                </>
                            )}
                            {error ? (
                                <>
                                    <UserChatMessage message={lastQuestionRef.current} />
                                    <div className={styles.chatMessageGptMinWidth}>
                                        <AnswerError error={error.toString()} onRetry={() => makeApiRequest(lastQuestionRef.current)} />
                                    </div>
                                </>
                            ) : null}
                            <div ref={chatMessageStreamEnd} />
                        </div>
                    )}
                    {/* Chat Input */}
                    <div className={styles.chatInput}>
                        {/* Stop Generate  */}
                        <div>
                            {isAnswerCompleted && !isLoading && (
                                <button
                                    className={styles.stopButtonContent}
                                    onClick={() => {
                                        stopGeneratingAnswer();
                                    }}
                                >
                                    <div id="stop" className={styles.stopButton} title={`${stopGenerating ? "Continue" : "Stop Generate Response"}`}>
                                        <FaStop style={{ fontSize: "11px" }} />
                                        {/* {" "} */}
                                    </div>
                                    <div className={styles.stopText1} style={{ color: isDarkTheme ? "white" : "black" }}>
                                        Stop Responding
                                    </div>
                                </button>
                            )}
                            {/* QuestionInput/ Input Bar / Chat Input*/}
                            <QuestionInput
                                fileuploadelement={fileuploadelement()}
                                // imageuploadelement={imageuploadelement()}
                                translatefileuploadelement={translatefileuploadelement()}
                                clearchat={clearChat}
                                isLoading={isLoading}
                                lastQuestionRef={lastQuestionRef}
                                clearOnSend
                                disabled={isAnswerCompleted}
                                onSend={question => makeApiRequest(question)}
                                placeholder="Ask me a question. (Shift + Enter for new line)"
                                // onKeyDown={handleKeyDown}
                                value={isContent ? contentValue : ""}
                                isContent={isContent}
                                showTooltip={showTooltip}
                            />
                        </div>
                    </div>
                    <div className={styles.chatInput}>
                        {sharepointFilesLoaded === true ? ( // Condition when sharepointFilesLoaded is true
                            <div
                                className={styles.responseContainer}
                                style={{ display: "flex", justifyContent: "center", alignItems: "center", width: "100%" }}
                            >
                                {/* Flexbox container to align items in a row */}
                                <Text
                                    className={styles.customPromptMessageResponse}
                                    style={{
                                        color: isDarkTheme ? "white" : "black",
                                        marginRight: "10px", // Space between message and button
                                        fontSize: "12px", // Optional: adjust font size for better readability
                                        display: "inline-block"
                                    }}
                                >
                                    {`The responses are being fetched from the SharePoint files`}
                                </Text>

                                {/* Clear Document button */}
                                <button
                                    className={styles.clearPrompt}
                                    onClick={deleteEmbeddingsforcitaions}
                                    style={{ color: isDarkTheme ? "white" : "", cursor: "pointer", display: "inline-block" }}
                                >
                                    <Text>
                                        <u>
                                            <i>Clear Document</i>
                                        </u>
                                    </Text>
                                </button>
                            </div>
                        ) : embeddingsLoaded === false ? (
                            // {embeddingsLoaded == false ? (
                            <>
                                <Text className={styles.customPromptMessageResponse} style={{ color: isDarkTheme ? "white" : "black" }}>
                                    {
                                        // isLoading &&
                                        isAnswerCompleted && (
                                            <>
                                                {" "}
                                                The response is being generated <span className={styles.loadingdots} />{" "}
                                            </>
                                        )
                                    }
                                </Text>
                            </>
                        ) : (
                            // disclaimer Message for file upload
                            <div className={styles.customPromptMessage}>
                                <Text
                                    className={styles.customPromptMessage}
                                    style={{ color: isDarkTheme ? "white" : "black", marginBottom: promptTemplate == "" ? "0" : "-5px", fontSize: "11px" }}
                                >
                                    {uploaded_files[0]?.endsWith(".xlsx") ? (
                                        <>
                                            {`The responses are being fetched from the document ${uploaded_files[0]}.`}
                                            <span onClick={() => setOpenGuidlinesAlert(!openGuidlinesAlert)} className={styles.guidelines}>
                                                Guidelines...
                                            </span>
                                            <Snackbar
                                                open={openGuidlinesAlert}
                                                // autoHideDuration={12000}
                                                onClose={handleAlertClose}
                                                anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
                                                sx={{ marginBottom: "10%" }}
                                            >
                                                <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                                                    <AlertTitle sx={{ fontSize: "11px", fontWeight: "800" }}>Guidelines to Q&A with Excel File:</AlertTitle>
                                                    <p style={{ fontSize: "11px" }}>
                                                        {`• Mention the column name and worksheet name (if multiple columns of the same name are present 
                                                        in other worksheets as well) from which you want the data to be extracted.
                                                        • Mention the worksheet name, in addition to the question in the input.
                                                        • Kindly be more specific about the ask in the input.`}
                                                    </p>
                                                </Alert>
                                            </Snackbar>
                                            {console.log("xlsx selected")}
                                        </>
                                    ) : uploaded_files[0]?.endsWith(".csv") ? (
                                        <>
                                            {console.log("csv selected")}
                                            {`The responses are being fetched from the document ${uploaded_files[0]}.`}
                                            <span onClick={() => setOpenGuidlinesAlert(true)} className={styles.guidelines}>
                                                Guidelines...
                                            </span>
                                            <Snackbar
                                                open={openGuidlinesAlert}
                                                // autoHideDuration={12000}
                                                onClose={handleAlertClose}
                                                anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
                                                sx={{ marginBottom: "8%" }}
                                            >
                                                <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                                                    <AlertTitle sx={{ fontSize: "11px", fontWeight: "800" }}>Guidelines to Q&A with CSV File:</AlertTitle>
                                                    <p style={{ fontSize: "11px" }}>
                                                        {`• Mention the column name from which you want the data to be extracted.
                                                        • Kindly be more specific about the ask in the input.`}
                                                    </p>
                                                </Alert>
                                            </Snackbar>
                                        </>
                                    ) : (
                                        <>
                                            {/* Displaying the list of uploaded files */}
                                            <p>
                                                The responses are being fetched from the following files:{" "}
                                                {fileUploadedNames(uploaded_files, handleViewUploadedFiles)}{" "}
                                            </p>
                                            {/* Snackbar component to show the uploaded files list */}
                                            <Snackbar
                                                open={openSnackbar}
                                                onClose={handleAlertClose}
                                                anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
                                                sx={{ marginBottom: "8%" }}
                                            >
                                                <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                                                    <AlertTitle sx={{ fontSize: "11px", fontWeight: "800" }}>
                                                        Uploaded {uploaded_files.length} Files List:
                                                    </AlertTitle>
                                                    <p style={{ fontSize: "11px", maxHeight: "200px", overflowY: "scroll" }}>{responseMessage}</p>
                                                </Alert>
                                            </Snackbar>
                                        </>
                                    )}

                                    {/* Clear Document */}
                                    <button className={styles.clearPrompt} onClick={deleteEmbeddingsforcitaions} style={{ color: isDarkTheme ? "white" : "" }}>
                                        <Text>
                                            <u>
                                                <i>Clear Document</i>
                                            </u>
                                        </Text>
                                    </button>
                                </Text>
                            </div>
                        )}
                        {promptTemplate == "" ? (
                            <div></div>
                        ) : (
                            !isAnswerCompleted && (
                                <div className={styles.customPromptMessage}>
                                    <Text
                                        className={styles.customPromptMessage}
                                        style={{
                                            color: isDarkTheme ? "white" : "",
                                            fontSize: "11px",
                                            // marginBottom: embeddingsLoaded == false ? "0" : "-5px",
                                            // marginBottom: !embeddingsLoaded ? "0" : "5px",
                                            // marginTop: !embeddingsLoaded ? "0" : "-5px",
                                            overflow: "hidden"
                                        }}
                                    >
                                        *Assistant behaviour is being modified by custom prompt.
                                        <button className={styles.clearPrompt} onClick={clearPrompt}>
                                            <Text>
                                                <u>
                                                    <i>Clear Prompt</i>
                                                </u>
                                            </Text>
                                        </button>
                                    </Text>
                                </div>
                            )
                        )}
                        <QuestionInput
                            fileuploadelement={fileuploadelement()}
                            translatefileuploadelement={translatefileuploadelement()}
                            clearchat={clearChat}
                            isLoading={isLoading}
                            lastQuestionRef={lastQuestionRef}
                            clearOnSend
                            placeholder="Ask me a question. (Shift + Enter for new line)"
                            // onKeyDown={handleKeyDown}
                            disabled={isAnswerCompleted}
                            onSend={question => makeApiRequest(question)}
                            value={contentValue}
                            isContent={isContent}
                            showTooltip={showTooltip}
                        />
                        <Snackbar
                            open={openDocClearAlertforchat}
                            autoHideDuration={12000}
                            onClose={handleAlertClose}
                            anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        >
                            <Alert onClose={handleAlertClose} severity="info" sx={{ width: "100%" }}>
                                *The responses are not being fetched from the document.
                            </Alert>
                        </Snackbar>
                        <Snackbar
                            open={snackbarOpen}
                            autoHideDuration={6000}
                            onClose={handleAlertClose}
                            anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        >
                            <Alert onClose={handleSnackbarClose} severity={snackbarSeverity}>
                                {snackbarMessage}
                            </Alert>
                        </Snackbar>
                        {/* {showProgressBar && <ProgressBar currentValue={progress} maxValue={100} />} */}
                        <Snackbar
                            open={openSuccessAlert}
                            autoHideDuration={null}
                            onClose={handleAlertClose}
                            anchorOrigin={{ vertical: "top", horizontal: "center" }}
                        >
                            <Alert severity="success" sx={{ width: "100%" }} onClose={handleAlertClose}>
                                File(s) uploaded successfully!
                            </Alert>
                        </Snackbar>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Chat;
