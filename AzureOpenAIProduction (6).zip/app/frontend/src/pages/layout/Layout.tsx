import { Outlet, NavLink, Link } from "react-router-dom";
import github from "../../assets/github.svg";
import styles from "./Layout.module.css";
import NavSection from "../../components/NavSection/NavSection";
import { RecoilRoot } from "recoil";

interface LayoutProps {
    isSidebarOpen: boolean;
    setIsSidebarOpen: (isSidebarOpen: boolean) => void;
    promptTemplate: string;
    setPromptTemplate: (promptTemplate: string) => void;
    isInTeams : boolean;
}


const Layout = ({ setIsSidebarOpen, isSidebarOpen, setPromptTemplate, promptTemplate,isInTeams }: LayoutProps) => {
    return (
        <div className={styles.layout}>
            <RecoilRoot>
                <header className={styles.header} role={"banner"}>
                    <NavSection
                        isSidebarOpen={isSidebarOpen}
                        setIsSidebarOpen={setIsSidebarOpen}
                        pageTitle="ChatDSI"
                        pageSubTitle="Powered by GPT-4o"
                        promptTemplate={promptTemplate}
                        setPromptTemplate={setPromptTemplate}
                        isInTeams = {isInTeams}
                    />
                </header>

                <Outlet />
            </RecoilRoot>
        </div>
    );
};

export default Layout;
