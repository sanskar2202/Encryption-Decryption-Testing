/// <reference types="vite/client" />

declare module "vite-plugin-static-copy" {
    import { Plugin } from "vite";
    function viteStaticCopy(options: {
        targets: { src: string; dest: string }[];
    }): Plugin;
    export { viteStaticCopy };
}
