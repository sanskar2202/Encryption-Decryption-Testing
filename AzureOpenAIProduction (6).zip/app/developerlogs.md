PROD RELEASE: 5th April 2025


adeorukhkar@dsi.com

1)Removed code for capturing upload API runtime for dynamically capturing upload Time from app.py(for sharepoint and file upload) and writing inside CSV. Will consider this in future release.

2)Removed code for MS Teams Integration as it is on Hold. Teams_UAT_Publish(get code from this branch for teams)
 
3)Removed sharepoint API call and disabled some parts of it for Future integrations.


Sharepoint realese:

Multiple code refactor changes, please stop copy pasting same code for backend or even frontend
make plug and play code which is modular and can be re-used as much.

**Code Feature : Added a new Global Alerts module can be used anywhere from any file in front end. would improve upon feedback and check for overlaps with existing snackbars(there are too many confusing snackbars)