# Introduction 
This project uses Azure OpenAI Service to access the ChatGPT model (gpt-35-turbo / gpt-4), and Azure Cognitive Search for data indexing and retrieval.

# Steps to Setup the Project
1. Pull the repository on local machine
2. Go to folder /app/frontend and install the node packages using command "npm install".
3. Build the frontend using command "npm run build".
3. Go to folder /app/backend and create a python virtual environment.
4. Install the python packages in virtual environment using command "pip install -r requirements.txt".

# Steps to Run
1. Navigate to the /app/backend and activate the created python venv.
2. Start the server using command "quart run"
3. Navigate to http://localhost:5000 in web browser to interact with webapp.